## 检查ORACLE_DG的日志一致性
#
#spool OFF
#spool OFF
#spool OFF
#spool OFF
sqlplus  /nolog<<EOF
CONNECT /as  sysdba
@DGlog.sql
EOF

sqlplus system/oracle@//10.180.24.18/hlwzfdbbak<<EOF
@DGbaklog.sql
EOF
a=$(sed -n '4p' DG.log | tr -d ' ')
b=$(sed -n '4p' DGbak.log | tr -d ' ')

if [ $a!=$b ]; then
	echo " ERROR-db-DG"
    curl 'http://10.180.4.230:8000/sending/?msg=互联网支付数据库灾备同步异常此条是测试信息&at=15953192216'
	echo "oralce_DG is ok"
elif [ $a==$b ];then
	echo "hlwzfdb_DG is ok"
	curl 'http://10.180.4.230:8000/sending/?mesg=互联网支付数据库灾备数据同步正常'
#if [ read line DG100.log ]
