spool DGbak.log
select  max(sequence#) from v$log;
spool OFF
