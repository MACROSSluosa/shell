
set line 200 pages 1000
col trablespace_name format a24
col file_name format a40
col size_mb format 9999999
select tablespace_name,file_name,trunc(bytes/1024/1024) as size_mb from dba_data_files
union all
select tablespace_name,file_name,trunc(bytes/1024/1024) as size_mb from dba_temp_files
union all
select 'Redo Files' as tablespace_name,b.member,trunc(a.bytes/1024/1024) as size_mb
  from v$log a ,v$logfile b
 where a.group# = b.group# 
union all
select 'Control Files ' as tablespace_name,name,trunc(BLOCK_SIZE*FILE_SIZE_BLKS/1024/1024) as size_mb from v$controlfile ;

