prompt 
prompt +-----------------------------------------------------------------------------------------+
prompt |                             Snapshot Database 10g Release 2                             |
prompt |-----------------------------------------------------------------------------------------+
prompt +-----------------------------------------------------------------------------------------+
prompt
prompt Creating database report.
prompt This script must be run as a user with SYSDBA privileges.
prompt This process can take several minutes to complete.
prompt 

define reportHeader="<font size=+3 color=darkgreen><b>Snapshot Database 10<i>g</i> Release 2</b></font><hr>Copyright (c) 1998-2009 Jeffrey M. Hunter. All rights reserved. (<a target=""_blank"" href=""http://www.idevelopment.info"">www.idevelopment.info</a>)<p>"


-- +----------------------------------------------------------------------------+
-- |                           SCRIPT SETTINGS                                  |
-- +----------------------------------------------------------------------------+

set termout       off
set echo          off
set feedback      off
set heading       off
set verify        off
set wrap          on
set trimspool     on
set serveroutput  on
set escape        on

set pagesize 50000
set linesize 175
set long     2000000000

clear buffer computes columns breaks

define fileName=DBA_OraChk
define versionNumber=5.3


-- +----------------------------------------------------------------------------+
-- |                   GATHER DATABASE REPORT INFORMATION                       |
-- +----------------------------------------------------------------------------+

COLUMN tdate NEW_VALUE _date NOPRINT
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY') tdate FROM dual;

COLUMN time NEW_VALUE _time NOPRINT
SELECT TO_CHAR(SYSDATE,'HH24:MI:SS') time FROM dual;

COLUMN date_time NEW_VALUE _date_time NOPRINT
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY HH24:MI:SS') date_time FROM dual;

COLUMN date_time_timezone NEW_VALUE _date_time_timezone NOPRINT
SELECT TO_CHAR(systimestamp, 'Mon DD, YYYY (') || TRIM(TO_CHAR(systimestamp, 'Day')) || TO_CHAR(systimestamp, ') "at" HH:MI:SS AM') || TO_CHAR(systimestamp, ' "in Timezone" TZR') date_time_timezone
FROM dual;

COLUMN spool_time NEW_VALUE _spool_time NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD') spool_time FROM dual;

COLUMN dbname NEW_VALUE _dbname NOPRINT
SELECT name dbname FROM v$database;

COLUMN dbid NEW_VALUE _dbid NOPRINT
SELECT dbid dbid FROM v$database;

COLUMN platform_id NEW_VALUE _platform_id NOPRINT
SELECT platform_id platform_id FROM v$database;

COLUMN platform_name NEW_VALUE _platform_name NOPRINT
SELECT platform_name platform_name FROM v$database;

COLUMN global_name NEW_VALUE _global_name NOPRINT
SELECT global_name global_name FROM global_name;

COLUMN blocksize NEW_VALUE _blocksize NOPRINT
SELECT value blocksize FROM v$parameter WHERE name='db_block_size';

COLUMN startup_time NEW_VALUE _startup_time NOPRINT
SELECT TO_CHAR(startup_time, 'MM/DD/YYYY HH24:MI:SS') startup_time FROM v$instance;

COLUMN host_name NEW_VALUE _host_name NOPRINT
SELECT host_name host_name FROM v$instance;

COLUMN instance_name NEW_VALUE _instance_name NOPRINT
SELECT instance_name instance_name FROM v$instance;

COLUMN instance_number NEW_VALUE _instance_number NOPRINT
SELECT instance_number instance_number FROM v$instance;

COLUMN thread_number NEW_VALUE _thread_number NOPRINT
SELECT thread# thread_number FROM v$instance;

COLUMN cluster_database NEW_VALUE _cluster_database NOPRINT
SELECT value cluster_database FROM v$parameter WHERE name='cluster_database';

COLUMN cluster_database_instances NEW_VALUE _cluster_database_instances NOPRINT
SELECT value cluster_database_instances FROM v$parameter WHERE name='cluster_database_instances';

COLUMN reportRunUser NEW_VALUE _reportRunUser NOPRINT
SELECT user reportRunUser FROM dual;

COLUMN max_cursor_limit NEW_VALUE _max_cursor_limit NOPRINT
select value  max_cursor_limit from v$parameter where name='open_cursors' ;  

COLUMN value_cpu_count NEW_VALUE _value_cpu_count noprint
select value value_cpu_count  from v$parameter where name = 'cpu_count' ;


col startup_time  new_val startup_time noprint      
select to_char(startup_time, 'yyyymmddhh24mi') startup_time
  from v$instance ;

-- +----------------------------------------------------------------------------+
-- |                   GATHER DATABASE REPORT INFORMATION                       |
-- +----------------------------------------------------------------------------+

set heading on

col status format a8

set markup html on spool on preformat off entmap on -
head ' -
  <title>Database Report</title> -
  <style type="text/css"> -
    body              {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;} -
    p                 {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;} -
    table,tr,td       {font:9pt Arial,Helvetica,sans-serif; color:Black; background:#C0C0C0; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px;} -
    th                {font:bold 9pt Arial,Helvetica,sans-serif; color:#336699; background:#cccc99; padding:0px 0px 0px 0px;} -
    h1                {font:bold 12pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; border-bottom:1px solid #cccc99; margin-top:0pt; margin-bottom:0pt; padding:0px 0px 0px 0px;} -
    h2                {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; margin-top:4pt; margin-bottom:0pt;} -
    a                 {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.link            {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLink          {font:9pt Arial,Helvetica,sans-serif; color:#663300; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkBlue      {font:9pt Arial,Helvetica,sans-serif; color:#0000ff; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkBlue  {font:9pt Arial,Helvetica,sans-serif; color:#000099; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkRed       {font:9pt Arial,Helvetica,sans-serif; color:#ff0000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkRed   {font:9pt Arial,Helvetica,sans-serif; color:#990000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkGreen     {font:9pt Arial,Helvetica,sans-serif; color:#00ff00; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkGreen {font:9pt Arial,Helvetica,sans-serif; color:#009900; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
  </style>' -
body   'BGCOLOR="#C0C0C0"' -
table  'WIDTH="90%" BORDER="1"' 

spool &FileName._&_dbname._&_spool_time..html

set markup html on entmap off


-- +----------------------------------------------------------------------------+
-- |                             - REPORT HEADER -                              |
-- +----------------------------------------------------------------------------+

prompt <a name=top></a>
prompt &reportHeader



-- +----------------------------------------------------------------------------+
-- |                             - REPORT INDEX -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="report_index"></a>


prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Report Index</b></font><hr align="center" width="250"></center> -
<table width="90%" border="1"> -
<tr><th colspan="4">Database and Instance Information</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#report_header">Report Header</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#version">Version</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#high_water_mark_statistics">High Water Mark Statistics</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#instance_overview">Instance Overview</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#database_overview">Database Overview</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#initialization_parameters">Initialization Parameters</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#control_files">Control Files</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#online_redo_logs">Online Redo Logs</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#redo_log_switches">Redo Log Switches</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#outstanding_alerts">Outstanding Alerts</a></td> -
<td nowrap align="center" width="25%"><br></td> -
<td nowrap align="center" width="25%"><br></td> -
</tr>


prompt -
<tr><th colspan="4">Scheduler / Jobs</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#jobs">Jobs</a></td> -
<td nowrap align="center" width="25%"><br></td> -
<td nowrap align="center" width="25%"><br></td> -
<td nowrap align="center" width="25%"><br></td> -
</tr> -
<tr><th colspan="4">Storage</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#tablespaces">Tablespaces</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#data_files">Data Files</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#database_growth">Database Growth</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#tablespace_extents">Tablespace Extents</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#tablespace_to_owner">Tablespace to Owner</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#owner_to_tablespace">Owner to Tablespace</a></td> -
<td nowrap align="center" width="25%"><br></td> -
<td nowrap align="center" width="25%"><br></td> -
</tr>


prompt -
<tr><th colspan="4">UNDO Segments</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#undo_segments">UNDO Segments</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#undo_segment_contention">UNDO Segment Contention</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#undo_retention_parameters">UNDO Retention Parameters</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#Undo_tablespace_check">Undo Tablesspace Information</a></td> -
</tr>


prompt -
<tr><th colspan="4">Backups</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#rman_backup_jobs">RMAN Backup Jobs</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#rman_configuration">RMAN Configuration</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#rman_backup_sets">RMAN Backup Sets</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#rman_backup_pieces">RMAN Backup Pieces</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#rman_backup_control_files">RMAN Backup Control Files</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#rman_backup_spfile">RMAN Backup SPFILE</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#archiving_mode">Archiving Mode</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#archive_destinations">Archive Destinations</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#archiving_instance_parameters">Archiving Instance Parameters</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#archiving_history">Archiving History</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#flash_recovery_area_parameters">Flash Recovery Area Parameters</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#flash_recovery_area_status">Flash Recovery Area Status</a></td> -
</tr>


prompt -
<tr><th colspan="4">Flashback Technologies</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#undo_retention_parameters">UNDO Retention Parameters</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#flashback_database_parameters">Flashback Database Parameters</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#flashback_database_status">Flashback Database Status</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#flashback_database_redo_time_matrix">Flashback Database Redo Time Matrix</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_recycle_bin">Recycle Bin</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr>


prompt -
<tr><th colspan="4">Performance</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#sga_information">SGA Information</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#sga_target_advice">SGA Target Advice</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#sga_asmm_dynamic_components">SGA (ASMM) Dynamic Components</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#pga_target_advice">PGA Target Advice</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#pga_session">PGA advice for Individual Session</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#sql_workarea_histogram">SQL Workarea Histogram</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#file_io_statistics">File I/O Statistics</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#file_io_timings">File I/O Timings</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#average_overall_io_per_sec">Average Overall I/O per Second</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#redo_log_contention">Redo Log Contention</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#full_table_scans">Full Table Scans</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#sorts">Sorts</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_outlines">Outlines</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_outline_hints">Outline Hints</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#sql_statements_with_most_buffer_gets">SQL Statements With Most Buffer Gets</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#sql_statements_with_most_disk_reads">SQL Statements With Most Disk Reads</a></td> -
</tr>
prompt -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#db_buffer_cache_hit_ratio">DB Buffer Cache Hit Ratio</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dictionary_cache_hit_ratio">Dictionary Cache Hit Ratio</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#library_cache_hit_ratio">Library Cache Hit Ratio</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#latch_contention">Latch Contention</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#system_wait_statistics">System Wait Statistics</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#system_statistics">System Statistics</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#system_event_statistics">System Event Statistics</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#top_10_tables">Top 10 Accessed Objects</a></td> -
</tr>-
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#top_10_procedures">Top 10 Procedures</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr>-


prompt -
<tr><th colspan="4">Automatic Workload Repository - (AWR)</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#awr_workload_repository_information">Workload Repository Information</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#awr_snapshot_size_estimates">AWR Snapshot Size Estimates</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr> -


prompt -
<tr><th colspan="4">Sessions</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#current_sessions">Current Sessions</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#user_session_matrix">User Session Matrix</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr>


prompt -
<tr><th colspan="4">Security</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#user_accounts">User Accounts</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#users_with_dba_privileges">Users With DBA Privileges</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#default_passwords">Default Passwords</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#db_links">DB Links</a></td> -
</tr>


prompt -
<tr><th colspan="4">Objects</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#segment_summary">Segment Summary</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#top_100_segments_by_size">Top 100 Segments (by size)</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#top_100_segments_by_extents">Top 100 Segments (by number of extents)</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_directories">Directories</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_directory_privileges">Directory Privileges</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_lob_segments">LOB Segments</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#objects_unable_to_extend">Objects Unable to Extend</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#objects_which_are_nearing_maxextents">Objects Which Are Nearing MAXEXTENTS</a></td> -
</tr>


prompt -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#invalid_objects">Invalid Objects</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#objects_without_statistics">Objects Without Statistics</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#tables_suffering_from_row_chaining_migration">Tables Suffering From Row Chaining/Migration</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#users_with_default_tablespace_defined_as_system">Users With Default Tablespace - (SYSTEM)</a></td> -
</tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#users_with_default_temporary_tablespace_as_system">Users With Default Temp Tablespace - (SYSTEM)</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#objects_in_the_system_tablespace">Objects in the SYSTEM Tablespace</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_recycle_bin">Recycle Bin</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr>


prompt -
<tr><th colspan="4">Online Analytical Processing - (OLAP)</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_olap_materialized_views">Materialized Views</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_olap_materialized_view_logs">Materialized View Logs</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#dba_olap_materialized_view_refresh_groups">Materialized View Refresh Groups</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr>


prompt -
<tr><th colspan="4">CES</th></tr> -
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#open_cursors">Open Cursors and Others</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#index_invalid">Invalid Index</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#index_need_rebuild">Index Needs Rebuild</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#tables_need_stats">Tables Needs Stats</a></td> -
</tr>-
<tr> -
<td nowrap align="center" width="25%"><a class="link" href="#auto_statistics">Auto Statistics Info</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#Snapshot_infor_perf">10g Snapshot Info</a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
<td nowrap align="center" width="25%"><a class="link" href="#"><br></a></td> -
</tr> -
</table>

prompt <p>






-- +============================================================================+
-- |                                                                            |
-- |        <<<<<     Database and Instance Information    >>>>>                |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Database and Instance Information</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                            - REPORT HEADER -                               |
-- +----------------------------------------------------------------------------+

prompt 
prompt <a name="report_header"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Report Header</b></font><hr align="left" width="460">

prompt <table width="90%" border="1"> -
<tr><th align="left" width="20%">Report Name</th><td width="80%"><tt>&FileName._&_dbname._&_spool_time..html</tt></td></tr> -
<tr><th align="left" width="20%">Snapshot Database Version</th><td width="80%"><tt>&versionNumber</tt></td></tr> -
<tr><th align="left" width="20%">Run Date / Time / Timezone</th><td width="80%"><tt>&_date_time_timezone</tt></td></tr> -
<tr><th align="left" width="20%">Host Name</th><td width="80%"><tt>&_host_name</tt></td></tr> -
<tr><th align="left" width="20%">Database Name</th><td width="80%"><tt>&_dbname</tt></td></tr> -
<tr><th align="left" width="20%">Database ID</th><td width="80%"><tt>&_dbid</tt></td></tr> -
<tr><th align="left" width="20%">Global Database Name</th><td width="80%"><tt>&_global_name</tt></td></tr> -
<tr><th align="left" width="20%">Platform Name / ID</th><td width="80%"><tt>&_platform_name / &_platform_id</tt></td></tr> -
<tr><th align="left" width="20%">Clustered Database?</th><td width="80%"><tt>&_cluster_database</tt></td></tr> -
<tr><th align="left" width="20%">Clustered Database Instances</th><td width="80%"><tt>&_cluster_database_instances</tt></td></tr> -
<tr><th align="left" width="20%">Instance Name</th><td width="80%"><tt>&_instance_name</tt></td></tr> -
<tr><th align="left" width="20%">Instance Number</th><td width="80%"><tt>&_instance_number</tt></td></tr> -
<tr><th align="left" width="20%">Thread Number</th><td width="80%"><tt>&_thread_number</tt></td></tr> -
<tr><th align="left" width="20%">Database Startup Time</th><td width="80%"><tt>&_startup_time</tt></td></tr> -
<tr><th align="left" width="20%">Database Block Size</th><td width="80%"><tt>&_blocksize</tt></td></tr> -
<tr><th align="left" width="20%">Report Run User</th><td width="80%"><tt>&_reportRunUser</tt></td></tr> -
</table>

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- SET TIMING ON

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - DBA REGISTRY -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="DBA REGISTRY  "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b> DBA REGISTRY  </b></font><hr align="left" width="460">


select * from  DBA_REGISTRY;


-- +----------------------------------------------------------------------------+
-- |                                 - VERSION -                                |
-- +----------------------------------------------------------------------------+

prompt <a name="version"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Version</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN banner   FORMAT a120   HEADING 'Banner'

SELECT * FROM v$version;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - HIGH WATER MARK STATISTICS -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="high_water_mark_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>High Water Mark Statistics</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN statistic_name        FORMAT a115                    HEADING 'Statistic Name'
COLUMN version               FORMAT a62                     HEADING 'Version'
COLUMN highwater             FORMAT 9,999,999,999,999,999   HEADING 'Highwater'
COLUMN last_value            FORMAT 9,999,999,999,999,999   HEADING 'Last Value'
COLUMN description           FORMAT a120                    HEADING 'Description'

SELECT
    '<div align="left"><font color="#336699"><b>' || hw.name || '</b></font></div>'  statistic_name
  , '<div align="right">' || hw.version || '</div>'                                  version
  , hw.highwater                                                                     highwater
  , hw.last_value                                                                    last_value
  , hw.description                                                                   description
FROM dba_high_water_mark_statistics hw,v$instance i
WHERE hw.version=i.version
ORDER BY name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - INSTANCE OVERVIEW -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="instance_overview"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Instance Overview</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print       FORMAT a75    HEADING 'Instance|Name'       ENTMAP off
COLUMN instance_number_print     FORMAT a75    HEADING 'Instance|Num'        ENTMAP off
COLUMN thread_number_print                     HEADING 'Thread|Num'          ENTMAP off
COLUMN host_name_print           FORMAT a75    HEADING 'Host|Name'           ENTMAP off
COLUMN version                                 HEADING 'Oracle|Version'      ENTMAP off
COLUMN start_time                FORMAT a75    HEADING 'Start|Time'          ENTMAP off
COLUMN uptime                                  HEADING 'Uptime|(in days)'    ENTMAP off
COLUMN parallel                  FORMAT a75    HEADING 'Parallel - (RAC)'    ENTMAP off
COLUMN instance_status           FORMAT a75    HEADING 'Instance|Status'     ENTMAP off
COLUMN database_status           FORMAT a75    HEADING 'Database|Status'     ENTMAP off
COLUMN logins                    FORMAT a75    HEADING 'Logins'              ENTMAP off
COLUMN archiver                  FORMAT a75    HEADING 'Archiver'            ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || instance_name || '</b></font></div>'         instance_name_print
  , '<div align="center">' || instance_number || '</div>'                                           instance_number_print
  , '<div align="center">' || thread#         || '</div>'                                           thread_number_print
  , '<div align="center">' || host_name       || '</div>'                                           host_name_print
  , '<div align="center">' || version         || '</div>'                                           version
  , '<div align="center">' || TO_CHAR(startup_time,'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , ROUND(TO_CHAR(SYSDATE-startup_time), 2)                                                         uptime
  , '<div align="center">' || parallel        || '</div>'                                           parallel
  , '<div align="center">' || status          || '</div>'                                           instance_status
  , '<div align="center">' || logins          || '</div>'                                           logins
  , DECODE(   archiver
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || archiver || '</font></b></div>'
            , '<div align="center"><b><font color="darkgreen">' || archiver || '</font></b></div>') archiver
FROM gv$instance
ORDER BY instance_number;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - DATABASE OVERVIEW -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="database_overview"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Overview</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name                            FORMAT a75     HEADING 'Database|Name'              ENTMAP off
COLUMN dbid                                           HEADING 'Database|ID'                ENTMAP off
COLUMN db_unique_name                                 HEADING 'Database|Unique Name'       ENTMAP off
COLUMN creation_date                                  HEADING 'Creation|Date'              ENTMAP off
COLUMN platform_name_print                            HEADING 'Platform|Name'              ENTMAP off
COLUMN current_scn                                    HEADING 'Current|SCN'                ENTMAP off
COLUMN log_mode                                       HEADING 'Log|Mode'                   ENTMAP off
COLUMN open_mode                                      HEADING 'Open|Mode'                  ENTMAP off
COLUMN force_logging                                  HEADING 'Force|Logging'              ENTMAP off
COLUMN flashback_on                                   HEADING 'Flashback|On?'              ENTMAP off
COLUMN controlfile_type                               HEADING 'Controlfile|Type'           ENTMAP off
COLUMN last_open_incarnation_number                   HEADING 'Last Open|Incarnation Num'  ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>'  || name  || '</b></font></div>'          name
  , '<div align="center">' || dbid                   || '</div>'                              dbid
  , '<div align="center">' || db_unique_name         || '</div>'                              db_unique_name
  , '<div align="center">' || TO_CHAR(created, 'mm/dd/yyyy HH24:MI:SS') || '</div>'           creation_date
  , '<div align="center">' || platform_name          || '</div>'                              platform_name_print
  , '<div align="center">' || current_scn            || '</div>'                              current_scn
  , '<div align="center">' || log_mode               || '</div>'                              log_mode
  , '<div align="center">' || open_mode              || '</div>'                              open_mode
  , '<div align="center">' || force_logging          || '</div>'                              force_logging
  , '<div align="center">' || flashback_on           || '</div>'                              flashback_on
  , '<div align="center">' || controlfile_type       || '</div>'                              controlfile_type
  , '<div align="center">' || last_open_incarnation# || '</div>'                              last_open_incarnation_number
FROM v$database;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                       - INITIALIZATION PARAMETERS -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="initialization_parameters"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Initialization Parameters</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN spfile  HEADING 'SPFILE Usage'

SELECT
  'This database '||
  DECODE(   (1-SIGN(1-SIGN(count(*) - 0)))
          , 1
          , '<font color="#663300"><b>IS</b></font>'
          , '<font color="#990000"><b>IS NOT</b></font>') ||
  ' using an SPFILE.'spfile
FROM v$spparameter
WHERE value IS NOT null;


COLUMN pname                FORMAT a75    HEADING 'Parameter Name'    ENTMAP off
COLUMN instance_name_print  FORMAT a45    HEADING 'Instance Name'     ENTMAP off
COLUMN value                FORMAT a75    HEADING 'Value'             ENTMAP off
COLUMN isdefault            FORMAT a75    HEADING 'Is Default?'       ENTMAP off
COLUMN issys_modifiable     FORMAT a75    HEADING 'Is Dynamic?'       ENTMAP off

BREAK ON report ON pname

SELECT
    DECODE(   p.isdefault
            , 'FALSE'
            , '<b><font color="#336699">' || SUBSTR(p.name,0,512) || '</font></b>'
            , '<b><font color="#336699">' || SUBSTR(p.name,0,512) || '</font></b>' )    pname
  , DECODE(   p.isdefault
            , 'FALSE'
            , '<font color="#663300"><b>' || i.instance_name || '</b></font>'
            , i.instance_name )                                                         instance_name_print
  , DECODE(   p.isdefault
            , 'FALSE'
            , '<font color="#663300"><b>' || SUBSTR(p.value,0,512) || '</b></font>'
            , SUBSTR(p.value,0,512) ) value
  , DECODE(   p.isdefault
            , 'FALSE'
            , '<div align="center"><font color="#663300"><b>' || p.isdefault || '</b></font></div>'
            , '<div align="center">'                          || p.isdefault || '</div>')                         isdefault
  , DECODE(   p.isdefault
            , 'FALSE'
            , '<div align="right"><font color="#663300"><b>' || p.issys_modifiable || '</b></font></div>'
            , '<div align="right">'                          || p.issys_modifiable || '</div>')                  issys_modifiable
FROM
    gv$parameter p
  , gv$instance  i
WHERE
    p.inst_id = i.inst_id
ORDER BY
		isdefault
	, p.name
  , i.instance_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                            - CONTROL FILES -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="control_files"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Control Files</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name                           HEADING 'Controlfile Name'  ENTMAP off
COLUMN status           FORMAT a75    HEADING 'Status'            ENTMAP off
COLUMN file_size        FORMAT a75    HEADING 'File Size'         ENTMAP off

SELECT
    '<tt>' || c.name || '</tt>'                                                                      name
  , DECODE(   c.status
            , NULL
            ,  '<div align="center"><b><font color="darkgreen">VALID</font></b></div>'
            ,  '<div align="center"><b><font color="#663300">'   || c.status || '</font></b></div>') status
  , '<div align="right">' || TO_CHAR(block_size *  file_size_blks, '999,999,999,999') || '</div>'    file_size
FROM 
    v$controlfile c
ORDER BY
    c.name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                          - ONLINE REDO LOGS -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="online_redo_logs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Online Redo Logs</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print  FORMAT a95                HEADING 'Instance Name'    ENTMAP off
COLUMN thread_number_print  FORMAT a95                HEADING 'Thread Number'    ENTMAP off
COLUMN groupno                                        HEADING 'Group Number'     ENTMAP off
COLUMN member                                         HEADING 'Member'           ENTMAP off
COLUMN redo_file_type       FORMAT a75                HEADING 'Redo Type'        ENTMAP off
COLUMN log_status           FORMAT a75                HEADING 'Log Status'       ENTMAP off
COLUMN bytes                FORMAT 999,999,999,999    HEADING 'Bytes'            ENTMAP off
COLUMN archived             FORMAT a75                HEADING 'Archived?'        ENTMAP off

BREAK ON report ON instance_name_print ON thread_number_print

SELECT
    '<div align="center"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'        instance_name_print
  , '<div align="center">' || i.thread# || '</div>'                                                  thread_number_print
  , f.group#                                                                                         groupno
  , '<tt>' || f.member || '</tt>'                                                                    member
  , f.type                                                                                           redo_file_type
  , DECODE(   l.status
            , 'CURRENT'
            , '<div align="center"><b><font color="darkgreen">' || l.status || '</font></b></div>'
            , '<div align="center"><b><font color="#990000">'   || l.status || '</font></b></div>')  log_status
  , l.bytes                                                                                          bytes
  , '<div align="center">'  || l.archived || '</div>'                                                archived
FROM
    gv$logfile  f
  , gv$log      l
  , gv$instance i
WHERE
      f.group#  = l.group#
  AND l.thread# = i.thread#
  AND i.inst_id = f.inst_id
  AND f.inst_id = l.inst_id
ORDER BY
    i.instance_name
  , f.group#
  , f.member;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                         - REDO LOG SWITCHES -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="redo_log_switches"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Redo Log Switches</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN DAY   FORMAT a75              HEADING 'Day / Time'  ENTMAP off
COLUMN H00   FORMAT 999,999B         HEADING '00'          ENTMAP off
COLUMN H01   FORMAT 999,999B         HEADING '01'          ENTMAP off
COLUMN H02   FORMAT 999,999B         HEADING '02'          ENTMAP off
COLUMN H03   FORMAT 999,999B         HEADING '03'          ENTMAP off
COLUMN H04   FORMAT 999,999B         HEADING '04'          ENTMAP off
COLUMN H05   FORMAT 999,999B         HEADING '05'          ENTMAP off
COLUMN H06   FORMAT 999,999B         HEADING '06'          ENTMAP off
COLUMN H07   FORMAT 999,999B         HEADING '07'          ENTMAP off
COLUMN H08   FORMAT 999,999B         HEADING '08'          ENTMAP off
COLUMN H09   FORMAT 999,999B         HEADING '09'          ENTMAP off
COLUMN H10   FORMAT 999,999B         HEADING '10'          ENTMAP off
COLUMN H11   FORMAT 999,999B         HEADING '11'          ENTMAP off
COLUMN H12   FORMAT 999,999B         HEADING '12'          ENTMAP off
COLUMN H13   FORMAT 999,999B         HEADING '13'          ENTMAP off
COLUMN H14   FORMAT 999,999B         HEADING '14'          ENTMAP off
COLUMN H15   FORMAT 999,999B         HEADING '15'          ENTMAP off
COLUMN H16   FORMAT 999,999B         HEADING '16'          ENTMAP off
COLUMN H17   FORMAT 999,999B         HEADING '17'          ENTMAP off
COLUMN H18   FORMAT 999,999B         HEADING '18'          ENTMAP off
COLUMN H19   FORMAT 999,999B         HEADING '19'          ENTMAP off
COLUMN H20   FORMAT 999,999B         HEADING '20'          ENTMAP off
COLUMN H21   FORMAT 999,999B         HEADING '21'          ENTMAP off
COLUMN H22   FORMAT 999,999B         HEADING '22'          ENTMAP off
COLUMN H23   FORMAT 999,999B         HEADING '23'          ENTMAP off
COLUMN TOTAL FORMAT 999,999,999      HEADING 'Total'       ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total:</b></font>' avg label '<font color="#990000"><b>Average:</b></font>' OF total ON report

SELECT
    '<div align="center"><font color="#336699"><b>' || SUBSTR(TO_CHAR(first_time, 'YYYY-MM-DD HH:MI:SS'),1,10)  || '</b></font></div>'  DAY
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'00',1,0)) H00
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'01',1,0)) H01
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'02',1,0)) H02
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'03',1,0)) H03
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'04',1,0)) H04
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'05',1,0)) H05
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'06',1,0)) H06
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'07',1,0)) H07
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'08',1,0)) H08
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'09',1,0)) H09
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'10',1,0)) H10
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'11',1,0)) H11
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'12',1,0)) H12
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'13',1,0)) H13
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'14',1,0)) H14
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'15',1,0)) H15
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'16',1,0)) H16
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'17',1,0)) H17
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'18',1,0)) H18
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'19',1,0)) H19
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'20',1,0)) H20
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'21',1,0)) H21
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'22',1,0)) H22
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'23',1,0)) H23
  , COUNT(*)                                                                      TOTAL
FROM
  v$log_history  a
GROUP BY SUBSTR(TO_CHAR(first_time, 'YYYY-MM-DD HH:MI:SS'),1,10)
ORDER BY SUBSTR(TO_CHAR(first_time, 'YYYY-MM-DD HH:MI:SS'),1,10)
/


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +============================================================================+
-- |                                                                            |
-- |                  <<<<<     SCHEDULER / JOBS     >>>>>                      |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Scheduler / Jobs</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                                 - JOBS -                                   |
-- +----------------------------------------------------------------------------+

prompt <a name="jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Jobs</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN job_id     FORMAT a75             HEADING 'Job ID'           ENTMAP off
COLUMN username   FORMAT a75             HEADING 'User'             ENTMAP off
COLUMN what       FORMAT a175            HEADING 'What'             ENTMAP off
COLUMN next_date  FORMAT a110            HEADING 'Next Run Date'    ENTMAP off
COLUMN interval   FORMAT a75             HEADING 'Interval'         ENTMAP off
COLUMN last_date  FORMAT a110            HEADING 'Last Run Date'    ENTMAP off
COLUMN failures   FORMAT a75             HEADING 'Failures'         ENTMAP off
COLUMN broken     FORMAT a75             HEADING 'Broken?'          ENTMAP off

SELECT
    DECODE(   broken
            , 'Y'
            , '<b><font color="#990000"><div align="center">' || job || '</div></font></b>'
            , '<b><font color="#336699"><div align="center">' || job || '</div></font></b>')    job_id
  , DECODE(   broken
            , 'Y'
            , '<b><font color="#990000">' || log_user || '</font></b>'
            , log_user )    username
  , DECODE(   broken
            , 'Y'
            , '<b><font color="#990000">' || what || '</font></b>'
            , what )        what
  , DECODE(   broken
            , 'Y'
            , '<div nowrap align="right"><b><font color="#990000">' || NVL(TO_CHAR(next_date, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</font></b></div>'
            , '<div nowrap align="right">'                          || NVL(TO_CHAR(next_date, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</div>')      next_date  
  , DECODE(   broken
            , 'Y'
            , '<b><font color="#990000">' || interval || '</font></b>'
            , interval )    interval
  , DECODE(   broken
            , 'Y'
            , '<div nowrap align="right"><b><font color="#990000">' || NVL(TO_CHAR(last_date, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</font></b></div>'
            , '<div nowrap align="right">'                          || NVL(TO_CHAR(last_date, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</div>')    last_date  
  , DECODE(   broken
            , 'Y'
            , '<b><font color="#990000"><div align="center">' || NVL(failures, 0) || '</div></font></b>'
            , '<div align="center">'                          || NVL(failures, 0) || '</div>')    failures
  , DECODE(   broken
            , 'Y'
            , '<b><font color="#990000"><div align="center">' || broken || '</div></font></b>'
            , '<div align="center">'                          || broken || '</div>')      broken
FROM
    dba_jobs
ORDER BY
    job;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +============================================================================+
-- |                                                                            |
-- |                      <<<<<     STORAGE    >>>>>                            |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Storage</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                            - TABLESPACES -                                 |
-- +----------------------------------------------------------------------------+

prompt <a name="tablespaces"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tablespaces</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN status                                  HEADING 'Status'            ENTMAP off
COLUMN name                                    HEADING 'Tablespace Name'   ENTMAP off
COLUMN type        FORMAT a12                  HEADING 'TS Type'           ENTMAP off
COLUMN extent_mgt  FORMAT a10                  HEADING 'Ext. Mgt.'         ENTMAP off
COLUMN segment_mgt FORMAT a9                   HEADING 'Seg. Mgt.'         ENTMAP off
COLUMN ts_size     FORMAT 999,999,999,999,999  HEADING 'Tablespace Size'   ENTMAP off
COLUMN free        FORMAT 999,999,999,999,999  HEADING 'Free (in MB)'   ENTMAP off
COLUMN used        FORMAT 999,999,999,999,999  HEADING 'Used (in MB)'   ENTMAP off
COLUMN pct_used                                HEADING 'Pct. Used'         ENTMAP off

BREAK ON report
COMPUTE SUM label '<font color="#990000"><b>Total:</b></font>'   OF ts_size used free ON report

SELECT
    DECODE(   d.status
            , 'OFFLINE'
            , '<div align="center"><b><font color="#990000">'   || d.status || '</font></b></div>'
            , '<div align="center"><b><font color="darkgreen">' || d.status || '</font></b></div>') status
  , '<b><font color="#336699">' || d.tablespace_name || '</font></b>'                               name
  , d.contents                                          type
  , d.extent_management                                 extent_mgt
  , d.segment_space_management                          segment_mgt
  , NVL(a.bytes, 0)                                     ts_size
  , NVL(f.bytes, 0)                                     free
  , NVL(a.bytes - NVL(f.bytes, 0), 0)                   used
  , '<div align="right"><b>' || 
          DECODE (
              (1-SIGN(1-SIGN(TRUNC(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0)) - 90)))
            , 1
            , '<font color="#990000">'   || TO_CHAR(TRUNC(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0))) || '</font>'
            , '<font color="darkgreen">' || TO_CHAR(TRUNC(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0))) || '</font>'
          )
    || '</b> %</div>' pct_used
FROM 
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes)/1024/1024 bytes
      from dba_data_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes)/1024/1024 bytes
      from dba_free_space
      group by tablespace_name
    ) f
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = f.tablespace_name(+)
  AND NOT (
    d.extent_management like 'LOCAL'
    AND
    d.contents like 'TEMPORARY'
  )
UNION ALL 
SELECT
    DECODE(   d.status
            , 'OFFLINE'
            , '<div align="center"><b><font color="#990000">'   || d.status || '</font></b></div>'
            , '<div align="center"><b><font color="darkgreen">' || d.status || '</font></b></div>') status
  , '<b><font color="#336699">' || d.tablespace_name  || '</font></b>'                              name
  , d.contents                                   type
  , d.extent_management                          extent_mgt
  , d.segment_space_management                   segment_mgt
  , NVL(a.bytes, 0)                              ts_size
  , NVL(a.bytes - NVL(t.bytes,0), 0)             free
  , NVL(t.bytes, 0)                              used
  , '<div align="right"><b>' || 
          DECODE (
              (1-SIGN(1-SIGN(TRUNC(NVL(t.bytes / a.bytes * 100, 0)) - 90)))
            , 1
            , '<font color="#990000">'   || TO_CHAR(TRUNC(NVL(t.bytes / a.bytes * 100, 0))) || '</font>'
            , '<font color="darkgreen">' || TO_CHAR(TRUNC(NVL(t.bytes / a.bytes * 100, 0))) || '</font>'
          )
    || '</b> %</div>' pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes)/1024/1024 bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_cached)/1024/1024 bytes
      from v$temp_extent_pool
      group by tablespace_name
    ) t
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
ORDER BY 2;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                            - DATA FILES -                                  |
-- +----------------------------------------------------------------------------+

prompt <a name="data_files"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Data Files</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN tablespace                                   HEADING 'Tablespace Name / File Class'  ENTMAP off
COLUMN filename                                     HEADING 'Filename'                      ENTMAP off
COLUMN filesize        FORMAT 999,999,999,999,999   HEADING 'File Size'                     ENTMAP off
COLUMN autoextensible                               HEADING 'Autoextensible'                ENTMAP off
COLUMN increment_by    FORMAT 999,999,999,999,999   HEADING 'Next'                          ENTMAP off
COLUMN maxbytes        FORMAT 999,999,999,999,999   HEADING 'Max'                           ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF filesize ON report

SELECT --/*+ ordered */
    '<font color="#336699"><b>' || d.tablespace_name  || '</b></font>'  tablespace
  , '<tt>' || d.file_name || '</tt>'                                    filename
  , d.bytes                                                             filesize
  , '<div align="center">' || NVL(d.autoextensible, '<br>') || '</div>' autoextensible
  , d.increment_by * e.value                                            increment_by
  , d.maxbytes                                                          maxbytes
FROM
    sys.dba_data_files d
  , v$datafile v
  , (SELECT value
     FROM v$parameter 
     WHERE name = 'db_block_size') e
WHERE
  (d.file_name = v.name)
UNION ALL
SELECT
    '<font color="#336699"><b>' || d.tablespace_name || '</b></font>'   tablespace 
  , '<tt>' || d.file_name  || '</tt>'                                   filename
  , d.bytes                                                             filesize
  , '<div align="center">' || NVL(d.autoextensible, '<br>') || '</div>' autoextensible
  , d.increment_by * e.value                                            increment_by
  , d.maxbytes                                                          maxbytes
FROM
    sys.dba_temp_files d
  , (SELECT value
     FROM v$parameter 
     WHERE name = 'db_block_size') e
UNION ALL
SELECT
    '<font color="#336699"><b>[ ONLINE REDO LOG ]</b></font>'
  , '<tt>' || a.member || '</tt>'
  , b.bytes
  , null
  , null
  , null
FROM
    v$logfile a
  , v$log b
WHERE
    a.group# = b.group#
UNION ALL
SELECT
    '<font color="#336699"><b>[ CONTROL FILE    ]</b></font>'
  , '<tt>' || a.name || '</tt>'
  , null
  , null
  , null
  , null
FROM
    v$controlfile a
ORDER BY
    1
  , 2;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                          - DATABASE GROWTH -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="database_growth"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Growth</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN month        FORMAT a75                  HEADING 'Month'
COLUMN growth       FORMAT 999,999,999,999,999  HEADING 'Growth (bytes)'

BREAK ON report
COMPUTE SUM label '<font color="#990000"><b>Total:</b></font>' OF growth ON report

SELECT
    '<div align="left"><font color="#336699"><b>' || TO_CHAR(creation_time, 'RRRR-MM') || '</b></font></div>' month
  , SUM(bytes)                        growth
FROM     sys.v_$datafile
GROUP BY TO_CHAR(creation_time, 'RRRR-MM')
ORDER BY TO_CHAR(creation_time, 'RRRR-MM');

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - TABLESPACE EXTENTS -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="tablespace_extents"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tablespace Extents</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN tablespace_name                              HEADING 'Tablespace Name'         ENTMAP off
COLUMN largest_ext     FORMAT 999,999,999,999,999   HEADING 'Largest Extent'          ENTMAP off
COLUMN smallest_ext    FORMAT 999,999,999,999,999   HEADING 'Smallest Extent'         ENTMAP off
COLUMN total_free      FORMAT 999,999,999,999,999   HEADING 'Total Free'              ENTMAP off
COLUMN pieces          FORMAT 999,999,999,999,999   HEADING 'Number of Free Extents'  ENTMAP off

break on report
compute sum label '<font color="#990000"><b>Total:</b></font>' of largest_ext smallest_ext total_free pieces on report

SELECT 
    '<b><font color="#336699">' || tablespace_name || '</font></b>' tablespace_name
  , max(bytes)       largest_ext
  , min(bytes)       smallest_ext
  , sum(bytes)       total_free
  , count(*)         pieces
FROM
    dba_free_space
GROUP BY
    tablespace_name
ORDER BY
    tablespace_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - TABLESPACE TO OWNER  -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="tablespace_to_owner"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tablespace to Owner</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN tablespace_name  FORMAT a75                  HEADING 'Tablespace Name'  ENTMAP off
COLUMN owner            FORMAT a75                  HEADING 'Owner'            ENTMAP off
COLUMN segment_type     FORMAT a75                  HEADING 'Segment Type'     ENTMAP off
COLUMN bytes            FORMAT 999,999,999,999,999  HEADING 'Size (in Bytes)'  ENTMAP off
COLUMN seg_count        FORMAT 999,999,999,999      HEADING 'Segment Count'    ENTMAP off

BREAK ON report ON tablespace_name
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' of seg_count bytes ON report

SELECT
    '<font color="#336699"><b>' || tablespace_name || '</b></font>'  tablespace_name
  , '<div align="right">'       || owner           || '</div>'       owner
  , '<div align="right">'       || segment_type    || '</div>'       segment_type
  , sum(bytes)                                                       bytes
  , count(*)                                                         seg_count
FROM
    dba_segments
WHERE
		owner in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN'))
GROUP BY
    tablespace_name
  , owner
  , segment_type
ORDER BY
    tablespace_name
  , owner
  , segment_type;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                       - OWNER TO TABLESPACE -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="owner_to_tablespace"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Owner to Tablespace</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner            FORMAT a75                  HEADING 'Owner'            ENTMAP off
COLUMN tablespace_name  FORMAT a75                  HEADING 'Tablespace Name'  ENTMAP off
COLUMN segment_type     FORMAT a75                  HEADING 'Segment Type'     ENTMAP off
COLUMN bytes            FORMAT 999,999,999,999,999  HEADING 'Size (in Bytes)'  ENTMAP off
COLUMN seg_count        FORMAT 999,999,999,999      HEADING 'Segment Count'    ENTMAP off

break on report on owner
compute sum label '<font color="#990000"><b>Total: </b></font>' of seg_count bytes on report

SELECT
    '<font color="#336699"><b>'  || owner           || '</b></font>' owner
  , '<div align="right">'        || tablespace_name || '</div>'      tablespace_name
  , '<div align="right">'        || segment_type    || '</div>'      segment_type
  , sum(bytes)                                                       bytes
  , count(*)                                                         seg_count
FROM
    dba_segments
WHERE
		owner in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN'))
GROUP BY
    owner
  , tablespace_name
  , segment_type
ORDER BY
    owner
  , tablespace_name
  , segment_type;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>






-- +============================================================================+
-- |                                                                            |
-- |                   <<<<<     UNDO Segments     >>>>>                        |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>UNDO Segments</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                       - UNDO RETENTION PARAMETERS -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="undo_retention_parameters"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>UNDO Retention Parameters</b></font><hr align="left" width="460">

prompt <b>undo_retention is specified in minutes</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print   FORMAT a95    HEADING 'Instance Name'     ENTMAP off
COLUMN thread_number_print   FORMAT a95    HEADING 'Thread Number'     ENTMAP off
COLUMN name                  FORMAT a125   HEADING 'Name'              ENTMAP off
COLUMN value                               HEADING 'Value'             ENTMAP off

BREAK ON report ON instance_name_print ON thread_number_print

SELECT
    '<div align="center"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'        instance_name_print
  , '<div align="center">'                          || i.thread#       || '</div>'                   thread_number_print
  , '<div nowrap>'                                  || p.name          || '</div>'                   name
  , (CASE p.name
         WHEN 'undo_retention' THEN '<div nowrap align="right">' || TO_CHAR(TO_NUMBER(p.value)/60, '999,999,999,999,999') || '</div>'
     ELSE
         '<div nowrap align="right">' || p.value || '</div>'
     END)                                                                                            value
FROM
    gv$parameter p
  , gv$instance  i
WHERE
      p.inst_id = i.inst_id
  AND p.name LIKE 'undo%'
ORDER BY
    i.instance_name
  , p.name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                            - UNDO SEGMENTS -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="undo_segments"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>UNDO Segments</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name FORMAT a75              HEADING 'Instance Name'      ENTMAP off
COLUMN tablespace    FORMAT a85              HEADING 'Tablspace'          ENTMAP off
COLUMN roll_name                             HEADING 'UNDO Segment Name'  ENTMAP off
COLUMN in_extents                            HEADING 'Init/Next Extents'  ENTMAP off
COLUMN m_extents                             HEADING 'Min/Max Extents'    ENTMAP off
COLUMN status                                HEADING 'Status'             ENTMAP off
COLUMN wraps         FORMAT 999,999,999      HEADING 'Wraps'              ENTMAP off
COLUMN shrinks       FORMAT 999,999,999      HEADING 'Shrinks'            ENTMAP off
COLUMN opt           FORMAT 999,999,999,999  HEADING 'Opt. Size'          ENTMAP off
COLUMN bytes         FORMAT 999,999,999,999  HEADING 'Bytes'              ENTMAP off
COLUMN extents       FORMAT 999,999,999      HEADING 'Extents'            ENTMAP off

CLEAR COMPUTES BREAKS

BREAK ON report ON instance_name ON tablespace
-- COMPUTE sum LABEL '<font color="#990000"><b>Total:</b></font>' OF bytes extents shrinks wraps ON report

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - UNDO SEGMENT CONTENTION -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="undo_segment_contention"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>UNDO Segment Contention</b></font><hr align="left" width="460">

prompt <b>UNDO statistics from V$ROLLSTAT - (ordered by waits)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN roll_name                             HEADING 'UNDO Segment Name'   ENTMAP off
COLUMN gets             FORMAT 999,999,999   HEADING 'Gets'                ENTMAP off
COLUMN waits            FORMAT 999,999,999   HEADING 'Waits'               ENTMAP off
COLUMN immediate_misses FORMAT 999,999,999   HEADING 'Immediate Misses'    ENTMAP off
COLUMN hit_ratio                             HEADING 'Hit Ratio'           ENTMAP off

BREAK ON report
COMPUTE SUM label '<font color="#990000"><b>Total:</b></font>' OF gets waits ON report




prompt 
prompt <b>Wait statistics</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN class                  HEADING 'Class'    
COLUMN ratio                  HEADING 'Wait Ratio'       

SELECT
    '<font color="#336699"><b>' || w.class || '</b></font>'                            class
  , '<div align="right">' || TO_CHAR(ROUND(100*(w.count/SUM(s.value)),8)) || '%</div>' ratio
FROM
    v$waitstat  w
  , v$sysstat   s
WHERE
      w.class IN (  'system undo header'
                  , 'system undo block'
                  , 'undo header'
                  , 'undo block'
                 )
  AND s.name IN ('db block gets', 'consistent gets')
GROUP BY
    w.class
  , w.count;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - Undo Tablespace Size-                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Undo_tablespace_check"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Undo Tablespace Check</b></font><hr align="left" width="460">

prompt UNDO_RETENTION parameter should at least be equal to the            
prompt length of longest running query on a given database instance.
prompt When the columns UNXPSTEALCNT through EXPBLKREUCNT hold non-zero values, it is 
prompt an indication of space pressure. If the column SSOLDERRCNT is non-zero, then 
prompt UNDO_RETENTION is not properly set. If the column NOSPACEERRCNT is non-zero, 
prompt then there is a serious space problem.


select max(maxquerylen) maxquerylen,max(UNXPSTEALCNT) UNXPSTEALCNT,
 max(SSOLDERRCNT) SSOLDERRCNT,max(NOSPACEERRCNT ) NOSPACEERRCNT  from v$undostat;

declare 
  v_Min_Undo_Size NUMBER;
  v_Max_Undo_Size NUMBER;
  v_Setted_Undo_Size NUMBER;
  v_undo_retention number;
begin
   DBMS_OUTPUT.PUT_LINE('<table width="90%" border="1">');
   select ((ur * ( ups * dbs)) + (dbs*24))/1024/1024/1024 into v_Min_Undo_Size
   from (select min(TUNED_UNDORETENTION) ur from v$undostat ),
   (select (sum(undoblks)/sum(((end_time-begin_time)*86400))) as ups from v$undostat),
   (select block_size as dbs from dba_tablespaces where tablespace_name= 
   (select upper(value) from v$parameter where name='undo_tablespace'));   
   select  ((ur * ( ups * dbs)) + (dbs*24))/1024/1024/1024 
   into v_Max_Undo_Size
   from (select max(TUNED_UNDORETENTION) ur from v$undostat ),
   (select (sum(undoblks)/sum(((end_time-begin_time)*86400))) as ups from v$undostat),
   (select block_size as dbs from dba_tablespaces where tablespace_name= 
   (select upper(value) from v$parameter where name='undo_tablespace'));
   select ((ur * ( ups * dbs)) + (dbs*24))/1024/1024/1024
   into v_Setted_Undo_Size
   from (select value ur from v$parameter where name='undo_retention' ),
   (select (sum(undoblks)/sum(((end_time-begin_time)*86400))) as ups from v$undostat),
   (select block_size as dbs from dba_tablespaces where tablespace_name= 
   (select upper(value) from v$parameter where name='undo_tablespace'));
   select value into v_undo_retention
   from v$parameter where name ='undo_retention';
    DBMS_OUTPUT.PUT_LINE('<tr><td>Minimum Undo Suggested</td><td align="right">'
                            || TO_CHAR(round(v_Min_Undo_Size,2))
                            || ' GB</td><td align="right"></td></tr>' );
    DBMS_OUTPUT.PUT_LINE('<tr><td>Maximum Undo Suggested</td><td align="right">'
                            || TO_CHAR(round(v_Max_Undo_Size,2))
                            || ' GB</td><td align="right"></td></tr>' );
    DBMS_OUTPUT.PUT_LINE('<tr><td>Setted Undo Suggested</td><td align="right">'
                            || TO_CHAR(round(v_Setted_Undo_Size,2))
                            || ' GB</td><td align="right"></td></tr>' );
    DBMS_OUTPUT.PUT_LINE('<tr><td>Current Undo_Retention Value</td><td align="right">'
                            || TO_CHAR(v_undo_retention)
                            || ' Seconds</td><td align="right"></td></tr>' );                            
    DBMS_OUTPUT.PUT_LINE('</table>');
END;
/


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +============================================================================+
-- |                                                                            |
-- |                      <<<<<     BACKUPS     >>>>>                           |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Backups</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP JOBS -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Jobs</b></font><hr align="left" width="460">

prompt <b>Last 10 RMAN backup jobs</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN backup_name           FORMAT a130   HEADING 'Backup Name'          ENTMAP off
COLUMN start_time            FORMAT a75    HEADING 'Start Time'           ENTMAP off
COLUMN elapsed_time          FORMAT a75    HEADING 'Elapsed Time'         ENTMAP off
COLUMN status                              HEADING 'Status'               ENTMAP off
COLUMN input_type                          HEADING 'Input Type'           ENTMAP off
COLUMN output_device_type                  HEADING 'Output Devices'       ENTMAP off
COLUMN input_size                          HEADING 'Input Size'           ENTMAP off
COLUMN output_size                         HEADING 'Output Size'          ENTMAP off
COLUMN output_rate_per_sec                 HEADING 'Output Rate Per Sec'  ENTMAP off

SELECT
    '<div nowrap><b><font color="#336699">' || r.command_id                                   || '</font></b></div>'  backup_name
  , '<div nowrap align="right">'            || TO_CHAR(r.start_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , '<div nowrap align="right">'            || r.time_taken_display                           || '</div>'             elapsed_time
  , DECODE(   r.status
            , 'COMPLETED'
            , '<div align="center"><b><font color="darkgreen">' || r.status || '</font></b></div>'
            , 'RUNNING'
            , '<div align="center"><b><font color="#000099">'   || r.status || '</font></b></div>'
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || r.status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || r.status || '</font></b></div>'
    )                                                                                       status
  , r.input_type                                                                            input_type
  , r.output_device_type                                                                    output_device_type
  , '<div nowrap align="right">' || r.input_bytes_display           || '</div>'  input_size
  , '<div nowrap align="right">' || r.output_bytes_display          || '</div>'  output_size
  , '<div nowrap align="right">' || r.output_bytes_per_sec_display  || '</div>'  output_rate_per_sec
FROM
    (select
         command_id
       , start_time
       , time_taken_display
       , status
       , input_type
       , output_device_type
       , input_bytes_display
       , output_bytes_display
       , output_bytes_per_sec_display
     from v$rman_backup_job_details
     order by start_time DESC
    ) r
WHERE
    rownum < 11; 

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - RMAN CONFIGURATION -                           |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_configuration"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Configuration</b></font><hr align="left" width="460">

prompt <b>All non-default RMAN configuration settings</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name     FORMAT a130   HEADING 'Name'   ENTMAP off
COLUMN value                  HEADING 'Value'  ENTMAP off

SELECT
    '<div nowrap><b><font color="#336699">' || name || '</font></b></div>'   name
  , value
FROM
    v$rman_configuration
ORDER BY
    name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP SETS -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_sets"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Sets</b></font><hr align="left" width="460">

prompt <b>Available backup sets contained in the control file including available and expired backup sets</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN bs_key                 FORMAT a75                    HEADING 'BS Key'                 ENTMAP off
COLUMN backup_type            FORMAT a70                    HEADING 'Backup Type'            ENTMAP off
COLUMN device_type                                          HEADING 'Device Type'            ENTMAP off
COLUMN controlfile_included   FORMAT a30                    HEADING 'Controlfile Included?'  ENTMAP off
COLUMN spfile_included        FORMAT a30                    HEADING 'SPFILE Included?'       ENTMAP off
COLUMN incremental_level                                    HEADING 'Incremental Level'      ENTMAP off
COLUMN pieces                 FORMAT 999,999,999,999        HEADING '# of Pieces'            ENTMAP off
COLUMN start_time             FORMAT a75                    HEADING 'Start Time'             ENTMAP off
COLUMN completion_time        FORMAT a75                    HEADING 'End Time'               ENTMAP off
COLUMN elapsed_seconds        FORMAT 999,999,999,999,999    HEADING 'Elapsed Seconds'        ENTMAP off
COLUMN tag                                                  HEADING 'Tag'                    ENTMAP off
COLUMN block_size             FORMAT 999,999,999,999,999    HEADING 'Block Size'             ENTMAP off
COLUMN keep                   FORMAT a40                    HEADING 'Keep?'                  ENTMAP off
COLUMN keep_until             FORMAT a75                    HEADING 'Keep Until'             ENTMAP off
COLUMN keep_options           FORMAT a15                    HEADING 'Keep Options'           ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total:</b></font>' OF pieces elapsed_seconds ON report

SELECT
    '<div align="center"><font color="#336699"><b>' || bs.recid || '</b></font></div>'                        bs_key
  , DECODE(backup_type
           , 'L', '<div nowrap><font color="#990000">Archived Redo Logs</font></div>'
           , 'D', '<div nowrap><font color="#000099">Datafile Full Backup</font></div>'
           , 'I', '<div nowrap><font color="darkgreen">Incremental Backup</font></div>')                      backup_type
  , '<div nowrap align="right">' || device_type || '</div>'                                                   device_type
  , '<div align="center">' ||
    DECODE(bs.controlfile_included, 'NO', '-', bs.controlfile_included) || '</div>'                           controlfile_included
  , '<div align="center">' || NVL(sp.spfile_included, '-') || '</div>'                                        spfile_included
  , bs.incremental_level                                                                                      incremental_level
  , bs.pieces                                                                                                 pieces
  , '<div nowrap align="right">' || TO_CHAR(bs.start_time, 'mm/dd/yyyy HH24:MI:SS')      || '</div>'          start_time
  , '<div nowrap align="right">' || TO_CHAR(bs.completion_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'          completion_time
  , bs.elapsed_seconds                                                                                        elapsed_seconds
  , bp.tag                                                                                                    tag
  , bs.block_size                                                                                             block_size
  , '<div align="center">' || bs.keep || '</div>'                                                             keep
  , '<div nowrap align="right">' || NVL(TO_CHAR(bs.keep_until, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</div>'  keep_until
  , bs.keep_options                                                                                           keep_options
FROM
    v$backup_set                           bs
  , (select distinct
         set_stamp
       , set_count
       , tag
       , device_type
     from v$backup_piece
     where status in ('A', 'X'))           bp
 ,  (select distinct set_stamp, set_count, 'YES' spfile_included
     from v$backup_spfile)                 sp
WHERE
      bs.set_stamp = bp.set_stamp
  AND bs.set_count = bp.set_count
  AND bs.set_stamp = sp.set_stamp (+)
  AND bs.set_count = sp.set_count (+)
  AND bs.completion_time>=sysdate-31                     -- add to collect backup sets wtihin one month , 2009-6-16, Wzg
ORDER BY
    bs.recid;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                          - RMAN BACKUP PIECES -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_pieces"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Pieces</b></font><hr align="left" width="460">

prompt <b>Available backup pieces contained in the control file including available and expired backup sets</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN bs_key              FORMAT a75                     HEADING 'BS Key'            ENTMAP off
COLUMN piece#                                             HEADING 'Piece #'           ENTMAP off
COLUMN copy#                                              HEADING 'Copy #'            ENTMAP off
COLUMN bp_key                                             HEADING 'BP Key'            ENTMAP off
COLUMN status                                             HEADING 'Status'            ENTMAP off
COLUMN handle                                             HEADING 'Handle'            ENTMAP off
COLUMN start_time          FORMAT a75                     HEADING 'Start Time'        ENTMAP off
COLUMN completion_time     FORMAT a75                     HEADING 'End Time'          ENTMAP off
COLUMN elapsed_seconds     FORMAT 999,999,999,999,999     HEADING 'Elapsed Seconds'   ENTMAP off
COLUMN deleted             FORMAT a10                     HEADING 'Deleted?'          ENTMAP off

BREAK ON bs_key

SELECT
    '<div align="center"><font color="#336699"><b>' || bs.recid  || '</b></font></div>'                bs_key
  , bp.piece#                                                                                          piece#
  , bp.copy#                                                                                           copy#
  , bp.recid                                                                                           bp_key
  , DECODE(   status
            , 'A', '<div nowrap align="center"><font color="darkgreen"><b>Available</b></font></div>'
            , 'D', '<div nowrap align="center"><font color="#000099"><b>Deleted</b></font></div>'
            , 'X', '<div nowrap align="center"><font color="#990000"><b>Expired</b></font></div>')     status
  , handle                                                                                             handle
  , '<div nowrap align="right">' || TO_CHAR(bp.start_time, 'mm/dd/yyyy HH24:MI:SS')      || '</div>'   start_time
  , '<div nowrap align="right">' || TO_CHAR(bp.completion_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'   completion_time
  , bp.elapsed_seconds                                                                                 elapsed_seconds
FROM
    v$backup_set    bs
  , v$backup_piece  bp
WHERE
      bs.set_stamp = bp.set_stamp
  AND bs.set_count = bp.set_count
  AND bp.status IN ('A', 'X')
  AND bs.completion_time>=sysdate-31                     -- add to collect backup pieces wtihin one month , 2009-6-16, Wzg
ORDER BY
    bs.recid
  , piece#;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                       - RMAN BACKUP CONTROL FILES -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_control_files"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Control Files</b></font><hr align="left" width="460">

prompt <b>Available automatic control files within all available (and expired) backup sets</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN bs_key                 FORMAT a75                     HEADING 'BS Key'                 ENTMAP off
COLUMN piece#                                                HEADING 'Piece #'                ENTMAP off
COLUMN copy#                                                 HEADING 'Copy #'                 ENTMAP off
COLUMN bp_key                                                HEADING 'BP Key'                 ENTMAP off
COLUMN controlfile_included   FORMAT a75                     HEADING 'Controlfile Included?'  ENTMAP off
COLUMN status                                                HEADING 'Status'                 ENTMAP off
COLUMN handle                                                HEADING 'Handle'                 ENTMAP off
COLUMN start_time             FORMAT a40                     HEADING 'Start Time'             ENTMAP off
COLUMN completion_time        FORMAT a40                     HEADING 'End Time'               ENTMAP off
COLUMN elapsed_seconds        FORMAT 999,999,999,999,999     HEADING 'Elapsed Seconds'        ENTMAP off
COLUMN deleted                FORMAT a10                     HEADING 'Deleted?'               ENTMAP off

BREAK ON bs_key

SELECT
    '<div align="center"><font color="#336699"><b>' || bs.recid  || '</b></font></div>'             bs_key
  , bp.piece#                                                                                       piece#
  , bp.copy#                                                                                        copy#
  , bp.recid                                                                                        bp_key
  , '<div align="center"><font color="#663300"><b>'                      ||
    DECODE(bs.controlfile_included, 'NO', '-', bs.controlfile_included)  ||
    '</b></font></div>'                                                                             controlfile_included
  , DECODE(   status
            , 'A', '<div nowrap align="center"><font color="darkgreen"><b>Available</b></font></div>'
            , 'D', '<div nowrap align="center"><font color="#000099"><b>Deleted</b></font></div>'
            , 'X', '<div nowrap align="center"><font color="#990000"><b>Expired</b></font></div>')  status
  , handle                                                                                          handle
FROM
    v$backup_set    bs
  , v$backup_piece  bp
WHERE
      bs.set_stamp = bp.set_stamp
  AND bs.set_count = bp.set_count
  AND bp.status IN ('A', 'X')
  AND bs.controlfile_included != 'NO'
  AND bs.completion_time>=sysdate-31                     -- add to collect backup sets wtihin one month , 2009-6-16, Wzg
ORDER BY
    bs.recid
  , piece#;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP SPFILE -                           |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_spfile"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup SPFILE</b></font><hr align="left" width="460">

prompt <b>Available automatic SPFILE backups within all available (and expired) backup sets</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN bs_key                 FORMAT a75                     HEADING 'BS Key'                 ENTMAP off
COLUMN piece#                                                HEADING 'Piece #'                ENTMAP off
COLUMN copy#                                                 HEADING 'Copy #'                 ENTMAP off
COLUMN bp_key                                                HEADING 'BP Key'                 ENTMAP off
COLUMN spfile_included        FORMAT a75                     HEADING 'SPFILE Included?'       ENTMAP off
COLUMN status                                                HEADING 'Status'                 ENTMAP off
COLUMN handle                                                HEADING 'Handle'                 ENTMAP off
COLUMN start_time             FORMAT a40                     HEADING 'Start Time'             ENTMAP off
COLUMN completion_time        FORMAT a40                     HEADING 'End Time'               ENTMAP off
COLUMN elapsed_seconds        FORMAT 999,999,999,999,999     HEADING 'Elapsed Seconds'        ENTMAP off
COLUMN deleted                FORMAT a10                     HEADING 'Deleted?'               ENTMAP off

BREAK ON bs_key

SELECT
    '<div align="center"><font color="#336699"><b>' || bs.recid  || '</b></font></div>'             bs_key
  , bp.piece#                                                                                       piece#
  , bp.copy#                                                                                        copy#
  , bp.recid                                                                                        bp_key
  , '<div align="center"><font color="#663300"><b>'  ||
    NVL(sp.spfile_included, '-')                     ||
    '</b></font></div>'                                                                             spfile_included
  , DECODE(   status
            , 'A', '<div nowrap align="center"><font color="darkgreen"><b>Available</b></font></div>'
            , 'D', '<div nowrap align="center"><font color="#000099"><b>Deleted</b></font></div>'
            , 'X', '<div nowrap align="center"><font color="#990000"><b>Expired</b></font></div>')  status
  , handle                                                                                          handle
FROM
    v$backup_set                            bs
  , v$backup_piece                          bp
  ,  (select distinct set_stamp, set_count, 'YES' spfile_included
      from v$backup_spfile)                 sp
WHERE
      bs.set_stamp = bp.set_stamp
  AND bs.set_count = bp.set_count
  AND bp.status IN ('A', 'X')
  AND bs.set_stamp = sp.set_stamp
  AND bs.set_count = sp.set_count
ORDER BY
    bs.recid
  , piece#;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                      - archived log NOT backup -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Archived log NOT backup"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archived log NOT backup</b></font><hr align="left" width="460">
col status format A8

with t as (select max(bs.completion_time) maxtime
 FROM v$backup_set  bs
 where exists(select '1' from v$backup_piece bp 
                        where  bs.set_stamp = bp.set_stamp
                           and bs.set_count = bp.set_count
                           and bp.status in ('A', 'X')
              )
   and bs.completion_time>=sysdate-31 
   and bs.backup_type ='L') 
select thread#,
       sequence#,
       to_char(first_time,'yyyymmdd hh24:mi:ss') as first_time,
       status,
       deleted
from v$archived_log 
where (thread#,sequence#) in (
SELECT THREAD#,
       SEQUENCE#
  FROM V$ARCHIVED_LOG
  where first_time >= (select maxtime from t)
MINUS
SELECT THREAD#,
       SEQUENCE#
  FROM V$BACKUP_ARCHIVELOG_DETAILS )
 ;
 
 


-- +----------------------------------------------------------------------------+
-- |                             - ARCHIVING MODE -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="archiving_mode"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archiving Mode</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN db_log_mode                  FORMAT a95                HEADING 'Database|Log Mode'             ENTMAP off
COLUMN log_archive_start            FORMAT a95                HEADING 'Automatic|Archival'            ENTMAP off
COLUMN oldest_online_log_sequence   FORMAT 999999999999999    HEADING 'Oldest Online |Log Sequence'   ENTMAP off
COLUMN current_log_seq              FORMAT 999999999999999    HEADING 'Current |Log Sequence'         ENTMAP off

SELECT
    '<div align="center"><font color="#663300"><b>' || d.log_mode           || '</b></font></div>'    db_log_mode
  , '<div align="center"><font color="#663300"><b>' || p.log_archive_start  || '</b></font></div>'    log_archive_start
  , c.current_log_seq                                   current_log_seq
  , o.oldest_online_log_sequence                        oldest_online_log_sequence
FROM
    (select
         DECODE(   log_mode
                 , 'ARCHIVELOG', 'Archive Mode'
                 , 'NOARCHIVELOG', 'No Archive Mode'
                 , log_mode
         )   log_mode
     from v$database
    ) d
  , (select
         DECODE(   log_mode
                 , 'ARCHIVELOG', 'Enabled'
                 , 'NOARCHIVELOG', 'Disabled')   log_archive_start
     from v$database
    ) p
  , (select a.sequence#   current_log_seq
     from   v$log a
     where  a.status = 'CURRENT'
       and thread# = &_thread_number
    ) c
  , (select min(a.sequence#) oldest_online_log_sequence
     from   v$log a
     where  thread# = &_thread_number
    ) o
/


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                         - ARCHIVE DESTINATIONS -                           |
-- +----------------------------------------------------------------------------+

prompt <a name="archive_destinations"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archive Destinations</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN dest_id                                                HEADING 'Destination|ID'            ENTMAP off
COLUMN dest_name                                              HEADING 'Destination|Name'          ENTMAP off
COLUMN destination                                            HEADING 'Destination'               ENTMAP off
COLUMN status                                                 HEADING 'Status'                    ENTMAP off
COLUMN schedule                                               HEADING 'Schedule'                  ENTMAP off
COLUMN archiver                                               HEADING 'Archiver'                  ENTMAP off
COLUMN log_sequence                 FORMAT 999999999999999    HEADING 'Current Log|Sequence'      ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || a.dest_id || '</b></font></div>'    dest_id
  , a.dest_name                               dest_name
  , a.destination                             destination
  , DECODE(   a.status
            , 'VALID',    '<div align="center"><b><font color="darkgreen">' || status || '</font></b></div>'
            , 'INACTIVE', '<div align="center"><b><font color="#990000">'   || status || '</font></b></div>'
            ,             '<div align="center"><b><font color="#663300">'   || status || '</font></b></div>' ) status
  , DECODE(   a.schedule
            , 'ACTIVE',   '<div align="center"><b><font color="darkgreen">' || schedule || '</font></b></div>'
            , 'INACTIVE', '<div align="center"><b><font color="#990000">'   || schedule || '</font></b></div>'
            ,             '<div align="center"><b><font color="#663300">'   || schedule || '</font></b></div>' ) schedule
  , a.archiver                                archiver
  , a.log_sequence                            log_sequence
FROM
    v$archive_dest a
ORDER BY
    a.dest_id
/


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                    - ARCHIVING INSTANCE PARAMETERS -                       |
-- +----------------------------------------------------------------------------+

prompt <a name="archiving_instance_parameters"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archiving Instance Parameters</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name      HEADING 'Parameter Name'   ENTMAP off
COLUMN value     HEADING 'Parameter Value'  ENTMAP off

SELECT
    '<b><font color="#336699">' || a.name || '</font></b>'    name
  , a.value                                                   value
FROM
    v$parameter a
WHERE
    a.name like 'log_%'
ORDER BY
    a.name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - ARCHIVING HISTORY -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="archiving_history"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archiving History</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN thread#          FORMAT a79                   HEADING 'Thread#'           ENTMAP off
COLUMN sequence#        FORMAT a79                   HEADING 'Sequence#'         ENTMAP off
COLUMN name                                          HEADING 'Name'              ENTMAP off
COLUMN first_change#                                 HEADING 'First|Change #'    ENTMAP off
COLUMN first_time       FORMAT a75                   HEADING 'First|Time'        ENTMAP off
COLUMN next_change#                                  HEADING 'Next|Change #'     ENTMAP off
COLUMN next_time        FORMAT a75                   HEADING 'Next|Time'         ENTMAP off
COLUMN log_size         FORMAT 999,999,999,999,999   HEADING 'Size (in bytes)'   ENTMAP off
COLUMN archived         FORMAT a31                   HEADING 'Archived?'         ENTMAP off
COLUMN applied          FORMAT a31                   HEADING 'Applied?'          ENTMAP off
COLUMN deleted          FORMAT a31                   HEADING 'Deleted?'          ENTMAP off
COLUMN status           FORMAT a75                   HEADING 'Status'            ENTMAP off

BREAK ON report ON thread#

SELECT
    '<div align="center"><b><font color="#336699">' || thread#   || '</font></b></div>'  thread#
  , '<div align="center"><b><font color="#336699">' || sequence# || '</font></b></div>'  sequence#
  , name
  , first_change#
  , '<div align="right" nowrap>' || TO_CHAR(first_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>' first_time
  , next_change#
  , '<div align="right" nowrap>' || TO_CHAR(next_time, 'mm/dd/yyyy HH24:MI:SS')  || '</div>' next_time
  , (blocks * block_size)                            log_size
  , '<div align="center">' || archived || '</div>'  archived
  , '<div align="center">' || applied  || '</div>'  applied
  , '<div align="center">' || deleted  || '</div>'  deleted
  , DECODE(   status
            , 'A', '<div align="center"><b><font color="darkgreen">Available</font></b></div>'
            , 'D', '<div align="center"><b><font color="#663300">Deleted</font></b></div>'
            , 'U', '<div align="center"><b><font color="#990000">Unavailable</font></b></div>'
            , 'X', '<div align="center"><b><font color="#990000">Expired</font></b></div>'
    ) status
FROM
    v$archived_log
WHERE
    status in ('A')
AND trunc(sysdate-COMPLETION_TIME)<=3    
ORDER BY
    thread#
  , sequence#;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                     - FLASH RECOVERY AREA PARAMETERS -                     |
-- +----------------------------------------------------------------------------+

prompt <a name="flash_recovery_area_parameters"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Flash Recovery Area Parameters</b></font><hr align="left" width="460">

prompt <b>db_recovery_file_dest_size is specified in bytes</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print   FORMAT a95    HEADING 'Instance Name'     ENTMAP off
COLUMN thread_number_print   FORMAT a95    HEADING 'Thread Number'     ENTMAP off
COLUMN name                  FORMAT a125   HEADING 'Name'              ENTMAP off
COLUMN value                               HEADING 'Value'             ENTMAP off

BREAK ON report ON instance_name_print ON thread_number_print

SELECT
    '<div align="center"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'        instance_name_print
  , '<div align="center">'                          || i.thread#       || '</div>'                   thread_number_print
  , '<div nowrap>'                                  || p.name          || '</div>'                   name
  , (CASE p.name
         WHEN 'db_recovery_file_dest_size' THEN '<div nowrap align="right">' || TO_CHAR(p.value, '999,999,999,999,999') || '</div>'
     ELSE
         '<div nowrap align="right">' || NVL(p.value, '(null)') || '</div>'
     END)                                                                                            value
FROM
    gv$parameter p
  , gv$instance  i
WHERE
      p.inst_id = i.inst_id
  AND p.name IN ('db_recovery_file_dest_size', 'db_recovery_file_dest')
ORDER BY
    1
  , 3;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - FLASH RECOVERY AREA STATUS -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="flash_recovery_area_status"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Flash Recovery Area Status</b></font><hr align="left" width="460">

prompt <b>Current location, disk quota, space in use, space reclaimable by deleting files, and number of files in the Flash Recovery Area</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name               FORMAT a75                  HEADING 'Name'               ENTMAP off
COLUMN space_limit        FORMAT 99,999,999,999,999   HEADING 'Space Limit'        ENTMAP off
COLUMN space_used         FORMAT 99,999,999,999,999   HEADING 'Space Used'         ENTMAP off
COLUMN space_used_pct     FORMAT 999.99               HEADING '% Used'             ENTMAP off
COLUMN space_reclaimable  FORMAT 99,999,999,999,999   HEADING 'Space Reclaimable'  ENTMAP off
COLUMN pct_reclaimable    FORMAT 999.99               HEADING '% Reclaimable'      ENTMAP off
COLUMN number_of_files    FORMAT 999,999              HEADING 'Number of Files'    ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || name || '</b></font></div>'    name
  , space_limit                                                                       space_limit
  , space_used                                                                        space_used
  , ROUND((space_used / DECODE(space_limit, 0, 0.000001, space_limit))*100, 2)        space_used_pct
  , space_reclaimable                                                                 space_reclaimable
  , ROUND((space_reclaimable / DECODE(space_limit, 0, 0.000001, space_limit))*100, 2) pct_reclaimable
  , number_of_files                                                                   number_of_files
FROM
    v$recovery_file_dest
ORDER BY
    name;


CLEAR COLUMNS BREAKS COMPUTES

COLUMN file_type                  FORMAT a75     HEADING 'File Type'
COLUMN percent_space_used                        HEADING 'Percent Space Used'
COLUMN percent_space_reclaimable                 HEADING 'Percent Space Reclaimable'
COLUMN number_of_files            FORMAT 999,999 HEADING 'Number of Files'

SELECT
    '<div align="center"><font color="#336699"><b>' || file_type || '</b></font></div>' file_type
  , percent_space_used                                                                  percent_space_used
  , percent_space_reclaimable                                                           percent_space_reclaimable
  , number_of_files                                                                     number_of_files
FROM
    v$flash_recovery_area_usage;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>






-- +============================================================================+
-- |                                                                            |
-- |               <<<<<     FLASHBACK TECHNOLOGIES     >>>>>                   |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Flashback Technologies</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                     - FLASHBACK DATABASE PARAMETERS -                      |
-- +----------------------------------------------------------------------------+

prompt <a name="flashback_database_parameters"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Flashback Database Parameters</b></font><hr align="left" width="460">

prompt <b>db_flashback_retention_target is specified in minutes</b>
prompt <b>db_recovery_file_dest_size is specified in bytes</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print   FORMAT a95    HEADING 'Instance Name'     ENTMAP off
COLUMN thread_number_print   FORMAT a95    HEADING 'Thread Number'     ENTMAP off
COLUMN name                  FORMAT a125   HEADING 'Name'              ENTMAP off
COLUMN value                               HEADING 'Value'             ENTMAP off

BREAK ON report ON instance_name_print ON thread_number_print

SELECT
    '<div align="center"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'        instance_name_print
  , '<div align="center">'                          || i.thread#       || '</div>'                   thread_number_print
  , '<div nowrap>'                                  || p.name          || '</div>'                   name
  , (CASE p.name
         WHEN 'db_recovery_file_dest_size'    THEN '<div nowrap align="right">' || TO_CHAR(p.value, '999,999,999,999,999') || '</div>'
         WHEN 'db_flashback_retention_target' THEN '<div nowrap align="right">' || TO_CHAR(p.value, '999,999,999,999,999') || '</div>'
     ELSE
         '<div nowrap align="right">' || NVL(p.value, '(null)') || '</div>'
     END)                                                                                            value
FROM
    gv$parameter p
  , gv$instance  i
WHERE
      p.inst_id = i.inst_id
  AND p.name IN ('db_flashback_retention_target', 'db_recovery_file_dest_size', 'db_recovery_file_dest')
ORDER BY
    1
  , 3;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                       - FLASHBACK DATABASE STATUS -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="flashback_database_status"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Flashback Database Status</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN dbid                                HEADING 'DB ID'              ENTMAP off
COLUMN name             FORMAT A75         HEADING 'DB Name'            ENTMAP off
COLUMN log_mode         FORMAT A75         HEADING 'Log Mode'           ENTMAP off
COLUMN flashback_on     FORMAT A75         HEADING 'Flashback DB On?'   ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || dbid          || '</b></font></div>'  dbid
  , '<div align="center">'                          || name          || '</div>'             name
  , '<div align="center">'                          || log_mode      || '</div>'             log_mode
  , '<div align="center">'                          || flashback_on  || '</div>'             flashback_on
FROM v$database;

CLEAR COLUMNS BREAKS COMPUTES

COLUMN oldest_flashback_time    FORMAT a125               HEADING 'Oldest Flashback Time'     ENTMAP off
COLUMN oldest_flashback_scn                               HEADING 'Oldest Flashback SCN'      ENTMAP off
COLUMN retention_target         FORMAT 999,999            HEADING 'Retention Target (min)'    ENTMAP off
COLUMN retention_target_hours   FORMAT 999,999            HEADING 'Retention Target (hour)'   ENTMAP off
COLUMN flashback_size           FORMAT 9,999,999,999,999  HEADING 'Flashback Size'            ENTMAP off
COLUMN estimated_flashback_size FORMAT 9,999,999,999,999  HEADING 'Estimated Flashback Size'  ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || TO_CHAR(oldest_flashback_time,'mm/dd/yyyy HH24:MI:SS') || '</b></font></div>'  oldest_flashback_time
  , oldest_flashback_scn             oldest_flashback_scn
  , retention_target                 retention_target
  , retention_target/60              retention_target_hours
  , flashback_size                   flashback_size
  , estimated_flashback_size         estimated_flashback_size
FROM
    v$flashback_database_log
ORDER BY
    1;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                  - FLASHBACK DATABASE REDO TIME MATRIX -                   |
-- +----------------------------------------------------------------------------+

prompt <a name="flashback_database_redo_time_matrix"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Flashback Database Redo Time Matrix</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN begin_time               FORMAT a75                HEADING 'Begin Time'               ENTMAP off
COLUMN end_time                 FORMAT a75                HEADING 'End Time'                 ENTMAP off
COLUMN flashback_data           FORMAT 9,999,999,999,999  HEADING 'Flashback Data'           ENTMAP off
COLUMN db_data                  FORMAT 9,999,999,999,999  HEADING 'DB Data'                  ENTMAP off
COLUMN redo_data                FORMAT 9,999,999,999,999  HEADING 'Redo Data'                ENTMAP off
COLUMN estimated_flashback_size FORMAT 9,999,999,999,999  HEADING 'Estimated Flashback Size' ENTMAP off

SELECT
    '<div align="right">' || TO_CHAR(begin_time,'mm/dd/yyyy HH24:MI:SS') || '</div>'  begin_time
  , '<div align="right">' || TO_CHAR(end_time,'mm/dd/yyyy HH24:MI:SS') || '</div>'    end_time
  , flashback_data
  , db_data
  , redo_data
  , estimated_flashback_size
FROM
    v$flashback_database_stat
ORDER BY
   begin_time;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>






-- +============================================================================+
-- |                                                                            |
-- |                    <<<<<     PERFORMANCE     >>>>>                         |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Performance</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                             - SGA INFORMATION -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="sga_information"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Information</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name FORMAT a79                 HEADING 'Instance Name'    ENTMAP off
COLUMN name          FORMAT a150                HEADING 'Pool Name'        ENTMAP off
COLUMN value         FORMAT 999,999,999,999,999 HEADING 'Bytes'            ENTMAP off

BREAK ON report ON instance_name
COMPUTE sum LABEL '<font color="#990000"><b>Total:</b></font>' OF value ON instance_name

SELECT
    '<div align="left"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'  instance_name
  , '<div align="left"><font color="#336699"><b>' || s.name          || '</b></font></div>'  name
  , s.value                                                                                  value
FROM
    gv$sga       s
  , gv$instance  i
WHERE
    s.inst_id = i.inst_id
ORDER BY
    i.instance_name
  , s.value DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - SGA TARGET ADVICE -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="sga_target_advice"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Target Advice</b></font><hr align="left" width="460">

prompt Modify the SGA_TARGET parameter (up to the size of the SGA_MAX_SIZE, if necessary) to reduce
prompt the number of "Estimated Physical Reads".

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name FORMAT a79     HEADING 'Instance Name'    ENTMAP off
COLUMN name          FORMAT a79     HEADING 'Parameter Name'   ENTMAP off
COLUMN value         FORMAT a79     HEADING 'Value'            ENTMAP off

BREAK ON report ON instance_name

SELECT
    '<div align="left"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'  instance_name
  , p.name    name
  , (CASE p.name
         WHEN 'sga_max_size' THEN '<div align="right">' || TO_CHAR(p.value, '999,999,999,999,999') || '</div>'
         WHEN 'sga_target'   THEN '<div align="right">' || TO_CHAR(p.value, '999,999,999,999,999') || '</div>'
     ELSE
         '<div align="right">' || p.value || '</div>'
     END) value
FROM
    gv$parameter p
  , gv$instance  i
WHERE
      p.inst_id = i.inst_id
  AND p.name IN ('sga_max_size', 'sga_target')
ORDER BY
    i.instance_name
  , p.name;



CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name         FORMAT a79                   HEADING 'Instance Name'              ENTMAP off
COLUMN sga_size              FORMAT 999,999,999,999,999   HEADING 'SGA Size'                   ENTMAP off
COLUMN sga_size_factor       FORMAT 999,999,999,999,999   HEADING 'SGA Size Factor'            ENTMAP off
COLUMN estd_db_time          FORMAT 999,999,999,999,999   HEADING 'Estimated DB Time'          ENTMAP off
COLUMN estd_db_time_factor   FORMAT 999,999,999,999,999   HEADING 'Estimated DB Time Factor'   ENTMAP off
COLUMN estd_physical_reads   FORMAT 999,999,999,999,999   HEADING 'Estimated Physical Reads'   ENTMAP off

BREAK ON report ON instance_name

SELECT
    '<div align="left"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'  instance_name
  , s.sga_size
  , s.sga_size_factor
  , s.estd_db_time
  , s.estd_db_time_factor
  , s.estd_physical_reads
FROM
    gv$sga_target_advice s
  , gv$instance  i
WHERE
    s.inst_id = i.inst_id
ORDER BY
    i.instance_name
  , s.sga_size_factor;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - SGA (ASMM) DYNAMIC COMPONENTS -                     |
-- +----------------------------------------------------------------------------+

prompt <a name="sga_asmm_dynamic_components"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA (ASMM) Dynamic Components</b></font><hr align="left" width="460">

prompt Provides a summary report of all dynamic components as part of the Automatic Shared Memory
prompt Management (ASMM) configuration. This will display the total real memory allocation for the current
prompt SGA from the V$SGA_DYNAMIC_COMPONENTS view, which contains both manual and autotuned SGA components.
prompt As with the other manageability features of Oracle Database 10g, ASMM requires you to set the 
prompt STATISTICS_LEVEL parameter to at least TYPICAL (the default) before attempting to enable ASMM. ASMM
prompt can be enabled by setting SGA_TARGET to a nonzero value in the initialization parameter file (pfile/spfile).

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name         FORMAT a79                HEADING 'Instance Name'        ENTMAP off
COLUMN component             FORMAT a79                HEADING 'Component Name'       ENTMAP off
COLUMN current_size          FORMAT 999,999,999,999    HEADING 'Current Size'         ENTMAP off
COLUMN min_size              FORMAT 999,999,999,999    HEADING 'Min Size'             ENTMAP off
COLUMN max_size              FORMAT 999,999,999,999    HEADING 'Max Size'             ENTMAP off
COLUMN user_specified_size   FORMAT 999,999,999,999    HEADING 'User Specified|Size'  ENTMAP off
COLUMN oper_count            FORMAT 999,999,999,999    HEADING 'Oper.|Count'          ENTMAP off
COLUMN last_oper_type        FORMAT a75                HEADING 'Last Oper.|Type'      ENTMAP off
COLUMN last_oper_mode        FORMAT a75                HEADING 'Last Oper.|Mode'      ENTMAP off
COLUMN last_oper_time        FORMAT a75                HEADING 'Last Oper.|Time'      ENTMAP off
COLUMN granule_size          FORMAT 999,999,999,999    HEADING 'Granule Size'         ENTMAP off

BREAK ON report ON instance_name

SELECT
    '<div align="left"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'  instance_name
  , sdc.component
  , sdc.current_size
  , sdc.min_size
  , sdc.max_size
  , sdc.user_specified_size
  , sdc.oper_count
  , sdc.last_oper_type
  , sdc.last_oper_mode
  , '<div align="right">' || NVL(TO_CHAR(sdc.last_oper_time, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</div>'   last_oper_time
  , sdc.granule_size
FROM
    gv$sga_dynamic_components sdc
  , gv$instance  i
ORDER BY
    i.instance_name
  , sdc.component DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - PGA TARGET ADVICE -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="pga_target_advice"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>PGA Target Advice</b></font><hr align="left" width="460">

prompt The <b>V$PGA_TARGET_ADVICE</b> view predicts how the statistics cache hit percentage and over
prompt allocation count in V$PGASTAT will be impacted if you change the value of the
prompt initialization parameter PGA_AGGREGATE_TARGET. When you set the PGA_AGGREGATE_TARGET and
prompt WORKAREA_SIZE_POLICY to <b>AUTO</b> then the *_AREA_SIZE parameter are automatically ignored and
prompt Oracle will automatically use the computed value for these parameters. Use the results from
prompt the query below to adequately set the initialization parameter PGA_AGGREGATE_TARGET as to avoid
prompt any over allocation. If column ESTD_OVERALLOCATION_COUNT in the V$PGA_TARGET_ADVICE
prompt view (below) is nonzero, it indicates that PGA_AGGREGATE_TARGET is too small to even
prompt meet the minimum PGA memory needs. If PGA_AGGREGATE_TARGET is set within the over
prompt allocation zone, the memory manager will over-allocate memory and actual PGA memory
prompt consumed will be more than the limit you set. It is therefore meaningless to set a
prompt value of PGA_AGGREGATE_TARGET in that zone. After eliminating over-allocations, the
prompt goal is to maximize the PGA cache hit percentage, based on your response-time requirement
prompt and memory constraints.

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name FORMAT a79     HEADING 'Instance Name'    ENTMAP off
COLUMN name          FORMAT a79     HEADING 'Parameter Name'   ENTMAP off
COLUMN value         FORMAT a79     HEADING 'Value'            ENTMAP off

BREAK ON report ON instance_name

SELECT
    '<div align="left"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'  instance_name
  , p.name    name
  , (CASE p.name
         WHEN 'pga_aggregate_target' THEN '<div align="right">' || TO_CHAR(p.value, '999,999,999,999,999') || '</div>'
     ELSE
         '<div align="right">' || p.value || '</div>'
     END) value
FROM
    gv$parameter p
  , gv$instance  i
WHERE
      p.inst_id = i.inst_id
  AND p.name IN ('pga_aggregate_target', 'workarea_size_policy')
ORDER BY
    i.instance_name
  , p.name;



CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name                  FORMAT a79                   HEADING 'Instance Name'               ENTMAP off
COLUMN pga_target_for_estimate        FORMAT 999,999,999,999,999   HEADING 'PGA Target for Estimate'     ENTMAP off
COLUMN estd_extra_bytes_rw            FORMAT 999,999,999,999,999   HEADING 'Estimated Extra Bytes R/W'   ENTMAP off
COLUMN estd_pga_cache_hit_percentage  FORMAT 999,999,999,999,999   HEADING 'Estimated PGA Cache Hit %'   ENTMAP off
COLUMN estd_overalloc_count           FORMAT 999,999,999,999,999   HEADING 'ESTD_OVERALLOC_COUNT'        ENTMAP off

BREAK ON report ON instance_name

SELECT
    '<div align="left"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'  instance_name
  , p.pga_target_for_estimate
  , p.estd_extra_bytes_rw
  , p.estd_pga_cache_hit_percentage
  , p.estd_overalloc_count
FROM
    gv$pga_target_advice p
  , gv$instance  i
WHERE
    p.inst_id = i.inst_id
ORDER BY
    i.instance_name
  , p.pga_target_for_estimate;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

prompt <a name="pga_session"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>PGA Advice for Individual session</b></font><hr align="left" width="460">
CLEAR COLUMNS BREAKS COMPUTES



SELECT NAME,round(value/1024/1024) value_M      from v$pgastat
where name like '%PGA allo%'
or name like '%PGA target%';

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


prompt <a name="sql_workarea_histogram"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SQl workarea Histogram</b></font><hr align="left" width="460">
CLEAR COLUMNS BREAKS COMPUTES

select swh.MULTIPASSES_EXECUTIONS,swh.LOW_OPTIMAL_SIZE,swh.HIGH_OPTIMAL_SIZE 
from v$sql_workarea_histogram swh 
where swh.MULTIPASSES_EXECUTIONS>0 
order by 1 desc;



prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


-- +----------------------------------------------------------------------------+
-- |                         - FILE I/O STATISTICS -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="file_io_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>File I/O Statistics</b></font><hr align="left" width="460">

prompt <b>Ordered by "Physical Reads" since last startup of the Oracle instance</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN tablespace_name   FORMAT a50                   HEAD 'Tablespace'       ENTMAP off
COLUMN fname                                          HEAD 'File Name'        ENTMAP off
COLUMN phyrds            FORMAT 999,999,999,999,999   HEAD 'Physical Reads'   ENTMAP off
COLUMN phywrts           FORMAT 999,999,999,999,999   HEAD 'Physical Writes'  ENTMAP off
COLUMN read_pct                                       HEAD 'Read Pct.'        ENTMAP off
COLUMN write_pct                                      HEAD 'Write Pct.'       ENTMAP off
COLUMN total_io          FORMAT 999,999,999,999,999   HEAD 'Total I/O'        ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF phyrds phywrts total_io ON report

SELECT
    '<font color="#336699"><b>' || df.tablespace_name || '</b></font>'                      tablespace_name
  , df.file_name                             fname
  , fs.phyrds                                phyrds
  , '<div align="right">' || ROUND((fs.phyrds * 100) / (fst.pr + tst.pr), 2) || '%</div>'   read_pct
  , fs.phywrts                               phywrts
  , '<div align="right">' || ROUND((fs.phywrts * 100) / (fst.pw + tst.pw), 2) || '%</div>'   write_pct
  , (fs.phyrds + fs.phywrts)                 total_io
FROM
    sys.dba_data_files df
  , v$filestat         fs
  , (select sum(f.phyrds) pr, sum(f.phywrts) pw from v$filestat f) fst
  , (select sum(t.phyrds) pr, sum(t.phywrts) pw from v$tempstat t) tst
WHERE
    df.file_id = fs.file#
UNION ALL
SELECT
    '<font color="#336699"><b>' || tf.tablespace_name || '</b></font>'                     tablespace_name
  , tf.file_name                           fname
  , ts.phyrds                              phyrds
  , '<div align="right">' || ROUND((ts.phyrds * 100) / (fst.pr + tst.pr), 2) || '%</div>'  read_pct
  , ts.phywrts                             phywrts
  , '<div align="right">' || ROUND((ts.phywrts * 100) / (fst.pw + tst.pw), 2) || '%</div>' write_pct
  , (ts.phyrds + ts.phywrts)                 total_io
FROM
    sys.dba_temp_files  tf
  , v$tempstat          ts
  , (select sum(f.phyrds) pr, sum(f.phywrts) pw from v$filestat f) fst
  , (select sum(t.phyrds) pr, sum(t.phywrts) pw from v$tempstat t) tst
WHERE
    tf.file_id = ts.file#
ORDER BY phyrds DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - FILE I/O TIMINGS -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="file_io_timings"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>File I/O Timings</b></font><hr align="left" width="460">

prompt <b>Average time (in milliseconds) for an I/O call per datafile since last startup of the Oracle instance - (ordered by Physical Reads)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN fname                                           HEAD 'File Name'                                      ENTMAP off
COLUMN phyrds            FORMAT 999,999,999,999,999    HEAD 'Physical Reads'                                 ENTMAP off
COLUMN read_rate         FORMAT 999,999,999,999,999.99 HEAD 'Average Read Time<br>(milliseconds per read)'   ENTMAP off
COLUMN phywrts           FORMAT 999,999,999,999,999    HEAD 'Physical Writes'                                ENTMAP off
COLUMN write_rate        FORMAT 999,999,999,999,999.99 HEAD 'Average Write Time<br>(milliseconds per write)' ENTMAP off

BREAK ON REPORT
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF phyrds phywrts ON report
COMPUTE avg LABEL '<font color="#990000"><b>Average: </b></font>' OF read_rate write_rate ON report

SELECT
    '<b><font color="#336699">' || d.name || '</font></b>'  fname
  , s.phyrds                                     phyrds
  , ROUND((s.readtim/GREATEST(s.phyrds,1)), 2)   read_rate
  , s.phywrts                                    phywrts
  , ROUND((s.writetim/GREATEST(s.phywrts,1)),2)  write_rate
FROM
    v$filestat  s
  , v$datafile  d
WHERE
  s.file# = d.file#
UNION ALL
SELECT
    '<b><font color="#336699">' || t.name || '</font></b>'  fname
  , s.phyrds                                     phyrds
  , ROUND((s.readtim/GREATEST(s.phyrds,1)), 2)   read_rate
  , s.phywrts                                    phywrts
  , ROUND((s.writetim/GREATEST(s.phywrts,1)),2)  write_rate
FROM
    v$tempstat  s
  , v$tempfile  t
WHERE
  s.file# = t.file#
ORDER BY
    2 DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                    - AVERAGE OVERALL I/O PER SECOND -                      |
-- +----------------------------------------------------------------------------+

prompt <a name="average_overall_io_per_sec"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Average Overall I/O per Second</b></font><hr align="left" width="460">

prompt <b>Average overall I/O calls (physical read/write calls) since last startup of the Oracle instance</b>

CLEAR COLUMNS BREAKS COMPUTES

DECLARE

CURSOR get_file_io IS
  SELECT
      NVL(SUM(a.phyrds + a.phywrts), 0)  sum_datafile_io
    , TO_NUMBER(null)                    sum_tempfile_io
  FROM
      v$filestat a
  UNION ALL
  SELECT
      TO_NUMBER(null)                    sum_datafile_io
    , NVL(SUM(b.phyrds + b.phywrts), 0)  sum_tempfile_io
  FROM
      v$tempstat b;

current_time           DATE;
elapsed_time_seconds   NUMBER;
sum_datafile_io        NUMBER;
sum_datafile_io2       NUMBER;
sum_tempfile_io        NUMBER;
sum_tempfile_io2       NUMBER;
total_io               NUMBER;
datafile_io_per_sec    NUMBER;
tempfile_io_per_sec    NUMBER;
total_io_per_sec       NUMBER;

BEGIN
    OPEN get_file_io;
    FOR i IN 1..2 LOOP
      FETCH get_file_io INTO sum_datafile_io, sum_tempfile_io;
      IF i = 1 THEN
        sum_datafile_io2 := sum_datafile_io;
      ELSE
        sum_tempfile_io2 := sum_tempfile_io;
      END IF;
    END LOOP;

    total_io := sum_datafile_io2 + sum_tempfile_io2;
    SELECT sysdate INTO current_time FROM dual;
    SELECT CEIL ((current_time - startup_time)*(60*60*24)) INTO elapsed_time_seconds FROM v$instance;

    datafile_io_per_sec := sum_datafile_io2/elapsed_time_seconds;
    tempfile_io_per_sec := sum_tempfile_io2/elapsed_time_seconds;
    total_io_per_sec    := total_io/elapsed_time_seconds;

    DBMS_OUTPUT.PUT_LINE('<table width="90%" border="1">');

    DBMS_OUTPUT.PUT_LINE('<tr><th align="left" width="20%">Elapsed Time (in seconds)</th><td width="80%">' || TO_CHAR(elapsed_time_seconds, '9,999,999,999,999') || '</td></tr>');
    DBMS_OUTPUT.PUT_LINE('<tr><th align="left" width="20%">Datafile I/O Calls per Second</th><td width="80%">' || TO_CHAR(datafile_io_per_sec, '9,999,999,999,999') || '</td></tr>');
    DBMS_OUTPUT.PUT_LINE('<tr><th align="left" width="20%">Tempfile I/O Calls per Second</th><td width="80%">' || TO_CHAR(tempfile_io_per_sec, '9,999,999,999,999') || '</td></tr>');
    DBMS_OUTPUT.PUT_LINE('<tr><th align="left" width="20%">Total I/O Calls per Second</th><td width="80%">' || TO_CHAR(total_io_per_sec, '9,999,999,999,999') || '</td></tr>');

    DBMS_OUTPUT.PUT_LINE('</table>');
END;
/

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - REDO LOG CONTENTION -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="redo_log_contention"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Redo Log Contention</b></font><hr align="left" width="460">

prompt <b>All latches like redo% - (ordered by misses)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name             FORMAT a95                        HEADING 'Latch Name'
COLUMN gets             FORMAT 999,999,999,999,999,999    HEADING 'Gets'
COLUMN misses           FORMAT 999,999,999,999            HEADING 'Misses'
COLUMN sleeps           FORMAT 999,999,999,999            HEADING 'Sleeps'
COLUMN immediate_gets   FORMAT 999,999,999,999,999,999    HEADING 'Immediate Gets'
COLUMN immediate_misses FORMAT 999,999,999,999            HEADING 'Immediate Misses'

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total:</b></font>' OF gets misses sleeps immediate_gets immediate_misses ON report

SELECT 
    '<div align="left"><font color="#336699"><b>' || INITCAP(name) || '</b></font></div>' name
  , gets
  , misses
  , sleeps
  , immediate_gets
  , immediate_misses
FROM sys.v_$latch
WHERE name LIKE 'redo%'
ORDER BY 1;


prompt 
prompt <b>System statistics like redo%</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name    FORMAT a95                   HEADING 'Statistics Name'
COLUMN value   FORMAT 999,999,999,999,999   HEADING 'Value'

SELECT
    '<div align="left"><font color="#336699"><b>' || INITCAP(name) || '</b></font></div>' name
  , value
FROM v$sysstat
WHERE name LIKE 'redo%'
ORDER BY 1;

prompt 
prompt <b>redo buffer allocation retries</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name    FORMAT a95                   HEADING 'Statistics Name'
COLUMN value   FORMAT 999,999,999,999,999   HEADING 'Value'

SELECT
    '<div align="left"><font color="#336699"><b>' || INITCAP(name) || '</b></font></div>' name
  , value
FROM v$sysstat
WHERE upper(NAME) = 'REDO BUFFER ALLOCATION RETRIES'
;

prompt 
prompt <b>redo log space requests</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name    FORMAT a95                   HEADING 'Statistics Name'
COLUMN value   FORMAT 999,999,999,999,999   HEADING 'Value'

SELECT
    '<div align="left"><font color="#336699"><b>' || INITCAP(name) || '</b></font></div>' name
  , value
FROM v$sysstat
WHERE name='redo log space requests'
;

prompt 
prompt <b>redo log buffer retry ratio</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name    FORMAT a95                   HEADING 'Statistics Name'
COLUMN value   FORMAT 999,999,999,999,999   HEADING 'Value'

select retries.value/entries.value "Redo Log Buffer Retry Ratio"
from v$sysstat retries,v$sysstat entries
where retries.name='redo buffer allocation retries' and
entries.name='redo entries';


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - FULL TABLE SCANS -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="full_table_scans"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Full Table Scans</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN large_table_scans   FORMAT 999,999,999,999,999  HEADING 'Large Table Scans'   ENTMAP off
COLUMN small_table_scans   FORMAT 999,999,999,999,999  HEADING 'Small Table Scans'   ENTMAP off
COLUMN pct_large_scans                                 HEADING 'Pct. Large Scans'    ENTMAP off

SELECT
    a.value large_table_scans
  , b.value small_table_scans
  , '<div align="right">' || ROUND(100*a.value/DECODE((a.value+b.value),0,1,(a.value+b.value)),2) || '%</div>' pct_large_scans
FROM
    v$sysstat  a
  , v$sysstat  b
WHERE
      a.name = 'table scans (long tables)'
  AND b.name = 'table scans (short tables)';

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                                - SORTS -                                   |
-- +----------------------------------------------------------------------------+

prompt <a name="sorts"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sorts</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN disk_sorts     FORMAT 999,999,999,999,999    HEADING 'Disk Sorts'       ENTMAP off
COLUMN memory_sorts   FORMAT 999,999,999,999,999    HEADING 'Memory Sorts'     ENTMAP off
COLUMN pct_disk_sorts                               HEADING 'Pct. Disk Sorts'  ENTMAP off

SELECT
    a.value   disk_sorts
  , b.value   memory_sorts
  , '<div align="right">' || ROUND(100*a.value/DECODE((a.value+b.value),0,1,(a.value+b.value)),2) || '%</div>' pct_disk_sorts
FROM
    v$sysstat  a
  , v$sysstat  b
WHERE
      a.name = 'sorts (disk)'
  AND b.name = 'sorts (memory)';

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                               - OUTLINES -                                 |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_outlines"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Outlines</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN category       FORMAT a125    HEADING 'Category'     ENTMAP off
COLUMN owner          FORMAT a125    HEADING 'Owner'        ENTMAP off
COLUMN name           FORMAT a125    HEADING 'Name'         ENTMAP off
COLUMN used                          HEADING 'Used?'        ENTMAP off
COLUMN timestamp      FORMAT a125    HEADING 'Time Stamp'   ENTMAP off
COLUMN version                       HEADING 'Version'      ENTMAP off
COLUMN sql_text                      HEADING 'SQL Text'     ENTMAP off

SELECT
    '<div nowrap><font color="#336699"><b>' || category || '</b></font></div>' category
  , owner
  , name
  , used
  , '<div nowrap align="right">' || TO_CHAR(timestamp, 'mm/dd/yyyy HH24:MI:SS') || '</div>' timestamp
  , version
  , sql_text
FROM
    dba_outlines
ORDER BY
    category
  , owner
  , name;
  
prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                            - OUTLINE HINTS -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_outline_hints"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Outline Hints</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN category       FORMAT a125    HEADING 'Category'        ENTMAP off
COLUMN owner          FORMAT a125    HEADING 'Owner'           ENTMAP off
COLUMN name           FORMAT a125    HEADING 'Name'            ENTMAP off
COLUMN node                          HEADING 'Node'            ENTMAP off
COLUMN join_pos                      HEADING 'Join Position'   ENTMAP off
COLUMN hint                          HEADING 'Hint'            ENTMAP off

BREAK ON category ON owner ON name

SELECT
    '<div nowrap><font color="#336699"><b>' || a.category || '</b></font></div>' category
  , a.owner                                           owner
  , a.name                                            name
  , '<div align="center">' || b.node || '</div>'      node
  , '<div align="center">' || b.join_pos || '</div>'  join_pos
  , b.hint                                            hint
FROM
    dba_outlines       a
  , dba_outline_hints  b
WHERE
      a.owner = b.owner
  AND b.name  = b.name
ORDER BY
    category
  , owner
  , name;
  
prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                - SQL STATEMENTS WITH MOST BUFFER GETS -                    |
-- +----------------------------------------------------------------------------+

prompt <a name="sql_statements_with_most_buffer_gets"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SQL Statements With Most Buffer Gets</b></font><hr align="left" width="460">

prompt <b>Top 20 SQL statements with buffer gets greater than 1000</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN username        FORMAT a75                   HEADING 'Username'                 ENTMAP off
COLUMN buffer_gets     FORMAT 999,999,999,999,999   HEADING 'Buffer Gets'              ENTMAP off
COLUMN executions      FORMAT 999,999,999,999,999   HEADING 'Executions'               ENTMAP off
COLUMN gets_per_exec   FORMAT 999,999,999,999,999   HEADING 'Buffer Gets / Execution'  ENTMAP off
COLUMN sql_text                                     HEADING 'SQL Text'                 ENTMAP off

SELECT 
  a.buffer_gets              buffer_gets 
  , a.executions               executions 
  , (a.buffer_gets / decode(a.executions, 0, 1, a.executions))  gets_per_exec 
  , a.sql_text                 sql_text 
FROM 
    (SELECT ai.buffer_gets, ai.executions, ai.sql_text  
     FROM sys.v$sqlstats ai 
     ORDER BY ai.buffer_gets 
    ) a 
WHERE 
  a.buffer_gets > 1000 
  AND rownum < 21 
ORDER BY 
    a.buffer_gets DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                 - SQL STATEMENTS WITH MOST DISK READS -                    |
-- +----------------------------------------------------------------------------+

prompt <a name="sql_statements_with_most_disk_reads"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SQL Statements With Most Disk Reads</b></font><hr align="left" width="460">

prompt <b>Top 20 SQL statements with disk reads greater than 1000</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN username        FORMAT a75                   HEADING 'Username'           ENTMAP off
COLUMN disk_reads      FORMAT 999,999,999,999,999   HEADING 'Disk Reads'         ENTMAP off
COLUMN executions      FORMAT 999,999,999,999,999   HEADING 'Executions'         ENTMAP off
COLUMN reads_per_exec  FORMAT 999,999,999,999,999   HEADING 'Reads / Execution'  ENTMAP off
COLUMN sql_text                                     HEADING 'SQL Text'           ENTMAP off

SELECT  
  a.disk_reads       disk_reads 
  , a.executions       executions 
  , (a.disk_reads / decode(a.executions, 0, 1, a.executions))  reads_per_exec 
  , a.sql_text         sql_text  
FROM  
    (SELECT ai.disk_reads, ai.executions, ai.sql_text 
     FROM sys.v$sqlstats ai 
     ORDER BY ai.buffer_gets 
    ) a 
WHERE 
  a.disk_reads > 1000 
  AND rownum < 21 
ORDER BY
    a.disk_reads DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                      - DB BUFFER CACHE HIT RATIO -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="db_buffer_cache_hit_ratio"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>DB Buffer Cache Hit Ratio</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN consistent_gets   FORMAT 999,999,999,999,999,999   HEADING 'Consistent Gets'  ENTMAP off
COLUMN db_block_gets     FORMAT 999,999,999,999,999,999   HEADING 'DB Block Gets'    ENTMAP off
COLUMN phys_reads        FORMAT 999,999,999,999,999,999   HEADING 'Physical Reads'   ENTMAP off
COLUMN db_hit_ratio                                       HEADING 'Hit Ratio'        ENTMAP off

SELECT
    SUM(DECODE(name, 'consistent gets', value, 0))   consistent_gets
  , SUM(DECODE(name, 'db block gets', value, 0))     db_block_gets
  , SUM(DECODE(name, 'physical reads', value, 0))    phys_reads
  , '<div align="right">' ||
    TO_CHAR(ROUND((SUM(DECODE(name, 'consistent gets', value, 0)) +
                       SUM(DECODE(name, 'db block gets', value, 0)) -
                       SUM(DECODE(name, 'physical reads', value, 0))) /
                      (SUM(DECODE(name, 'consistent gets', value, 0)) +
                       SUM(DECODE(name, 'db block gets', value, 0)))*100, 2))  ||
    '%</div>'   db_hit_ratio
FROM v$sysstat;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - DICTIONARY CACHE HIT RATIO -                        |
-- +----------------------------------------------------------------------------+

prompt <a name="dictionary_cache_hit_ratio"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Dictionary Cache Hit Ratio</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN gets          FORMAT 999,999,999,999,999,999  HEADING 'Misses'       ENTMAP off
COLUMN misses        FORMAT 999,999,999,999,999,999  HEADING 'Gets'         ENTMAP off
COLUMN dc_hit_ratio                                  HEADING 'Hit Ratio'    ENTMAP off

SELECT
    SUM(gets)       gets
  , SUM(getmisses)  misses
  , '<div align="right">' ||
    TO_CHAR(ROUND((((SUM(gets)-SUM(getmisses))/SUM(gets))*100), 2)) ||
    '%</div>'       dc_hit_ratio
FROM
    v$rowcache;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - LIBRARY CACHE HIT RATIO -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="library_cache_hit_ratio"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Library Cache Hit Ratio</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN pins            FORMAT 999,999,999,999,999,999  HEADING 'Pins - (Executions)'      ENTMAP off
COLUMN reloads         FORMAT 999,999,999,999,999,999  HEADING 'Reloads - (Cache Miss)'   ENTMAP off
COLUMN lc_hit_ratio                                    HEADING 'Hit Ratio'                ENTMAP off 

SELECT
    SUM(pins)      pins
  , SUM(reloads)   reloads
  , '<div align="right">' ||
    TO_CHAR(ROUND((((SUM(pins)-SUM(reloads))/SUM(pins))*100),2)) ||
    '%</div>'      lc_hit_ratio
FROM
    v$librarycache;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                            - LATCH CONTENTION -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="latch_contention"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Latch Contention</b></font><hr align="left" width="460">

prompt <b>Latches with "gets", "misses", "sleeps", "immediate gets", or "immediate misses" greater than 0 - (ordered by misses)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN latch_name        FORMAT a110                      HEADING 'Latch Name'              ENTMAP off
COLUMN gets              FORMAT 999,999,999,999,999,999   HEADING 'Gets'                    ENTMAP off
COLUMN misses            FORMAT 999,999,999,999,999,999   HEADING 'Misses'                  ENTMAP off
COLUMN sleeps            FORMAT 999,999,999,999,999,999   HEADING 'Sleeps'                  ENTMAP off
COLUMN miss_ratio                                         HEADING 'Willing to Wait Ratio'   ENTMAP off
COLUMN imm_gets          FORMAT 999,999,999,999,999,999   HEADING 'Immediate Gets'          ENTMAP off
COLUMN imm_misses        FORMAT 999,999,999,999,999,999   HEADING 'Immediate Misses'        ENTMAP off
COLUMN imm_miss_ratio                                     HEADING 'Immediate Ratio'         ENTMAP off

SELECT
    '<b><font color="#336699">' || SUBSTR(a.name,1,40) || '</font></b>'         latch_name
  , gets                         gets
  , misses                       misses
  , sleeps                       sleeps
  , '<div align="right">' || ROUND((misses/(gets+.001))*100, 4) || '%</div>'     miss_ratio
  , immediate_gets               imm_gets
  , immediate_misses             imm_misses
  , '<div align="right">' || ROUND((immediate_misses/(immediate_gets+.001))*100, 4) || '%</div>'  imm_miss_ratio
FROM
    v$latch      a
  , v$latchname  b
WHERE
      a.latch# = b.latch#
  AND (    gets > 10000
        --OR misses > 0
        --OR sleeps > 0
        OR immediate_gets > 10000
        --OR immediate_misses > 0
  )
ORDER BY
    misses DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                         - SYSTEM WAIT STATISTICS -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="system_wait_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>System Wait Statistics</b></font><hr align="left" width="460">

prompt <b>Classes with counts greater than 0</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN class    FORMAT A95              HEADING 'Class'   ENTMAP off
COLUMN count    FORMAT 99999999999990   HEADING 'Count'   ENTMAP off

SELECT
    '<b><font color="#336699">' || class || '</font></b>'  class
  , count
FROM
    v$waitstat 
WHERE
    count > 0
ORDER BY
    2 DESC
  , 1;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - SYSTEM STATISTICS -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="system_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>System Statistics</b></font><hr align="left" width="460">

prompt <b>Statistics with values greater than 0</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name     FORMAT A95                                HEADING 'Name'     ENTMAP off
COLUMN value    FORMAT 999,999,999,999,999,999,999,990    HEADING 'Value'    ENTMAP off

SELECT
    '<b><font color="#336699">' || name || '</font></b>'  name
  , value
FROM
    v$sysstat 
WHERE
    value > 0
ORDER BY
    2 DESC
  , 1;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - SYSTEM EVENT STATISTICS -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="system_event_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>System Event Statistics</b></font><hr align="left" width="460">

prompt <b>Non-idle events with total waits greater than 0 - (ordered by "Time Waited")</b>
prompt 

prompt -
<b>EVENT:</b> The name of the wait event.<br> -
<b>TOTAL_WAITS:</b> The total number of waits for this event.<br> -
<b>TOTAL_TIMEOUTS:</b> The total number of timeouts for this event.<br> -
<b>TIME_WAITED:</b> The total amount of time waited for this event, in hundredths of a second.<br> -
<b>AVERAGE_WAIT:</b> The average amount of time waited for this event, in hundredths of a second.

CLEAR COLUMNS BREAKS COMPUTES

COLUMN event             FORMAT a95                       HEADING 'Event'           ENTMAP off
COLUMN total_waits       FORMAT 999,999,999,999,999,999   HEADING 'Total Waits'     ENTMAP off
COLUMN total_timeouts    FORMAT 999,999,999,999,999,999   HEADING 'Total Timeouts'  ENTMAP off
COLUMN time_waited       FORMAT 999,999,999,999,999,999   HEADING 'Time Waited'     ENTMAP off
COLUMN average_wait      FORMAT 999,999,999,999,999,999   HEADING 'Average Wait'    ENTMAP off

SELECT
    '<b><font color="#336699">' || event || '</font></b>'  event
  , total_waits
  , total_timeouts
  , time_waited
  , average_wait
FROM
    v$system_event 
WHERE
      total_waits > 0
and time_waited>1000
  AND event NOT IN (   'PX Idle Wait'
                     , 'pmon timer'
                     , 'smon timer'
                     , 'rdbms ipc message'
                     , 'parallel dequeue wait'
                     , 'parallel query dequeue'
                     , 'virtual circuit'
                     , 'SQL*Net message from client'
                     , 'SQL*Net message to client'
                     , 'SQL*Net more data to client'
                     , 'client message','Null event'
                     , 'WMON goes to sleep'
                     , 'virtual circuit status'
                     , 'dispatcher timer'
                     , 'pipe get'
                     , 'slave wait'
                     , 'KXFX: execution message dequeue - Slaves'
                     , 'parallel query idle wait - Slaves'
                     , 'lock manager wait for remote message') 
ORDER BY
    time_waited DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                            - TOP 10 TABLES -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="top_10_tables"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 10 Accessed Objects</b></font><hr align="left" width="460">

prompt <b>Top 10 Accessed Objects - (ordered by logical reads)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner       		FORMAT a30                  HEADING 'Object Owner'          ENTMAP off
COLUMN object_type      FORMAT a30  				HEADING 'Object Type'  			ENTMAP off
COLUMN object_name      FORMAT a30  				HEADING 'Object Name'           ENTMAP off
COLUMN subobject_name   FORMAT a30  				HEADING 'Partition Name'        ENTMAP off
COLUMN value 			FORMAT 999,999,999,999,999  HEADING 'Count of Access'        ENTMAP off

SELECT 
a. owner,
a.object_type,
a.object_name,
a.subobject_name,
a.value 
FROM ( 
select o.owner,o.object_type,o.object_name,o.subobject_name,s.value 
from dba_objects o, v$segstat s 
where s.obj#=o.object_id 
and s.dataobj#=o.data_object_id 
and s.statistic_name='logical reads' 
order by 5 desc,1,2,3 
    ) a 
WHERE rownum <= 10;


prompt <b>Top 10 Accessed Objects - (ordered by physical reads)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner       		FORMAT a30                  HEADING 'Object Owner'          ENTMAP off
COLUMN object_type      FORMAT a30  				HEADING 'Object Type'  			ENTMAP off
COLUMN object_name      FORMAT a30  				HEADING 'Object Name'           ENTMAP off
COLUMN subobject_name   FORMAT a30  				HEADING 'Partition Name'        ENTMAP off
COLUMN value 			FORMAT 999,999,999,999,999  HEADING 'Count of Access'        ENTMAP off

SELECT 
a. owner,
a.object_type,
a.object_name,
a.subobject_name,
a.value 
FROM ( 
select o.owner,o.object_type,o.object_name,o.subobject_name,s.value 
from dba_objects o, v$segstat s 
where s.obj#=o.object_id 
and s.dataobj#=o.data_object_id 
and s.statistic_name='physical reads' 
order by 5 desc,1,2,3 
    ) a 
WHERE rownum <= 10;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - TOP 10 PROCEDURES -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="top_10_procedures"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 10 Procedures</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN ptyp      FORMAT a79                   HEADING 'Object Type'            ENTMAP off
COLUMN obj       FORMAT a42                   HEADING 'Object Name'            ENTMAP off
COLUMN noe       FORMAT 999,999,999,999,999   HEADING 'Number of Executions'   ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF noe ON report

SELECT
    '<div nowrap><font color="#336699"><b>' || ptyp || '</b></font></div>'  ptyp
  , obj
  , 0 - exem noe
FROM ( select distinct exem, ptyp, obj  
       from ( select
                  o.type                    ptyp
                , o.owner || '.' || o.name  obj
                , 0 - o.executions          exem
              from  v$db_object_cache O 
              where o.type in (   'FUNCTION'
                                , 'PACKAGE'
                                , 'PACKAGE BODY'
                                , 'PROCEDURE'
                                , 'TRIGGER')
	   )
     )
WHERE rownum <= 10;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +============================================================================+
-- |                                                                            |
-- |        <<<<<     AUTOMATIC WORKLOAD REPOSITORY - (AWR)     >>>>>           |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Automatic Workload Repository - (AWR)</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                   - WORKLOAD REPOSITORY INFORMATION -                      |
-- +----------------------------------------------------------------------------+

prompt <a name="awr_workload_repository_information"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Workload Repository Information</b></font><hr align="left" width="460">

prompt <b>Instances found in the "Workload Repository"</b>
prompt <b>The instance running this report (&_instance_name) is indicated in "<font color="darkgreen">GREEN</font>"</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN dbbid          FORMAT a75           HEAD 'Database ID'      ENTMAP off
COLUMN dbb_name       FORMAT a75           HEAD 'Database Name'    ENTMAP off
COLUMN instt_name     FORMAT a75           HEAD 'Instance Name'    ENTMAP off
COLUMN instt_num      FORMAT 9999999999    HEAD 'Instance Number'  ENTMAP off
COLUMN host           FORMAT a75           HEAD 'Host'             ENTMAP off
COLUMN host_platform  FORMAT a125          HEAD 'Host Platform'    ENTMAP off

SELECT
    DISTINCT (CASE WHEN cd.dbid = wr.dbid
                        AND 
                        cd.name = wr.db_name
                        AND
                        ci.instance_number = wr.instance_number
                        AND
                        ci.instance_name = wr.instance_name
                   THEN '<div align="left"><font color="darkgreen"><b>' || wr.dbid || '</b></font></div>'
                   ELSE '<div align="left"><font color="#663300"><b>'   || wr.dbid || '</b></font></div>'
              END)                  dbbid
  , wr.db_name                      dbb_name
  , wr.instance_name                instt_name
  , wr.instance_number              instt_num
  , wr.host_name                    host
  , cd.platform_name                host_platform
FROM
    dba_hist_database_instance wr
  , v$database cd
  , v$instance ci
ORDER BY
    wr.instance_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - AWR SNAPSHOT SIZE ESTIMATES -                       |
-- +----------------------------------------------------------------------------+

prompt <a name="awr_snapshot_size_estimates"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>AWR Snapshot Size Estimates</b></font><hr align="left" width="460">

DECLARE

    CURSOR get_instances IS
        SELECT COUNT(DISTINCT instance_number)
        FROM wrm$_database_instance;
  
    CURSOR get_wr_control_info IS
        SELECT snapint_num, retention_num
        FROM wrm$_wr_control;
  
    CURSOR get_snaps IS
        SELECT
            SUM(all_snaps)
          , SUM(good_snaps)
          , SUM(today_snaps)
          , SYSDATE - MIN(begin_interval_time)
        FROM
            (SELECT
                  1 AS all_snaps
                , (CASE WHEN s.status = 0 THEN 1 ELSE 0 END) AS good_snaps
                , (CASE WHEN (s.end_interval_time > SYSDATE - 1) THEN 1 ELSE 0 END) AS today_snaps
                , CAST(s.begin_interval_time AS DATE) AS begin_interval_time
             FROM wrm$_snapshot s
             );

    CURSOR sysaux_occ_usage IS
        SELECT
            occupant_name
          , schema_name
          , space_usage_kbytes/1024 space_usage_mb
        FROM
            v$sysaux_occupants
        ORDER BY
            space_usage_kbytes DESC
          , occupant_name;
  
    mb_format           CONSTANT  VARCHAR2(30)  := '99,999,990.0';
    kb_format           CONSTANT  VARCHAR2(30)  := '999,999,990';
    pct_format          CONSTANT  VARCHAR2(30)  := '990.0';
    snapshot_interval   NUMBER;
    retention_interval  NUMBER;
    all_snaps           NUMBER;
    awr_size            NUMBER;
    snap_size           NUMBER;
    awr_average_size    NUMBER;
    est_today_snaps     NUMBER;
    awr_size_past24     NUMBER;
    good_snaps          NUMBER;
    today_snaps         NUMBER;
    num_days            NUMBER;
    num_instances       NUMBER;

BEGIN

    OPEN get_instances;
    FETCH get_instances INTO num_instances;
    CLOSE get_instances;

    OPEN get_wr_control_info;
    FETCH get_wr_control_info INTO snapshot_interval, retention_interval;
    CLOSE get_wr_control_info;

    OPEN get_snaps;
    FETCH get_snaps INTO all_snaps, good_snaps, today_snaps, num_days;
    CLOSE get_snaps;

    FOR occ_rec IN sysaux_occ_usage
    LOOP
        IF (occ_rec.occupant_name = 'SM/AWR') THEN
            awr_size := occ_rec.space_usage_mb;
        END IF;
    END LOOP;

    snap_size := awr_size/all_snaps;
    awr_average_size := snap_size*86400/snapshot_interval;

    today_snaps := today_snaps / num_instances;

    IF (num_days < 1) THEN
        est_today_snaps := ROUND(today_snaps / num_days);
    ELSE
        est_today_snaps := today_snaps;
    END IF;

    awr_size_past24 := snap_size * est_today_snaps;
    
    DBMS_OUTPUT.PUT_LINE('<table width="90%" border="1">');

    DBMS_OUTPUT.PUT_LINE('<tr><th align="center" colspan="3">Estimates based on ' || ROUND(snapshot_interval/60) || ' minute snapshot intervals</th></tr>');
    DBMS_OUTPUT.PUT_LINE('<tr><td>AWR size/day</td><td align="right">'
                            || TO_CHAR(awr_average_size, mb_format)
                            || ' MB</td><td align="right">(' || TRIM(TO_CHAR(snap_size*1024, kb_format)) || ' K/snap * '
                            || ROUND(86400/snapshot_interval) || ' snaps/day)</td></tr>' );
    DBMS_OUTPUT.PUT_LINE('<tr><td>AWR size/wk</td><td align="right">'
                            || TO_CHAR(awr_average_size * 7, mb_format)
                            || ' MB</td><td align="right">(size_per_day * 7) per instance</td></tr>' );
    IF (num_instances > 1) THEN
        DBMS_OUTPUT.PUT_LINE('<tr><td>AWR size/wk</td><td align="right">'
                            || TO_CHAR(awr_average_size * 7 * num_instances, mb_format)
                            || ' MB</td><td align="right">(size_per_day * 7) per database</td></tr>' );
    END IF;

    DBMS_OUTPUT.PUT_LINE('<tr><th align="center" colspan="3">Estimates based on ' || ROUND(today_snaps) || ' snaps in past 24 hours</th></tr>');

    DBMS_OUTPUT.PUT_LINE('<tr><td>AWR size/day</td><td align="right">'
                            || TO_CHAR(awr_size_past24, mb_format)
                            || ' MB</td><td align="right">('
                            || TRIM(TO_CHAR(snap_size*1024, kb_format)) || ' K/snap and '
                            || ROUND(today_snaps) || ' snaps in past '
                            || ROUND(least(num_days*24,24),1) || ' hours)</td></tr>' );
    DBMS_OUTPUT.PUT_LINE('<tr><td>AWR size/wk</td><td align="right">'
                            || TO_CHAR(awr_size_past24 * 7, mb_format)
                            || ' MB</td><td align="right">(size_per_day * 7) per instance</td></tr>' );
    IF (num_instances > 1) THEN
        DBMS_OUTPUT.PUT_LINE('<tr><td>AWR size/wk</td><td align="right">'
                            || TO_CHAR(awr_size_past24 * 7 * num_instances, mb_format)
                            || ' MB</td><td align="right">(size_per_day * 7) per database</td></tr>' );
    END IF;
  
    DBMS_OUTPUT.PUT_LINE('</table>');
    
END;
/

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +============================================================================+
-- |                                                                            |
-- |                      <<<<<     SESSIONS    >>>>>                           |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Sessions</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                          - CURRENT SESSIONS -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="current_sessions"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Current Sessions</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print  FORMAT a45    HEADING 'Instance Name'              ENTMAP off
COLUMN thread_number_print  FORMAT a45    HEADING 'Thread Number'              ENTMAP off
COLUMN count                FORMAT a45    HEADING 'Current No. of Processes'   ENTMAP off
COLUMN value                FORMAT a45    HEADING 'Max No. of Processes'       ENTMAP off
COLUMN pct_usage            FORMAT a45    HEADING '% Usage'                    ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || a.instance_name  || '</b></font></div>'  instance_name_print
  , '<div align="center">' || a.thread#             || '</div>'  thread_number_print
  , '<div align="center">' || TO_CHAR(a.count)      || '</div>'  count
  , '<div align="center">' || b.value               || '</div>'  value
  , '<div align="center">' || TO_CHAR(ROUND(100*(a.count / b.value), 2)) || '%</div>'  pct_usage
FROM
    (select   count(*) count, a1.inst_id, a2.instance_name, a2.thread#
     from     gv$session a1
            , gv$instance a2
     where    a1.inst_id = a2.inst_id
     group by a1.inst_id
            , a2.instance_name
            , a2.thread#) a
  , (select value, inst_id from gv$parameter where name='processes') b
WHERE
    a.inst_id = b.inst_id
ORDER BY
    a.instance_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - USER SESSION MATRIX -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="user_session_matrix"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User Session Matrix</b></font><hr align="left" width="460">

prompt <b>User sessions (excluding SYS and background processes)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print  FORMAT a75               HEADING 'Instance Name'            ENTMAP off
COLUMN thread_number_print  FORMAT a75               HEADING 'Thread Number'            ENTMAP off
COLUMN username             FORMAT a79               HEADING 'Oracle User'              ENTMAP off
COLUMN num_user_sess        FORMAT 999,999,999,999   HEADING 'Total Number of Logins'   ENTMAP off
COLUMN count_a              FORMAT 999,999,999       HEADING 'Active Logins'            ENTMAP off
COLUMN count_i              FORMAT 999,999,999       HEADING 'Inactive Logins'          ENTMAP off
COLUMN count_k              FORMAT 999,999,999       HEADING 'Killed Logins'            ENTMAP off

BREAK ON report ON instance_name_print ON thread_number_print

SELECT
    '<div align="center"><font color="#336699"><b>' || i.instance_name || '</b></font></div>'                      instance_name_print
  , '<div align="center"><font color="#336699"><b>' || i.thread#       || '</b></font></div>'                      thread_number_print
  , '<div align="left"><font color="#000000">' || NVL(sess.username, '[B.G. Process]') || '</font></div>' username
  , count(*)              num_user_sess
  , NVL(act.count, 0)     count_a
  , NVL(inact.count, 0)   count_i
  , NVL(killed.count, 0)  count_k
FROM 
    gv$session                        sess
  , gv$instance                       i
  , (SELECT    count(*) count, NVL(username, '[B.G. Process]') username, inst_id
     FROM      gv$session
     WHERE     status = 'ACTIVE'
     GROUP BY  username, inst_id)              act
  , (SELECT    count(*) count, NVL(username, '[B.G. Process]') username, inst_id
     FROM      gv$session
     WHERE     status = 'INACTIVE'
     GROUP BY  username, inst_id)              inact
  , (SELECT    count(*) count, NVL(username, '[B.G. Process]') username, inst_id
     FROM      gv$session
     WHERE     status = 'KILLED'
     GROUP BY  username, inst_id)              killed
WHERE
         sess.inst_id                         = i.inst_id
     AND (
           NVL(sess.username, '[B.G. Process]') = act.username (+)
           AND
           sess.inst_id  = act.inst_id (+)
         )
     AND (
           NVL(sess.username, '[B.G. Process]') = inact.username (+)
           AND
           sess.inst_id  = inact.inst_id (+)
         )
     AND (
           NVL(sess.username, '[B.G. Process]') = killed.username (+)
           AND
           sess.inst_id  = killed.inst_id (+)
         )
     AND sess.username NOT IN ('SYS')
GROUP BY
    i.instance_name
  , i.thread#
  , sess.username
  , act.count
  , inact.count
  , killed.count
ORDER BY
    i.instance_name
  , i.thread#
  , sess.username;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>





-- +============================================================================+
-- |                                                                            |
-- |                      <<<<<     SECURITY     >>>>>                          |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Security</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                             - USER ACCOUNTS -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="user_accounts"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User Accounts</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN username              FORMAT a75    HEAD 'Username'        ENTMAP off
COLUMN account_status        FORMAT a75    HEAD 'Account Status'  ENTMAP off
COLUMN expiry_date           FORMAT a75    HEAD 'Expire Date'     ENTMAP off
COLUMN default_tablespace    FORMAT a75    HEAD 'Default Tbs.'    ENTMAP off
COLUMN temporary_tablespace  FORMAT a75    HEAD 'Temp Tbs.'       ENTMAP off
COLUMN created               FORMAT a75    HEAD 'Created On'      ENTMAP off
COLUMN profile               FORMAT a75    HEAD 'Profile'         ENTMAP off
COLUMN sysdba                FORMAT a75    HEAD 'SYSDBA'          ENTMAP off
COLUMN sysoper               FORMAT a75    HEAD 'SYSOPER'         ENTMAP off

SELECT distinct
    '<b><font color="#336699">' || a.username || '</font></b>'                                            username
  , DECODE(   a.account_status
            , 'OPEN'
            , '<div align="left"><b><font color="darkgreen">' || a.account_status || '</font></b></div>'
            , '<div align="left"><b><font color="#663300">'   || a.account_status || '</font></b></div>') account_status
  , '<div nowrap align="right">' || NVL(TO_CHAR(a.expiry_date, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</div>'           expiry_date
  , a.default_tablespace                                                                                  default_tablespace
  , a.temporary_tablespace                                                                                temporary_tablespace
  , '<div nowrap align="right">' || TO_CHAR(a.created, 'mm/dd/yyyy HH24:MI:SS') || '</div>'               created
  , a.profile                                        profile
  , '<div nowrap align="center">' || NVL(DECODE(p.sysdba,'TRUE', 'TRUE',''), '<br>') || '</div>'   sysdba
  , '<div nowrap align="center">' || NVL(DECODE(p.sysoper,'TRUE','TRUE',''), '<br>') || '</div>'   sysoper
FROM
    dba_users       a
  , v$pwfile_users  p
WHERE
    p.username (+) = a.username 
ORDER BY
    account_status,default_tablespace,username;  -- order by account status, 2009-6-17

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - USERS WITH DBA PRIVILEGES -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="users_with_dba_privileges"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Users With DBA Privileges</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN grantee        FORMAT a70   HEADING 'Grantee'         ENTMAP off
COLUMN granted_role   FORMAT a35   HEADING 'Granted Role'    ENTMAP off
COLUMN admin_option   FORMAT a75   HEADING 'Admin. Option?'  ENTMAP off
COLUMN default_role   FORMAT a75   HEADING 'Default Role?'   ENTMAP off

SELECT
    '<b><font color="#336699">' || grantee       || '</font></b>'  grantee
  , '<div align="center">'      || granted_role  || '</div>'  granted_role
  , DECODE(   admin_option
            , 'YES'
            , '<div align="center"><font color="darkgreen"><b>' || admin_option || '</b></font></div>'
            , 'NO'
            , '<div align="center"><font color="#990000"><b>'   || admin_option || '</b></font></div>'
            , '<div align="center"><font color="#663300"><b>'   || admin_option || '</b></font></div>')   admin_option
  , DECODE(   default_role
            , 'YES'
            , '<div align="center"><font color="darkgreen"><b>' || default_role || '</b></font></div>'
            , 'NO'
            , '<div align="center"><font color="#990000"><b>'   || default_role || '</b></font></div>'
            , '<div align="center"><font color="#663300"><b>'   || default_role || '</b></font></div>')   default_role
FROM
    dba_role_privs
WHERE
    granted_role = 'DBA'
ORDER BY
    grantee
  , granted_role;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>





-- +----------------------------------------------------------------------------+
-- |                          - DEFAULT PASSWORDS -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="default_passwords"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Default Passwords</b></font><hr align="left" width="460">

prompt <b>User(s) with default password</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN username                      HEADING 'Username'        ENTMAP off
COLUMN account_status   FORMAT a75   HEADING 'Account Status'  ENTMAP off

SELECT
    '<b><font color="#336699">' || username        || '</font></b>'        username
  , DECODE(   account_status
            , 'OPEN'
            , '<div align="left"><b><font color="darkgreen">' || account_status || '</font></b></div>'
            , '<div align="left"><b><font color="#663300">'   || account_status || '</font></b></div>') account_status
FROM dba_users
WHERE password IN (
    'E066D214D5421CCC'   -- dbsnmp
  , '24ABAB8B06281B4C'   -- ctxsys
  , '72979A94BAD2AF80'   -- mdsys
  , 'C252E8FA117AF049'   -- odm
  , 'A7A32CD03D3CE8D5'   -- odm_mtr
  , '88A2B2C183431F00'   -- ordplugins
  , '7EFA02EC7EA6B86F'   -- ordsys
  , '4A3BA55E08595C81'   -- outln
  , 'F894844C34402B67'   -- scott
  , '3F9FBD883D787341'   -- wk_proxy
  , '79DF7A1BD138CF11'   -- wk_sys
  , '7C9BA362F8314299'   -- wmsys
  , '88D8364765FCE6AF'   -- xdb
  , 'F9DA8977092B7B81'   -- tracesvr
  , '9300C0977D7DC75E'   -- oas_public
  , 'A97282CE3D94E29E'   -- websys
  , 'AC9700FD3F1410EB'   -- lbacsys
  , 'E7B5D92911C831E1'   -- rman
  , 'AC98877DE1297365'   -- perfstat
  , 'D4C5016086B2DC6A'   -- sys
  , 'D4DF7931AB130E37')  -- system
ORDER BY
    username;



prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>





-- +============================================================================+
-- |                                                                            |
-- |                     <<<<<     OBJECTS     >>>>>                            |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Objects</u></b></font></center>




-- +----------------------------------------------------------------------------+
-- |                          - SEGMENT SUMMARY -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="segment_summary"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Segment Summary</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner           FORMAT a50                    HEADING 'Owner'             ENTMAP off
COLUMN segment_type    FORMAT a25                    HEADING 'Segment Type'      ENTMAP off
COLUMN seg_count       FORMAT 999,999,999,999        HEADING 'Segment Count'     ENTMAP off
COLUMN bytes           FORMAT 999,999,999,999,999    HEADING 'Size (in Bytes)'   ENTMAP off

BREAK ON report ON owner SKIP 2
-- COMPUTE sum LABEL ""                                                  OF seg_count bytes ON owner
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF seg_count bytes ON report

SELECT
    '<b><font color="#336699">' || owner || '</font></b>'  owner
  , segment_type        segment_type
  , count(*)            seg_count
  , sum(bytes)          bytes
FROM
    dba_segments
WHERE
		owner in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN'))    
GROUP BY
    owner
  , segment_type
ORDER BY
    owner
  , segment_type;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                    - TOP 100 SEGMENTS (BY SIZE) -                          |
-- +----------------------------------------------------------------------------+

prompt <a name="top_100_segments_by_size"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 100 Segments (by size)</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner                                               HEADING 'Owner'            ENTMAP off
COLUMN segment_name                                        HEADING 'Segment Name'     ENTMAP off
COLUMN partition_name                                      HEADING 'Partition Name'   ENTMAP off
COLUMN segment_type                                        HEADING 'Segment Type'     ENTMAP off
COLUMN tablespace_name                                     HEADING 'Tablespace Name'  ENTMAP off
COLUMN bytes               FORMAT 999,999,999,999,999,999  HEADING 'Size (in GB)'  ENTMAP off
COLUMN extents             FORMAT 999,999,999,999,999,999  HEADING 'Extents'          ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF bytes extents ON report

SELECT
    a.owner
  , a.segment_name
  , a.partition_name
  , a.segment_type
  , a.tablespace_name
  , a.bytes
  , a.extents
FROM
    (select
         b.owner
       , b.segment_name
       , b.partition_name
       , b.segment_type
       , b.tablespace_name
       , round(b.bytes/1024/1024/1024,2) bytes
       , b.extents
     from
         dba_segments b
     order by
         b.bytes desc
    ) a
WHERE
    rownum < 101;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - TOP 100 SEGMENTS (BY EXTENTS) -                     |
-- +----------------------------------------------------------------------------+

prompt <a name="top_100_segments_by_extents"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 100 Segments (by number of extents)</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner                                               HEADING 'Owner'            ENTMAP off
COLUMN segment_name                                        HEADING 'Segment Name'     ENTMAP off
COLUMN partition_name                                      HEADING 'Partition Name'   ENTMAP off
COLUMN segment_type                                        HEADING 'Segment Type'     ENTMAP off
COLUMN tablespace_name                                     HEADING 'Tablespace Name'  ENTMAP off
COLUMN extents             FORMAT 999,999,999,999,999,999  HEADING 'Extents'          ENTMAP off
COLUMN bytes               FORMAT 999,999,999,999,999,999  HEADING 'Size (in bytes)'  ENTMAP off

BREAK ON report
COMPUTE sum LABEL '<font color="#990000"><b>Total: </b></font>' OF extents bytes ON report

SELECT
    a.owner
  , a.segment_name
  , a.partition_name
  , a.segment_type
  , a.tablespace_name
  , a.extents
  , a.bytes
FROM
    (select
         b.owner
       , b.segment_name
       , b.partition_name
       , b.segment_type
       , b.tablespace_name
       , b.bytes
       , b.extents
     from
         dba_segments b
     order by
         b.extents desc
    ) a
WHERE
    rownum < 101;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - DIRECTORIES -                                  |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_directories"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Directories</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner             FORMAT a75  HEADING 'Owner'             ENTMAP off
COLUMN directory_name    FORMAT a75  HEADING 'Directory Name'    ENTMAP off
COLUMN directory_path                HEADING 'Directory Path'    ENTMAP off

BREAK ON report ON owner

SELECT
    '<div align="left"><font color="#336699"><b>' || owner          || '</b></font></div>'  owner
  , '<b><font color="#663300">'                   || directory_name || '</font></b>'        directory_name
  , '<tt>' || directory_path || '</tt>' directory_path
FROM
    dba_directories
ORDER BY
    owner
  , directory_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - DIRECTORY PRIVILEGES -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_directory_privileges"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Directory Privileges</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN table_name    FORMAT a75      HEADING 'Directory Name'    ENTMAP off
COLUMN grantee       FORMAT a75      HEADING 'Grantee'           ENTMAP off
COLUMN privilege     FORMAT a75      HEADING 'Privilege'         ENTMAP off
COLUMN grantable     FORMAT a75      HEADING 'Grantable?'        ENTMAP off

BREAK ON report ON table_name ON grantee

SELECT
    '<b><font color="#336699">' || table_name || '</font></b>'  table_name
  , '<b><font color="#663300">' || grantee    || '</font></b>'  grantee
  , privilege                                                   privilege
  , DECODE(   grantable
            , 'YES'
            , '<div align="center"><font color="darkgreen"><b>' || grantable || '</b></font></div>'
            , 'NO'
            , '<div align="center"><font color="#990000"><b>'   || grantable || '</b></font></div>'
            , '<div align="center"><font color="#663300"><b>'   || grantable || '</b></font></div>')   grantable
FROM
    dba_tab_privs
WHERE
    privilege IN ('READ', 'WRITE')
ORDER BY
    table_name
  , grantee
  , privilege;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>





-- +----------------------------------------------------------------------------+
-- |                           - LOB SEGMENTS -                                 |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_lob_segments"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>LOB Segments</b></font><hr align="left" width="460">

prompt <b>Excluding all internal system schemas (i.e. CTXSYS, MDSYS, SYS, SYSTEM)</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner              FORMAT a85        HEADING 'Owner'              ENTMAP off
COLUMN table_name         FORMAT a75        HEADING 'Table Name'         ENTMAP off
COLUMN column_name        FORMAT a75        HEADING 'Column Name'        ENTMAP off
COLUMN segment_name       FORMAT a125       HEADING 'LOB Segment Name'   ENTMAP off
COLUMN tablespace_name    FORMAT a75        HEADING 'Tablespace Name'    ENTMAP off
COLUMN lob_segment_bytes  FORMAT a75        HEADING 'Segment Size'       ENTMAP off
COLUMN index_name         FORMAT a125       HEADING 'LOB Index Name'     ENTMAP off
COLUMN in_row             FORMAT a75        HEADING 'In Row?'            ENTMAP off

BREAK ON report ON owner ON table_name

SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || l.owner || '</b></font></div>'    owner
  , '<div nowrap>' || l.table_name        || '</div>'       table_name
  , '<div nowrap>' || l.column_name       || '</div>'       column_name
  , '<div nowrap>' || l.segment_name      || '</div>'       segment_name
  , '<div nowrap>' || s.tablespace_name   || '</div>'       tablespace_name
  , '<div nowrap align="right">' || TO_CHAR(s.bytes, '999,999,999,999,999') || '</div>'  lob_segment_bytes
  , '<div nowrap>' || l.index_name        || '</div>'       index_name
  , DECODE(   l.in_row
            , 'YES'
            , '<div align="center"><font color="darkgreen"><b>' || l.in_row || '</b></font></div>'
            , 'NO'
            , '<div align="center"><font color="#990000"><b>'   || l.in_row || '</b></font></div>'
            , '<div align="center"><font color="#663300"><b>'   || l.in_row || '</b></font></div>')   in_row
FROM
    dba_lobs     l
  , dba_segments s
WHERE
      l.owner = s.owner
  AND l.segment_name = s.segment_name
  AND l.owner NOT IN (    'CTXSYS'
                        , 'DBSNMP'
                        , 'DMSYS'
                        , 'EXFSYS'
                        , 'IX'
                        , 'LBACSYS'
                        , 'MDSYS'
                        , 'OLAPSYS'
                        , 'ORDSYS'
                        , 'OUTLN'
                        , 'SYS'
                        , 'SYSMAN'
                        , 'SYSTEM'
                        , 'WKSYS'
                        , 'WMSYS'
                        , 'XDB')
ORDER BY
    l.owner
  , l.table_name
  , l.column_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                      - OBJECTS UNABLE TO EXTEND -                          |
-- +----------------------------------------------------------------------------+

prompt <a name="objects_unable_to_extend"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Objects Unable to Extend</b></font><hr align="left" width="460">

prompt <b>Segments that cannot extend because of MAXEXTENTS or not enough space</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner             FORMAT a75                  HEADING 'Owner'            ENTMAP off
COLUMN tablespace_name                               HEADING 'Tablespace Name'  ENTMAP off
COLUMN segment_name                                  HEADING 'Segment Name'     ENTMAP off
COLUMN segment_type                                  HEADING 'Segment Type'     ENTMAP off
COLUMN next_extent       FORMAT 999,999,999,999,999  HEADING 'Next Extent'      ENTMAP off
COLUMN max               FORMAT 999,999,999,999,999  HEADING 'Max. Piece Size'  ENTMAP off
COLUMN sum               FORMAT 999,999,999,999,999  HEADING 'Sum of Bytes'     ENTMAP off
COLUMN extents           FORMAT 999,999,999,999,999  HEADING 'Num. of Extents'  ENTMAP off
COLUMN max_extents       FORMAT 999,999,999,999,999  HEADING 'Max Extents'      ENTMAP off

BREAK ON report ON owner

SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || ds.owner || '</b></font></div>'    owner
  , ds.tablespace_name    tablespace_name
  , ds.segment_name       segment_name
  , ds.segment_type       segment_type
  , ds.next_extent        next_extent
  , NVL(dfs.max, 0)       max
  , NVL(dfs.sum, 0)       sum
  , ds.extents            extents
  , ds.max_extents        max_extents
FROM 
    dba_segments ds
  , (select
         max(bytes) max
       , sum(bytes) sum
       , tablespace_name
     from
         dba_free_space 
     group by
         tablespace_name
    ) dfs
WHERE
      (ds.next_extent > nvl(dfs.max, 0)
       OR
       ds.extents >= ds.max_extents)
  AND ds.tablespace_name = dfs.tablespace_name (+)
  AND ds.owner NOT IN ('SYS','SYSTEM')
ORDER BY
    ds.owner
  , ds.tablespace_name
  , ds.segment_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |               - OBJECTS WHICH ARE NEARING MAXEXTENTS -                     |
-- +----------------------------------------------------------------------------+

prompt <a name="objects_which_are_nearing_maxextents"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Objects Which Are Nearing MAXEXTENTS</b></font><hr align="left" width="460">

prompt <b>Segments where number of EXTENTS is less than 1/2 of MAXEXTENTS</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner             FORMAT a75                   HEADING 'Owner'             ENTMAP off
COLUMN tablespace_name   FORMAT a30                   HEADING 'Tablespace name'   ENTMAP off
COLUMN segment_name      FORMAT a30                   HEADING 'Segment Name'      ENTMAP off
COLUMN segment_type      FORMAT a20                   HEADING 'Segment Type'      ENTMAP off
COLUMN bytes             FORMAT 999,999,999,999,999   HEADING 'Size (in bytes)'   ENTMAP off
COLUMN next_extent       FORMAT 999,999,999,999,999   HEADING 'Next Extent Size'  ENTMAP off
COLUMN pct_increase                                   HEADING '% Increase'        ENTMAP off
COLUMN extents           FORMAT 999,999,999,999,999   HEADING 'Num. of Extents'   ENTMAP off
COLUMN max_extents       FORMAT 999,999,999,999,999   HEADING 'Max Extents'       ENTMAP off
COLUMN pct_util          FORMAT a35                   HEADING '% Utilized'        ENTMAP off

SELECT
    owner
  , tablespace_name
  , segment_name
  , segment_type
  , bytes
  , next_extent
  , pct_increase
  , extents
  , max_extents
  , '<div align="right">' || ROUND((extents/max_extents)*100, 2) || '%</div>'   pct_util
FROM
    dba_segments
WHERE
      extents > max_extents/2
  AND max_extents != 0
ORDER BY
    (extents/max_extents) DESC;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                          - INVALID OBJECTS -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="invalid_objects"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Invalid Objects</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner           FORMAT a85         HEADING 'Owner'         ENTMAP off
COLUMN object_name     FORMAT a30         HEADING 'Object Name'   ENTMAP off
COLUMN object_type     FORMAT a20         HEADING 'Object Type'   ENTMAP off
COLUMN status          FORMAT a75         HEADING 'Status'        ENTMAP off

BREAK ON report ON owner
COMPUTE count LABEL '<font color="#990000"><b>Grand Total: </b></font>' OF object_name ON report

SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || owner || '</b></font></div>'    owner
  , object_name
  , object_type
  , DECODE(   status
            , 'VALID'
            , '<div align="center"><font color="darkgreen"><b>' || status || '</b></font></div>'
            , '<div align="center"><font color="#990000"><b>'   || status || '</b></font></div>' ) status
FROM dba_objects
WHERE status <> 'VALID'
ORDER BY
    owner
  , object_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                     - OBJECTS WITHOUT STATISTICS -                         |
-- +----------------------------------------------------------------------------+

prompt <a name="objects_without_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Objects Without Statistics</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner            FORMAT a95                HEAD 'Owner'            ENTMAP off
COLUMN object_type      FORMAT a20                HEAD 'Object Type'      ENTMAP off
COLUMN count            FORMAT 999,999,999,999    HEAD 'Count'            ENTMAP off

BREAK ON report ON owner
COMPUTE count LABEL '<font color="#990000"><b>Total: </b></font>' OF object_name ON report

SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || owner || '</b></font></div>'        owner
  , 'Table'                                                                                     object_type
  , count(*)                                                                                    count
FROM
    sys.dba_tables 
WHERE
      last_analyzed IS NULL 
  AND owner  in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN','SYS','SYSTEM')) 
  AND partitioned = 'NO'
GROUP BY
    owner
  , 'Table'
UNION  ALL
SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || owner || '</b></font></div>'        owner
  , 'Index'                                                                                     object_type
  , count(*)                                                                                    count
FROM
    sys.dba_indexes 
WHERE
      last_analyzed IS NULL 
  AND owner  in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN','SYS','SYSTEM')) 
  AND partitioned = 'NO'
GROUP BY
    owner
  , 'Index'
UNION  ALL
SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || table_owner || '</b></font></div>'  owner
  , 'Table Partition'                                                                           object_type
  , count(*)                                                                                    count
FROM
    sys.dba_tab_partitions 
WHERE
      last_analyzed IS NULL 
  AND table_owner  in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN','SYS','SYSTEM')) 
GROUP BY
    table_owner
  , 'Table Partition'
UNION  ALL
SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || index_owner || '</b></font></div>'  owner
  , 'Index Partition'                                                                           object_type
  , count(*)                                                                                    count
FROM
    sys.dba_ind_partitions 
WHERE
      last_analyzed IS NULL 
  AND index_owner  in (select username from dba_users where account_status='OPEN' and username not in ('DBSNMP','SYSMAN','SYS','SYSTEM')) 
GROUP BY
    index_owner
  , 'Index Partition'
ORDER BY
    1
  , 2
  , 3;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |           - TABLES SUFFERING FROM ROW CHAINING/MIGRATION -                 |
-- +----------------------------------------------------------------------------+

prompt <a name="tables_suffering_from_row_chaining_migration"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tables Suffering From Row Chaining/Migration</b></font><hr align="left" width="460">

prompt <b><font color="#990000">NOTE</font>: Tables must have statistics gathered</b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner                                          HEADING 'Owner'           ENTMAP off
COLUMN table_name                                     HEADING 'Table Name'      ENTMAP off
COLUMN partition_name                                 HEADING 'Partition Name'  ENTMAP off
COLUMN num_rows           FORMAT 999,999,999,999,999  HEADING 'Total Rows'      ENTMAP off
COLUMN pct_chained_rows   FORMAT a65                  HEADING '% Chained Rows'  ENTMAP off
COLUMN avg_row_length     FORMAT 999,999,999,999,999  HEADING 'Avg Row Length'  ENTMAP off

SELECT
    owner                               owner
  , table_name                          table_name
  , ''                                  partition_name
  , num_rows                            num_rows
  , '<div align="right">' || ROUND((chain_cnt/num_rows)*100, 2) || '%</div>' pct_chained_rows
  , avg_row_len                         avg_row_length
FROM
    (select
         owner
       , table_name
       , chain_cnt
       , num_rows
       , avg_row_len 
     from
         sys.dba_tables 
     where
           chain_cnt is not null 
       and num_rows is not null 
       and chain_cnt > 0 
       and num_rows > 0 
       and owner != 'SYS')  
UNION ALL 
SELECT
    table_owner                         owner
  , table_name                          table_name
  , partition_name                      partition_name
  , num_rows                            num_rows
  , '<div align="right">' || ROUND((chain_cnt/num_rows)*100, 2) || '%</div>' pct_chained_rows
  , avg_row_len                         avg_row_length
FROM
    (select
         table_owner
       , table_name
       , partition_name
       , chain_cnt
       , num_rows
       , avg_row_len 
     from
         sys.dba_tab_partitions 
     where
           chain_cnt is not null 
       and num_rows is not null 
       and chain_cnt > 0 
       and num_rows > 0 
       and table_owner != 'SYS') b 
WHERE
    (chain_cnt/num_rows)*100 > 10;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |             - USERS WITH DEFAULT TABLESPACE - (SYSTEM) -                   |
-- +----------------------------------------------------------------------------+

prompt <a name="users_with_default_tablespace_defined_as_system"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Users With Default Tablespace - (SYSTEM)</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN username                 FORMAT a75    HEADING 'Username'                ENTMAP off
COLUMN default_tablespace       FORMAT a125   HEADING 'Default Tablespace'      ENTMAP off
COLUMN temporary_tablespace     FORMAT a125   HEADING 'Temporary Tablespace'    ENTMAP off
COLUMN created                  FORMAT a75    HEADING 'Created'                 ENTMAP off
COLUMN account_status           FORMAT a75    HEADING 'Account Status'          ENTMAP off

SELECT
    '<font color="#336699"><b>' || username             || '</font></b>'                  username
  , '<div align="left">'        || default_tablespace   || '</div>'                       default_tablespace
  , '<div align="left">'        || temporary_tablespace || '</div>'                       temporary_tablespace
  , '<div align="right">'       || TO_CHAR(created, 'mm/dd/yyyy HH24:MI:SS') || '</div>'  created
  , DECODE(   account_status
            , 'OPEN'
            , '<div align="center"><b><font color="darkgreen">' || account_status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || account_status || '</font></b></div>') account_status
FROM
    dba_users
WHERE
    default_tablespace = 'SYSTEM'
ORDER BY
    username;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |          - USERS WITH DEFAULT TEMPORARY TABLESPACE - (SYSTEM) -            |
-- +----------------------------------------------------------------------------+

prompt <a name="users_with_default_temporary_tablespace_as_system"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Users With Default Temporary Tablespace - (SYSTEM)</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN username                 FORMAT a75    HEADING 'Username'                ENTMAP off
COLUMN default_tablespace       FORMAT a125   HEADING 'Default Tablespace'      ENTMAP off
COLUMN temporary_tablespace     FORMAT a125   HEADING 'Temporary Tablespace'    ENTMAP off
COLUMN created                  FORMAT a75    HEADING 'Created'                 ENTMAP off
COLUMN account_status           FORMAT a75    HEADING 'Account Status'          ENTMAP off

SELECT
    '<font color="#336699"><b>'  || username             || '</font></b>'                  username
  , '<div align="center">'       || default_tablespace   || '</div>'                       default_tablespace
  , '<div align="center">'       || temporary_tablespace || '</div>'                       temporary_tablespace
  , '<div align="right">'        || TO_CHAR(created, 'mm/dd/yyyy HH24:MI:SS') || '</div>'  created
  , DECODE(   account_status
            , 'OPEN'
            , '<div align="center"><b><font color="darkgreen">' || account_status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || account_status || '</font></b></div>') account_status
FROM
    dba_users
WHERE
    temporary_tablespace = 'SYSTEM'
ORDER BY
    username;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                  - OBJECTS IN THE SYSTEM TABLESPACE -                      |
-- +----------------------------------------------------------------------------+

prompt <a name="objects_in_the_system_tablespace"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Objects in the SYSTEM Tablespace</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner               FORMAT a75                   HEADING 'Owner'           ENTMAP off
COLUMN segment_name        FORMAT a125                  HEADING 'Segment Name'    ENTMAP off
COLUMN segment_type        FORMAT a75                   HEADING 'Type'            ENTMAP off
COLUMN tablespace_name     FORMAT a125                  HEADING 'Tablespace'      ENTMAP off
COLUMN bytes               FORMAT 999,999,999,999,999   HEADING 'MBytes|Alloc'    ENTMAP off
COLUMN extents             FORMAT 999,999,999,999,999   HEADING 'Extents'         ENTMAP off
COLUMN max_extents         FORMAT 999,999,999,999,999   HEADING 'Max|Ext'         ENTMAP off
COLUMN initial_extent      FORMAT 999,999,999,999,999   HEADING 'Initial|Ext'     ENTMAP off
COLUMN next_extent         FORMAT 999,999,999,999,999   HEADING 'Next|Ext'        ENTMAP off
COLUMN pct_increase        FORMAT 999,999,999,999,999   HEADING 'Pct|Inc'         ENTMAP off

BREAK ON report ON owner
COMPUTE count LABEL '<font color="#990000"><b>Total Count: </b></font>' OF segment_name ON report
COMPUTE sum   LABEL '<font color="#990000"><b>Total Bytes: </b></font>' OF bytes ON report

SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || owner || '</b></font></div>'    owner
  , segment_type
  , tablespace_name
  , SUM(bytes)/1024/1024 bytes
  , SUM(extents) extents
FROM
    dba_segments
WHERE
      owner NOT IN ('SYS','SYSTEM')
  AND tablespace_name = 'SYSTEM'
GROUP BY owner,segment_type,tablespace_name
ORDER BY
    owner
;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                              - RECYCLE BIN -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_recycle_bin"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Recycle Bin</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner               FORMAT a85                   HEADING 'Owner'           ENTMAP off
COLUMN original_name                                    HEADING 'Original|Name'   ENTMAP off
COLUMN type                                             HEADING 'Object|Type'     ENTMAP off
COLUMN object_name                                      HEADING 'Object|Name'     ENTMAP off
COLUMN ts_name                                          HEADING 'Tablespace'      ENTMAP off
COLUMN operation                                        HEADING 'Operation'       ENTMAP off
COLUMN createtime                                       HEADING 'Create|Time'     ENTMAP off
COLUMN droptime                                         HEADING 'Drop|Time'       ENTMAP off
COLUMN can_undrop                                       HEADING 'Can|Undrop?'     ENTMAP off
COLUMN can_purge                                        HEADING 'Can|Purge?'      ENTMAP off
COLUMN bytes               FORMAT 999,999,999,999,999   HEADING 'Bytes'           ENTMAP off

BREAK ON report ON owner
/* Ignored  by HeYaodong 20090609
SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || owner || '</b></font></div>'    owner
  , original_name
  , type
  , object_name
  , ts_name
  , operation
  , '<div nowrap align="right">'  || NVL(createtime, '<br>') || '</div>' createtime
  , '<div nowrap align="right">'  || NVL(droptime, '<br>')   || '</div>' droptime
  , DECODE(   can_undrop
            , null
            , '<BR>'
            , 'YES'
            , '<div align="center"><font color="darkgreen"><b>' || can_undrop || '</b></font></div>'
            , 'NO'
            , '<div align="center"><font color="#990000"><b>'   || can_undrop || '</b></font></div>'
            , '<div align="center"><font color="#663300"><b>'   || can_undrop || '</b></font></div>')   can_undrop
  , DECODE(   can_purge
            , null
            , '<BR>'
            , 'YES'
            , '<div align="center"><font color="darkgreen"><b>' || can_purge || '</b></font></div>'
            , 'NO'
            , '<div align="center"><font color="#990000"><b>'   || can_purge || '</b></font></div>'
            , '<div align="center"><font color="#663300"><b>'   || can_purge || '</b></font></div>')    can_purge
  , (space * p.blocksize) bytes
FROM
    dba_recyclebin r
  , (SELECT value blocksize FROM v$parameter WHERE name='db_block_size') p
ORDER BY
    owner
  , object_name;
*/
prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>






-- +============================================================================+
-- |                                                                            |
-- |         <<<<<     ONLINE ANALYTICAL PROCESSING - (OLAP)     >>>>>          |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Online Analytical Processing - (OLAP)</u></b></font></center>




-- +----------------------------------------------------------------------------+
-- |                          - MATERIALIZED VIEWS -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_olap_materialized_views"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Materialized Views</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner                FORMAT a75     HEADING 'Owner'               ENTMAP off
COLUMN mview_name           FORMAT a75     HEADING 'MView|Name'          ENTMAP off
COLUMN master_link          FORMAT a75     HEADING 'Master|Link'         ENTMAP off
COLUMN updatable            FORMAT a75     HEADING 'Updatable?'          ENTMAP off
COLUMN update_log           FORMAT a75     HEADING 'Update|Log'          ENTMAP off
COLUMN rewrite_enabled      FORMAT a75     HEADING 'Rewrite|Enabled?'    ENTMAP off
COLUMN refresh_mode         FORMAT a75     HEADING 'Refresh|Mode'        ENTMAP off
COLUMN refresh_method       FORMAT a75     HEADING 'Refresh|Method'      ENTMAP off
COLUMN build_mode           FORMAT a75     HEADING 'Build|Mode'          ENTMAP off
COLUMN fast_refreshable     FORMAT a75     HEADING 'Fast|Refreshable'    ENTMAP off
COLUMN last_refresh_type    FORMAT a75     HEADING 'Last Refresh|Type'   ENTMAP off
COLUMN last_refresh_date    FORMAT a75     HEADING 'Last Refresh|Date'   ENTMAP off
COLUMN staleness            FORMAT a75     HEADING 'Staleness'           ENTMAP off
COLUMN compile_state        FORMAT a75     HEADING 'Compile State'       ENTMAP off

BREAK ON owner

SELECT
    '<div align="left"><font color="#336699"><b>' || m.owner || '</b></font></div>'                    owner
  , m.mview_name                                                                                       mview_name
  , m.master_link                                                                                      master_link
  , '<div align="center">' || NVL(m.updatable,'<br>')        || '</div>'                               updatable
  , update_log                                                                                         update_log
  , '<div align="center">' || NVL(m.rewrite_enabled,'<br>')  || '</div>'                               rewrite_enabled
  , m.refresh_mode                                                                                     refresh_mode
  , m.refresh_method                                                                                   refresh_method
  , m.build_mode                                                                                       build_mode
  , m.fast_refreshable                                                                                 fast_refreshable
  , m.last_refresh_type                                                                                last_refresh_type
  , '<div nowrap align="right">' || TO_CHAR(m.last_refresh_date, 'mm/dd/yyyy HH24:MI:SS') || '</div>'  last_refresh_date
  , m.staleness                                                                                        staleness
  , DECODE(   m.compile_state
            , 'VALID'
            , '<div align="center"><font color="darkgreen"><b>' || m.compile_state || '</b></font></div>'
            , '<div align="center"><font color="#990000"><b>'   || m.compile_state || '</b></font></div>' ) compile_state
FROM
  dba_mviews     m 
ORDER BY
    owner
  , mview_name
/

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                        - MATERIALIZED VIEW LOGS -                          |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_olap_materialized_view_logs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Materialized View Logs</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN log_owner            FORMAT a75     HEADING 'Log Owner'            ENTMAP off
COLUMN log_table            FORMAT a75     HEADING 'Log Table'            ENTMAP off
COLUMN master               FORMAT a75     HEADING 'Master'               ENTMAP off
COLUMN log_trigger          FORMAT a75     HEADING 'Log Trigger'          ENTMAP off
COLUMN rowids               FORMAT a75     HEADING 'Rowids?'              ENTMAP off
COLUMN primary_key          FORMAT a75     HEADING 'Primary Key?'         ENTMAP off
COLUMN object_id            FORMAT a75     HEADING 'Object ID?'           ENTMAP off
COLUMN filter_columns       FORMAT a75     HEADING 'Filter Columns?'      ENTMAP off
COLUMN sequence             FORMAT a75     HEADING 'Sequence?'            ENTMAP off
COLUMN include_new_values   FORMAT a75     HEADING 'Include New Values?'  ENTMAP off

BREAK ON log_owner

SELECT
    '<div align="left"><font color="#336699"><b>' || ml.log_owner || '</b></font></div>'       log_owner
  , ml.log_table                                                              log_table
  , ml.master                                                                 master
  , ml.log_trigger                                                            log_trigger
  , '<div align="center">' || NVL(ml.rowids,'<br>')              || '</div>'  rowids
  , '<div align="center">' || NVL(ml.primary_key,'<br>')         || '</div>'  primary_key
  , '<div align="center">' || NVL(ml.object_id,'<br>')           || '</div>'  object_id
  , '<div align="center">' || NVL(ml.filter_columns,'<br>')      || '</div>'  filter_columns
  , '<div align="center">' || NVL(ml.sequence,'<br>')            || '</div>'  sequence
  , '<div align="center">' || NVL(ml.include_new_values,'<br>')  || '</div>'  include_new_values
FROM
    dba_mview_logs  ml
ORDER BY
    ml.log_owner
  , ml.master;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                   - MATERIALIZED VIEW REFRESH GROUPS -                     |
-- +----------------------------------------------------------------------------+

prompt <a name="dba_olap_materialized_view_refresh_groups"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Materialized View Refresh Groups</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN owner         FORMAT a75   HEADING 'Owner'        ENTMAP off
COLUMN name          FORMAT a75   HEADING 'Name'         ENTMAP off
COLUMN broken        FORMAT a75   HEADING 'Broken?'      ENTMAP off
COLUMN next_date     FORMAT a75   HEADING 'Next Date'    ENTMAP off
COLUMN interval      FORMAT a75   HEADING 'Interval'     ENTMAP off

BREAK ON report ON owner

SELECT
    '<div nowrap align="left"><font color="#336699"><b>' || rowner   || '</b></font></div>'  owner
  , '<div align="left">'                                 || rname    || '</div>'             name
  , '<div align="center">'                               || broken   || '</div>'             broken
  , '<div nowrap align="right">'                         || NVL(TO_CHAR(next_date, 'mm/dd/yyyy HH24:MI:SS'), '<br>') || '</div>'   next_date
  , '<div nowrap align="right">'                         || interval || '</div>'             interval
FROM
    dba_refresh 
ORDER BY
    rowner
  , rname
/

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +============================================================================+
-- |                                                                            |
-- |                     <<<<<     CES    >>>>>  				                        |
-- |                                                                            |
-- +============================================================================+
-- +----------------------------------------------------------------------------+
-- |                      -Sysaux Usage-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Sysaux Usage"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sysaux Usage</b></font><hr align="left" width="460">


SELECT OCCUPANT_NAME,
       round(SPACE_USAGE_KBYTES/1024 ,2) as Size_MB
FROM V$SYSAUX_OCCUPANTS
where SPACE_USAGE_KBYTES/1024 >128
ORDER BY 2,1 ;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Undo state-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="undo state"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>undo stat</b></font><hr align="left" width="460">


select * from (
select to_char(BEGIN_TIME,'yyyymmdd hh24:mi:ss' ) BEGIN_TIME        ,
       to_char(END_TIME ,'yyyymmdd hh24:mi:ss' ) END_TIME           ,
 DBID                ,
 INSTANCE_NUMBER     ,
 SNAP_ID             ,
 UNDOTSN             ,
 UNDOBLKS            ,
 TXNCOUNT            ,
 MAXQUERYLEN         ,
 MAXQUERYSQLID       ,
 MAXCONCURRENCY      ,
 ACTIVEBLKS          ,
 UNEXPIREDBLKS       ,
 EXPIREDBLKS         ,
 TUNED_UNDORETENTION 
 from dba_hist_undostat
 order by snap_id desc)
 where rownum < 41
   order by instance_number,snap_id ;

-- +----------------------------------------------------------------------------+
-- |                      - Open Cursors-   								                    |
-- +----------------------------------------------------------------------------+

prompt <a name="open_cursors"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Open Cursors</b></font><hr align="left" width="460">

prompt <table width="90%" border="1"> -
<tr><th align="left" width="30%">Max Cursor Limit Per Session</th><td width="70%"><tt>&_max_cursor_limit</tt></td></tr> -
</table>

CLEAR COLUMNS BREAKS COMPUTES

SELECT 
	sid, cursors max_cursor from (
select sid,count(*) cursors from v$open_cursor
group by sid 
order by 2 desc
) 
where rownum <5;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                      - Index Unusable or Invalid-	  	                    |
-- +----------------------------------------------------------------------------+

prompt <a name="index_invalid"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Index Invalid</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

SELECT OWNER,INDEX_NAME
      FROM   dba_indexes 
      WHERE  status<>'VALID'
      AND    partitioned <> 'YES'
      UNION ALL
SELECT INDEX_OWNER,INDEX_NAME
      FROM   dba_ind_partitions 
      WHERE  status<>'USABLE'
      UNION ALL
SELECT INDEX_OWNER,INDEX_NAME
      FROM   dba_ind_subpartitions 
      WHERE  status<>'USABLE';


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


-- +----------------------------------------------------------------------------+
-- |                      - Index seems need rebuild-    		                    |
-- +----------------------------------------------------------------------------+

prompt <a name="index_need_rebuild"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Index seems need rebuild</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

column owner for a10;
column INDEX_NAME for a25;
column TABLESPACE_NAME for a20;

SELECT owner,
       INDEX_NAME ,
       TABLESPACE_NAME,
       NUM_ROWS,
       DISTINCT_KEYS "DISTINCT",
       BLEVEL "LEVEL",
       AVG_LEAF_BLOCKS_PER_KEY "ALFBPKEY"
  FROM dba_indexes
 WHERE BLEVEL >= 4
   and PARTITIONED = 'NO'
   and owner not in ('SYS', 'SYSTEM', 'OUTLN', 'WMSYS')
union all
SELECT index_owner owner,
       INDEX_NAME "NAME",
       TABLESPACE_NAME,
       NUM_ROWS,
       DISTINCT_KEYS "DISTINCT",
       BLEVEL "LEVEL",
       AVG_LEAF_BLOCKS_PER_KEY "ALFBPKEY"
  FROM dba_ind_partitions
 WHERE BLEVEL >= 4
   and COMPOSITE = 'NO'
   and index_owner not in ('SYS', 'SYSTEM', 'OUTLN', 'WMSYS')
union all
SELECT index_owner owner,
       INDEX_NAME "NAME",
       TABLESPACE_NAME,
       NUM_ROWS,
       DISTINCT_KEYS "DISTINCT",
       BLEVEL "LEVEL",
       AVG_LEAF_BLOCKS_PER_KEY "ALFBPKEY"
  FROM dba_ind_subpartitions
 WHERE BLEVEL >= 4
   and index_owner not in ('SYS', 'SYSTEM', 'OUTLN', 'WMSYS');




prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


-- +----------------------------------------------------------------------------+
-- |                      - Table may need update Statistics-                   |
-- +----------------------------------------------------------------------------+

prompt <a name="tables_need_stats"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Table needs update Statistics</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

select *
  from (select table_name,
               last_analyzed,
               s.bytes / 1024 / 1024 / 1024 size_G
          from dba_tables t,
               (select segment_name, sum(bytes) bytes
                  from dba_segments
                 where segment_type like '%TABLE%'
                   and owner not in ('SYS', 'SYSTEM', 'OUTLN', 'WMSYS')
                 group by segment_name
                having sum(bytes) > 500000000000) s --500M
         where t.owner not in ('SYS', 'SYSTEM', 'OUTLN', 'WMSYS')
           and last_analyzed < sysdate - 100
           and t.table_name = s.segment_name
         order by 3 desc)
 where rownum <= 10;
 
prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


-- +----------------------------------------------------------------------------+
-- |                      - ASM DISKGROUP USAGE-                   |
-- +----------------------------------------------------------------------------+

prompt <a name="ASM DISKGROUP USAGE"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM DISKGROUP USAGE</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES


SELECT NAME,
       STATE,
       TYPE,
       TOTAL_MB,
       FREE_MB,
       round((TOTAL_MB - FREE_MB)/TOTAL_MB,2)||'%' AS USAGE_PCT,
       VOTING_FILES
  FROM V$ASM_DISKGROUP ;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


-- +----------------------------------------------------------------------------+
-- |                      - 10g auto statistics info-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="auto_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>10g auto statistics info</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

Select to_char(actual_start_date, 'D') weekdays,
       to_char(sysdate, 'D') todayweek,
       run_duration,
       to_char(actual_start_date, 'YYYYMMDD') start_date
  from dba_scheduler_job_run_details
 where job_name = 'GATHER_STATS_JOB'
   and actual_start_date > sysdate - 10
 order by actual_start_date asc;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - 11g auto statistics info-                           |
-- +----------------------------------------------------------------------------+
prompt <a name="11g auto_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>11g auto statistics info</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

SELECT w.window_name,
       w.repeat_interval,
       w.duration, 
       w.enabled
FROM dba_autotask_window_clients c,
     dba_scheduler_windows w
WHERE c.window_name = w.window_name
  AND c.optimizer_stats = 'ENABLED';

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -  Important hidden params-                           |
-- +----------------------------------------------------------------------------+

prompt <a name=" Important hidden param"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b> Important hidden params</b></font><hr align="left" width="460">
SELECT x.ksppinm NAME, 
       y.ksppstvl VALUE, 
       x.ksppdesc describ
  FROM SYS.x$ksppi x, 
       SYS.x$ksppcv y
WHERE x.inst_id = USERENV ('Instance')
  AND y.inst_id = USERENV ('Instance')
  AND x.indx = y.indx
  AND ( x.ksppinm LIKE '%optimizer_use_feedback%' or
        x.ksppinm LIKE '%use_adaptive_log_file_sync%' or
        x.ksppinm LIKE '%px_use_large_pool%' or
        x.ksppinm LIKE '%undo_autotune%' or
        x.ksppinm LIKE '%gc_policy_time%' or
        x.ksppinm LIKE '%gc_undo_affinity%' or
        x.ksppinm LIKE '%gc_defer_time%' or
        x.ksppinm LIKE '%_gc_affinity%' or
        x.ksppinm LIKE '%optimizer_adaptive_cursor_sharing%' or
        x.ksppinm LIKE '%optimizer_extended_cursor_sharing%' or
        x.ksppinm LIKE '%optimizer_extended_cursor_sharing_rel%' 
       );


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>
-- +----------------------------------------------------------------------------+
-- |                      - Optimizer params-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Optimizer params"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Optimizer params</b></font><hr align="left" width="460">
SELECT x.ksppinm NAME,
       y.ksppstvl VALUE,
       x.ksppdesc describ
  FROM SYS.x$ksppi x,
       SYS.x$ksppcv y
WHERE x.inst_id = USERENV ('Instance')
  AND y.inst_id = USERENV ('Instance')
  AND x.indx = y.indx
  AND x.ksppinm LIKE '%optimizer%' ;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - DB profiles-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="11g auto_statistics"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>DB profiles</b></font><hr align="left" width="460">

select * from dba_profiles ;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -history sga stat-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="history sga stat"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>history sga stat</b></font><hr align="left" width="460">


select * from (
select * from dba_hist_sgastat order by snap_id desc )
where rownum < 41
order by instance_number,name,snap_id ; 


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -history pga stat-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="history pga stat"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>history pga stat</b></font><hr align="left" width="460">


select * from (
select * from dba_hist_pgastat order by snap_id desc )
where rownum < 41
order by instance_number,name,snap_id ; 


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Table without index-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Table without index"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Table without index</b></font><hr align="left" width="460">

select owner,table_name from dba_tables where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
MINUS
select TABLE_owner,table_name from dba_INDEXES where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX')) ;



prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - Disabled Constraints-                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Disabled Constraints"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Disabled Constraints</b></font><hr align="left" width="460">

SELECT OWNER,
       CONSTRAINT_NAME,
       CONSTRAINT_TYPE,
       TABLE_NAME
 FROM DBA_CONSTRAINTS 
WHERE STATUS='DISABLED';


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - Top 50 SQL WITH Too Many SQL Child-                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Top 50 SQL WITH Too Many SQL Child"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 50 SQL WITH Too Many SQL Child</b></font><hr align="left" width="460">

select * from
(select sql_id,
       FORCE_MATCHING_SIGNATURE,
       CHILD_NUMBER
  from v$sql
 where child_number > 16
  order by 3 desc)
  order by 3 desc;



-- +----------------------------------------------------------------------------+
-- |                      - Seuqnce usage greate than 70% -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Seuqnce usage greate than 70% "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Seuqnce usage greate than 70%  </b></font><hr align="left" width="460">

select SEQUENCE_OWNER , 
       SEQUENCE_NAME ,
       round((case
               when INCREMENT_BY < 0 then
                abs(a.last_number - a.MAX_VALUE) / abs(a.max_value - MIN_VALUE)
               when INCREMENT_BY > 0 then
                abs(a.last_number - a.MIN_VALUE) / abs(a.max_value - MIN_VALUE)
             end),
             0) , 
       MIN_VALUE , 
       MAX_VALUE ,
       INCREMENT_BY , 
       CYCLE_FLAG , 
       ORDER_FLAG ,
       CACHE_SIZE , 
       LAST_NUMBER
  from dba_sequences a
 where cycle_flag = 'N'
   and round(100 * (case
               when INCREMENT_BY < 0 then
                abs(a.last_number - a.MAX_VALUE) / abs(a.max_value - MIN_VALUE)
               when INCREMENT_BY > 0 then
                abs(a.last_number - a.MIN_VALUE) / abs(a.max_value - MIN_VALUE)
             end),
             0) >= 70 ;



-- +----------------------------------------------------------------------------+
-- |                      - PGA allocate history -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="PGA allocate history "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>PGA allocate history  </b></font><hr align="left" width="460">

with tmp_pga_warning as
( select round((case
                when (select value
                        from v$parameter
                       where name like 'pga_aggregate_target') > 0 then
                 (select value
                    from v$parameter
                   where name like 'pga_aggregate_target')
                when (select value
                        from v$parameter
                       where name like 'pga_aggregate_target') = 0 then
                 (select value from v$parameter where name like 'memory_target')
              end) / 1024 / 1024,
              0) as value
   from dual)
select to_char(b.end_interval_time, 'yyyymmdd hh24') as end_interval_time  ,
       round(a.value / 1024 / 1024, 1) as allocate_value  ,
       c.value setting_value
  from dba_hist_pgastat a, dba_hist_snapshot b,tmp_pga_warning c
 where a.name = 'total PGA allocated'
   and a.snap_id = b.snap_id
   and a.instance_number = b.instance_number
   and a.instance_number = (select instance_number from v$instance)
   and b.end_interval_time >= sysdate - 7
 order by 1
  ;




prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Table without PK-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Table without PK"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Table without PK</b></font><hr align="left" width="460">


PROMPT --TABLE NO PK OR UNIQUE
select owner,table_name from dba_tables where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
MINUS
select owner,table_name 
from dba_CONSTRAINTS 
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX')) 
  AND constraint_type = 'P' OR (constraint_type = 'U');
       

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Foreigrn Key without index-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Foreigrn Key without index"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Foreigrn Key without index</b></font><hr align="left" width="460">


select owner,table_name
  from (SELECT /*+ rule */
         acc.owner, acc.table_name, acc.column_name, acc.position
          FROM dba_cons_columns acc, dba_constraints ac
         WHERE ac.constraint_name = acc.constraint_name
           AND ac.constraint_type = 'R'
           and ac.owner  in
               (select /*+ no_merge */
                 username
                  from dba_users
                 where default_tablespace not in
                       ('SYSTEM', 'SYSAUX'))
        MINUS
        SELECT /*+ rule */
         table_owner owner, table_name, column_name, column_position
          FROM dba_ind_columns
         where index_owner  in
               (select /*+ no_merge */
                 username
                  from dba_users
                 where default_tablespace not in
                       ('SYSTEM', 'SYSAUX')))
 ORDER BY owner,table_name, position, column_name;
 


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -User with sysdba or sysoper-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="User with sysdba or sysoper"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User with sysdba or sysoper</b></font><hr align="left" width="460">


select * from V$PWFILE_USERS;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -User privikege-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="User privikege"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User privikege</b></font><hr align="left" width="460">

SELECT grantee,privilege
from dba_sys_privs
where grantee in (select username from dba_users where default_tablespace not in ('SYSTEM','SYSAUX'))
UNION
SELECT GRANTEE, GRANTED_ROLE
FROM DBA_ROLE_PRIVS
WHERE GRANTEE in (select username from dba_users where default_tablespace not in ('SYSTEM','SYSAUX')) ;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -User TableSpace quotas-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="User TableSpace quotas"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User TableSpace quotas</b></font><hr align="left" width="460">

SELECT USERNAME ,
       TABLESPACE_NAME ,
       DECODE(MAX_BYTES,-1,'UNLIMITED',MAX_BYTES/1024/1024) QUOTA_MB
FROM DBA_TS_QUOTAS;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Table defragment-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Table defragment"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Table defragment</b></font><hr align="left" width="460">

SELECT EST.OWNER,
       EST.TABLE_NAME,
       EST.est_size_mb,
       ACT.act_size_mb,
       ROUND((1-EST.est_size_mb/ACT.act_size_mb)*100,2) AS PCT
FROM 
(select owner ,table_name,round(avg_row_len*nvl(num_rows,0)/1024/1024/0.85,0) as est_size_mb
from dba_tables
where OWNER IN (SELECT USERNAME FROM DBA_USERS WHERE DEFAULT_TABLESPACE NOT IN ('SYSTEM','SYSAUX'))) est,
(select owner,segment_name,NVL(round(sum(bytes)/1024/1024,0),0.0000000001) as act_size_mb
from dba_segments
where OWNER IN (SELECT USERNAME FROM DBA_USERS WHERE DEFAULT_TABLESPACE NOT IN ('SYSTEM','SYSAUX'))
  and segment_type like '%TABLE%'
GROUP BY OWNER,SEGMENT_NAME
) ACT
WHERE EST.OWNER = ACT.OWNER
  AND EST.TABLE_NAME =  ACT.SEGMENT_NAME
  AND ACT.act_size_mb >=512
  and ROUND((1-EST.est_size_mb/ACT.act_size_mb)*100,2) >=50
ORDER BY 5
;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -OBJECT AUDIT-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="OBJECT AUDIT"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>OBJECT AUDIT</b></font><hr align="left" width="460">

SELECT * 
  FROM DBA_OBJ_AUDIT_OPTS ;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Privilege  AUDIT-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Privilege  AUDIT"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Privilege  AUDIT</b></font><hr align="left" width="460">

SELECT * 
  FROM DBA_PRIV_AUDIT_OPTS ;

 
prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Statement AUDIT-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Statement AUDIT"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Statement AUDIT</b></font><hr align="left" width="460">


select *
  from DBA_STMT_AUDIT_OPTS;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Archive Gap for DataGuard-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Archive Gap for DataGuard"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archive Gap for DataGuard</b></font><hr align="left" width="460">


select * 
  from v$archive_gap;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      -Archive Gap detail for DataGuard-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Archive Gap detail for DataGuard"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archive Gap detail for DataGuard</b></font><hr align="left" width="460">


select * 
  from v$managed_standby;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - NLS PARAMETERS-                               |
-- +----------------------------------------------------------------------------+

prompt <a name="NLS PARAMETERS"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>NLS PARAMETERS</b></font><hr align="left" width="460">

select * from nls_database_parameters  ;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - BLOCK CHANGE TRACKING -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="BLOCK CHANGE TRACKING "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>BLOCK CHANGE TRACKING </b></font><hr align="left" width="460">

select * from V$BLOCK_CHANGE_TRACKING;



prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>
-- +----------------------------------------------------------------------------+
-- |                      - SYSAUX OCCUPANTS > 128 MB-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="SYSAUX OCCUPANTS"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SYSAUX OCCUPANTS</b></font><hr align="left" width="460">

SELECT occupant_name "Item", 
       space_usage_kbytes / 1024 "Space Used (MB)", 
       schema_name "Schema", 
       move_procedure "Move Procedure" 
  FROM v$sysaux_occupants 
ORDER BY 1;




prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>
-- +----------------------------------------------------------------------------+
-- |                      - Top 10 segment In SYSAUX AND SIZE > 128 MB-                           |
-- +----------------------------------------------------------------------------+

prompt <a name="Top 10 segment In SYSAUX AND SIZE > 128 MB"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 10 segment In SYSAUX AND SIZE > 128 MB</b></font><hr align="left" width="460">
SELECT OWNER,SEGMENT_NAME,SEGMENT_TYPE,SIZE_MB
FROM 
(select OWNER,SEGMENT_NAME,SEGMENT_TYPE,SUM(BYTES)/1024/0124 AS Size_MB
  from dba_segments
 where tablespace_name  = 'SYSAUX'
 GROUP BY OWNER,SEGMENT_NAME,SEGMENT_TYPE
 HAVING SUM(BYTES)/1024/0124> 128
 ORDER BY 4 DESC)
where rownum < 11 ;


-- +----------------------------------------------------------------------------+
-- |                      - Table and it's index with different owner -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Table and it's index with different owner "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Table and it's index with different owner  </b></font><hr align="left" width="460">

select b.owner,b.table_owner, b.table_name, b.index_name
  from dba_indexes b
 where b.OWNER<> b.table_owner
   and b.table_owner not in (
   'MGMT_VIEW' 
,'SYS'
,'SYSTEM'
,'DBSNMP'
,'SYSMAN'
,'OUTLN'
,'FLOWS_FILES'
,'MDSYS'
,'ORDDATA'
,'ORDSYS'
,'ANONYMOUS'
,'EXFSYS'
,'WMSYS'
,'XDB'
,'APPQOSSYS'
,'ORDPLUGINS'
,'APEX_030200'
,'SI_INFORMTN_SCHEMA'
,'DIP'
,'APEX_PUBLIC_USER'
,'ORACLE_OCM'
,'XS$NULL'
);


-- +----------------------------------------------------------------------------+
-- |                      - Disable trigger -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Disable triggers "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Disable triggers  </b></font><hr align="left" width="460">

SELECT 
		 OWNER                             ,
		 TRIGGER_NAME                      ,
		 TRIGGER_TYPE                      ,
		 TRIGGERING_EVENT                  ,
		 TABLE_OWNER                       ,
		 BASE_OBJECT_TYPE                  ,
		 TABLE_NAME                        ,
		 COLUMN_NAME                       ,
		 REFERENCING_NAMES                 ,
		 WHEN_CLAUSE                       ,
		 STATUS                            ,
		 DESCRIPTION                       ,
		 ACTION_TYPE
  FROM DBA_TRIGGERS
 WHERE STATUS = 'DISABLED'
   AND OWNER not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX'));


-- +----------------------------------------------------------------------------+
-- |                      - Disable constraints -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Disable constraints  "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Disable constraints </b></font><hr align="left" width="460">

SELECT 
		 OWNER                    ,
		 CONSTRAINT_NAME          ,
		 CONSTRAINT_TYPE          ,
		 TABLE_NAME               ,
		 R_OWNER                  ,
		 R_CONSTRAINT_NAME        ,
		 DELETE_RULE              ,
		 STATUS                   ,
		 DEFERRABLE               ,
		 DEFERRED                 ,
		 VALIDATED                ,
		 GENERATED                ,
		 BAD                      ,
		 RELY                     ,
		 LAST_CHANGE              ,
		 INDEX_OWNER              ,
		 INDEX_NAME               ,
		 INVALID                  ,
		 VIEW_RELATED
  FROM DBA_CONSTRAINTS
 WHERE STATUS = 'DISABLED' 
   AND OWNER not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX')) ;



prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - Snapshot Information-                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Snapshot_infor_perf"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SnapShot info of AWR(only for 10g)</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

select count(1) now_sum,7*24*4 standard_sum,
to_char(min(BEGIN_INTERVAL_TIME),'YYYYMMDD') min_day,
to_char(max(BEGIN_INTERVAL_TIME),'YYYYMMDD') max_day
from dba_hist_snapshot;


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - Snapshot Detail -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Snapshot Detail "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Snapshot Detail </b></font><hr align="left" width="460">


select * from (
select 
 SNAP_ID,                            
 DBID ,                              
 INSTANCE_NUMBER ,                   
 to_char(STARTUP_TIME,'yyyymmdd hh24:mi:ss') as   STARTUP_TIME,                     
 TO_CHAR(BEGIN_INTERVAL_TIME ,'YYYYMMDD HH24:MI:SS')  as BEGIN_INTERVAL_TIME ,            
 TO_CHAR(END_INTERVAL_TIME   ,'YYYYMMDD HH24:MI:SS')  as END_INTERVAL_TIME ,                                 
 SNAP_LEVEL        ,                 
 ERROR_COUNT                        
 from dba_hist_snapshot 
 order by snap_id desc)
 where rownum < 40
 order by snap_id asc,instance_number asc ;
prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>

-- +----------------------------------------------------------------------------+
-- |                      - Resouce Limits-                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Resouce Limits  "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b> Resouce Limits  </b></font><hr align="left" width="460">


select * from  v$resource_limit;


-- +----------------------------------------------------------------------------+
-- |                      - Backgroubd Process -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Backgroubd Process "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Backgroubd Process </b></font><hr align="left" width="460">


 SELECT s.inst_id,
       s.sid ,
       b.name,
       p.spid ,
       b.description 
 FROM gv$session s,gv$bgprocess b,gv$process p
 WHERE s.paddr = b.paddr
   AND s.paddr = p.addr
   and s.inst_id=b.inst_id
   and s.inst_id=p.inst_id
 ORDER BY s.inst_id,s.sid;


-- +----------------------------------------------------------------------------+
-- |                      - Timezone -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Timezone"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Timezone </b></font><hr align="left" width="460">


select dbtimezone from dual;


-- +----------------------------------------------------------------------------+
-- |                      - LMS process for every node -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="LMS process for every node"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>LMS process for every node </b></font><hr align="left" width="460">


 select inst_id,sid,status,program from gv$session where program like '%LMS%';


-- +----------------------------------------------------------------------------+
-- |                      - Parallel Rollback -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Parallel Rollback "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Parallel Rollback  </b></font><hr align="left" width="460">

 select * from v$fast_start_transactions;



-- +----------------------------------------------------------------------------+
-- |                      - CPU Usage -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="CPU Usage "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>CPU Usage </b></font><hr align="left" width="460">

set heading on
set echo off
set flush off
set pagesize 9000
set linesize 200
set long 100000
col begin_interval_time for a30
col stat_name for a30
select to_char(c.begin_interval_time,'yyyymmdd-hh24:mi:ss') begin_time, b.instance_number, b.value/f.cpuvalue*100 "idle%"
  from sys.wrh$_osstat_name a,
       sys.wrh$_osstat b,
       sys.WRM$_SNAPSHOT c,
       (select d.dbid, e.instance_number, e.snap_id, sum(value) cpuvalue
          from sys.wrh$_osstat_name d, sys.wrh$_osstat e
         where d.stat_name in ('IDLE_TIME', 'BUSY_TIME') and d.stat_id=e.stat_id
         group by d.dbid, e.instance_number, e.snap_id) f
 where a.stat_name = 'IDLE_TIME'
   and a.dbid = b.dbid
   and a.stat_id = b.stat_id
   and b.snap_id = c.snap_id
   and b.dbid = c.dbid
   and b.instance_number = c.instance_number
   and f.dbid = a.dbid
   and f.instance_number = b.instance_number
   and f.snap_id = b.snap_id
   and c.begin_interval_time>sysdate-7
 order by 2, 1, 3;



-- +----------------------------------------------------------------------------+
-- |                      - Trans per second -                               |
-- +----------------------------------------------------------------------------+



prompt <a name="Trans per second"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Trans per second </b></font><hr align="left" width="460">




select snap_id,
       to_char(to_date(end_interval_time_prev,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_prev,
       to_char(to_date(end_interval_time,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_end,
       (to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600 as seconds,
       (value - value_prev) value_total,
       (value - value_prev)/((to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600) as per_second
from 
    (select  snap_id,
            end_interval_time,
            value,
            lag(value) over(order by snap_id) value_prev,
            lag(end_interval_time) over(order by snap_id) end_interval_time_prev
    from 
        (select a.snap_id,
                to_char(b.end_interval_time,'yyyymmddhh24miss') end_interval_time,
               sum(a.value) as value
          from dba_hist_sysstat a,
               dba_hist_snapshot b
         where a.snap_id = b.snap_id
           and a.dbid = &_DBID 
           and a.instance_number = &_instance_number
           and a.stat_name in ('user commits','user rollbacks')
           and b.end_interval_time >= sysdate - 7 
           and to_char(b.end_interval_time, 'yyyymmddhh24mi') > &startup_time
           group by a.snap_id, 
                 to_char(b.end_interval_time, 'yyyymmddhh24miss')
           order by a.snap_id,to_char(b.end_interval_time, 'yyyymmddhh24miss') 
        )
       )
 where value_prev is not null
   and end_interval_time_prev is not null
 order by snap_id ;


-- +----------------------------------------------------------------------------+
-- |                      - DB Time per second -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="DB Time per second  "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>DB Time per second   </b></font><hr align="left" width="460">


select snap_id,
       to_char(to_date(end_interval_time_prev,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_prev,
       to_char(to_date(end_interval_time,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_end,
       (to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600 as seconds,
       (value - value_prev) value_total,
       (value - value_prev)/((to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600) as per_second
from 
    (select  snap_id,
            end_interval_time,
            value,
            lag(value) over(order by snap_id) value_prev,
            lag(end_interval_time) over(order by snap_id) end_interval_time_prev
    from 
        (select a.snap_id,
                to_char(b.end_interval_time,'yyyymmddhh24miss') end_interval_time,
               sum(a.value) as value
          from dba_hist_sysstat a,
               dba_hist_snapshot b
         where a.snap_id = b.snap_id
           and a.dbid = &_DBID 
           and a.instance_number = &_instance_number
           and a.stat_name in ('DB time')
           and b.end_interval_time >= sysdate - 7 
           and to_char(b.end_interval_time, 'yyyymmddhh24mi') > &startup_time
           group by a.snap_id, 
                 to_char(b.end_interval_time, 'yyyymmddhh24miss')
           order by a.snap_id,to_char(b.end_interval_time, 'yyyymmddhh24miss') 
        )
       )
 where value_prev is not null
   and end_interval_time_prev is not null
 order by snap_id ;


-- +----------------------------------------------------------------------------+
-- |                      - Physical Read per second -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="Physical Read per second "></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Physical Read per second   </b></font><hr align="left" width="460">


select snap_id,
       to_char(to_date(end_interval_time_prev,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_prev,
       to_char(to_date(end_interval_time,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_end,
       (to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600 as seconds,
       (value - value_prev) value_total,
       (value - value_prev)/((to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600) as per_second,
      ((value - value_prev)/((to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600) * &_blocksize / 1024 / 1024) as Mb_ps
from 
    (select  snap_id,
            end_interval_time,
            value,
            lag(value) over(order by snap_id) value_prev,
            lag(end_interval_time) over(order by snap_id) end_interval_time_prev
    from 
        (select a.snap_id,
                to_char(b.end_interval_time,'yyyymmddhh24miss') end_interval_time,
               sum(a.value) as value
          from dba_hist_sysstat a,
               dba_hist_snapshot b
         where a.snap_id = b.snap_id
           and a.dbid = &_DBID 
           and a.instance_number = &_instance_number
           and a.stat_name in ('physical reads')
           and b.end_interval_time >= sysdate - 7 
           and to_char(b.end_interval_time, 'yyyymmddhh24mi') > &startup_time
           group by a.snap_id, 
                 to_char(b.end_interval_time, 'yyyymmddhh24miss')
           order by a.snap_id,to_char(b.end_interval_time, 'yyyymmddhh24miss') 
        )
       )
 where value_prev is not null
   and end_interval_time_prev is not null
 order by snap_id ;




-- +----------------------------------------------------------------------------+
-- |                      - session logical reads per second -                               |
-- +----------------------------------------------------------------------------+

prompt <a name="session logical reads per second"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>session logical reads per second</b></font><hr align="left" width="460">



select snap_id,
       to_char(to_date(end_interval_time_prev,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_prev,
       to_char(to_date(end_interval_time,'yyyymmdd hh24miss'),'yyyymmdd hh24miss') time_end,
       (to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600 as seconds,
       (value - value_prev) value_total,
       (value - value_prev)/((to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600) as per_second,
       ((value - value_prev)/((to_date(end_interval_time,'yyyymmddhh24miss') - to_date(end_interval_time_prev,'yyyymmddhh24miss'))*24*3600) * &_blocksize / 1024 / 1024) as Mb_ps
from 
    (select  snap_id,
            end_interval_time,
            value,
            lag(value) over(order by snap_id) value_prev,
            lag(end_interval_time) over(order by snap_id) end_interval_time_prev
    from 
        (select a.snap_id,
                to_char(b.end_interval_time,'yyyymmddhh24miss') end_interval_time,
               sum(a.value) as value
          from dba_hist_sysstat a,
               dba_hist_snapshot b
         where a.snap_id = b.snap_id
           and a.dbid = &_DBID 
           and a.instance_number = &_instance_number
           and a.stat_name in ('session logical reads')
           and b.end_interval_time >= sysdate - 7 
           and to_char(b.end_interval_time, 'yyyymmddhh24mi') > &startup_time
           group by a.snap_id, 
                 to_char(b.end_interval_time, 'yyyymmddhh24miss')
           order by a.snap_id,to_char(b.end_interval_time, 'yyyymmddhh24miss') 
        )
       )
 where value_prev is not null
   and end_interval_time_prev is not null
 order by snap_id ;
    


-- +----------------------------------------------------------------------------+
-- |                            - END OF REPORT -                               |
-- +----------------------------------------------------------------------------+

SPOOL OFF

SET MARKUP HTML OFF

SET TERMOUT ON

prompt 
prompt Output written to: &FileName._&_dbname._&_spool_time..html

--EXIT;
