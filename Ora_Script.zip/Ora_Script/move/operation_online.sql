@Gather_info.sql

@gen_move_default_attrbute.sql

@gen_restore_parallel_logging_all.sql


--����Ự
alter session set nls_date_format='YYYYMMDD HH24:MI:SS'

set lines 200 pages 1000
col status format a30

select username ,
      status,
      count(*) 
 from v$session 
 group by username,status 
 order by username,status ;

set lines 200 pages 1000
col username fromat a30
select username,
       count(*) 
 from v$session
 where taddr is not null 
 group by username;
 
select username,sid,serial#,status,last_call_et,LOGON_TIME,TADDR
FROM V$SESSION
WHERE TADDR IS NOT NULL;



--����ͳ����Ϣ

EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'CGS_EDW'     ,STATTAB=>'STAT_CGS_EDW',      TBLSPACE=>'FDM_S_DATA_N');
EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'CGS_TEST'    ,STATTAB=>'STAT_CGS_TEST',     TBLSPACE=>'FDM_S_DATA_N');
EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'EDW_CODE'    ,STATTAB=>'STAT_EDW_CODE',     TBLSPACE=>'FDM_S_DATA_N');
EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'HIS_FDM'     ,STATTAB=>'STAT_HIS_FDM',      TBLSPACE=>'FDM_S_DATA_N');
EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'HIS_ODM_CBS' ,STATTAB=>'STAT_HIS_ODM_CBS',  TBLSPACE=>'FDM_S_DATA_N');
EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'HIS_SDM'     ,STATTAB=>'STAT_HIS_SDM',      TBLSPACE=>'FDM_S_DATA_N');
EXEC DBMS_STATS.CREATE_STAT_TABLE(OWNNAME=>'PETL'        ,STATTAB=>'STAT_PETL',         TBLSPACE=>'FDM_S_DATA_N');

EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'CGS_EDW'     ,STATTAB=>'STAT_CGS_EDW',      STAOWN=>'CGS_EDW'    ); 
EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'CGS_TEST'    ,STATTAB=>'STAT_CGS_TEST',     STAOWN=>'CGS_TEST'   );
EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'EDW_CODE'    ,STATTAB=>'STAT_EDW_CODE',     STAOWN=>'EDW_CODE'   );
EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'HIS_FDM'     ,STATTAB=>'STAT_HIS_FDM',      STAOWN=>'HIS_FDM'    );
EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'HIS_ODM_CBS' ,STATTAB=>'STAT_HIS_ODM_CBS',  STAOWN=>'HIS_ODM_CBS');
EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'HIS_SDM'     ,STATTAB=>'STAT_HIS_SDM',      STAOWN=>'HIS_SDM'    );
EXEC DBMS_STATS.EXPORT_SCHEMA_STATS(OWNNAME=>'PETL'        ,STATTAB=>'STAT_PETL',         STAOWN=>'PETL'       );


purge dba_recyclebin;

--��¼����״̬��������Ƚϼ���״̬

lsnrctl status

lsnrctl service

lsnrctl stop

--Ǩ���漰�����û���ÿ���û�ִ��һ��
@gen_move_lob.sql

@gen_move_nopart_all.sql

@gen_move_part_table.sql

@gen_move_subpart_table.sql

@gen_move_part_index.sql

@gen_move_subpart_index.sql


ִ��Ǩ��

Ǩ�ƺ�ִ�У�

@restore_parallel_logging_ALL.sql


���ԭǨ�Ʊ��ռ䣬û���κζ���󣬲���ִ�б��ռ��л�

select sum(bytes) from dba_segments where tablespace_name  ='FDM_S_DATA';

SELECT ONWER,COUNT(*) from dba_segments where tablespace_name  ='FDM_S_DATA' GROUP BY OWNER;

SELECT ONWER,SEGMENT_NAME,SEGMENT_TYPE FROM dba_segments where tablespace_name  ='FDM_S_DATA';

���ռ��л���
alter tablespace FDM_S_DATA rename to FDM_S_DATA_orig;
alter tablespace FDM_S_DATA_N rename to FDM_S_DATA;
             
                                                                   
alter user TEMP_USER  default tablespace              FDM_S_DATA ; 
alter user CGS_TEST   default tablespace              FDM_S_DATA ; 
alter user EDW_CODE   default tablespace              FDM_S_DATA ; 
alter user PETL       default tablespace              FDM_S_DATA ; 
alter user CGS_EDW    default tablespace              FDM_S_DATA ;


--����û�ȱʡ���ռ�
select username ,default_tablespace from dba_users;


@Gather_info.sql
�Ƚϱ��ǰ�������Ϣ

diff old new


--�����ռ�ͳ����Ϣ                                                                           
exec dbms_stats.gather_schema_stats('TEMP_USER',cascade=>true,degree=>12) ;
exec dbms_stats.gather_schema_stats('CGS_TEST' ,cascade=>true,degree=>12) ;
exec dbms_stats.gather_schema_stats('EDW_CODE' ,cascade=>true,degree=>12) ;
exec dbms_stats.gather_schema_stats('PETL'     ,cascade=>true,degree=>12) ;
exec dbms_stats.gather_schema_stats('CGS_EDW'  ,cascade=>true,degree=>12) ;

--��������

lsnrctl start

alter system register ;

��¼����״̬
lsnrctl status
lsnrctl service

�Ƚϱ��ǰ�����״̬
