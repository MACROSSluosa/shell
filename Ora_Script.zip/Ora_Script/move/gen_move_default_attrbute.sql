set lines 400 pages 49999 

set echo off
set feedback off
set heading off
col owner new_value user_name noprint
COL target_tbs new_value target_tbs NOPRINT ;
col orig_tbs new_value orig_tbs noprint;
col move_syntax format a200

select UPPER('&original_tablespace') as orig_tbs,
       UPPER('&target_tablespace') as target_tbs 
  from dual;

spool modi_default_attribute.sql
set echo  off
set verify off
set term off

 select  'ALTER TABLE '|| username_table_name ||' modify default attributes  tablespace &target_tbs' ||'; '  
 from
(select  distinct table_owner||'.'|| table_NAME username_table_name
  from dba_tab_partitions
 WHERE TABLESPACE_NAME = '&orig_tbs'
);

 select  'ALTER TABLE '|| username_table_name ||' modify default attributes  tablespace &target_tbs' ||'; '  
 from
(select  distinct table_owner||'.'|| table_NAME username_table_name
  from dba_tab_partitions
 WHERE TABLESPACE_NAME = '&orig_tbs'
);



 select  'ALTER INDEX '|| username_index_name ||' modify default attributes  tablespace &target_tbs' ||'; ' 
 from 
(select  distinct index_owner||'.'|| index_NAME username_index_name
from dba_ind_partitions 
where tablespace_name = '&orig_tbs' 
 );


SELECT 'ALTER TABLE '||TABLE_OWNER||'.'||TABLE_NAME||' MODIFY DEFAULT ATTRIBUTES FOR PARTITION '||PARTITION_NAME ||' TABLESPACE &target_tbs' ||'; ' 
FROM DBA_TAB_PARTITIONS
WHERE TABLESPACE_NAME='&orig_tbs'; 


 
spool off

set term on
set echo on
set feedback on
set heading on
set verify on

undefine orig_tablespace ;
undefine orig_tbs
undefine target_tbs ;
undefine user_name ;
undefine TBS_NAME;
