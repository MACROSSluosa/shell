set lines 400 pages 49999
set echo off
set feedback off
set heading off

col syntax format a220

spool restore_parallel_logging_ALL.sql
set echo  off
set verify off
set term off

SELECT 'ALTER TABLE ' || OWNER || '.' || TABLE_NAME || ' ' ||
       DECODE(LOGGING, 'YES', 'LOGGING PARALLEL ', 'NOLOGGING PARALLEL ') ||
       TRIM(DEGREE) || ';' as syntax
  FROM DBA_TABLES
 WHERE  (OWNER,TABLE_NAME)  IN (SELECT OWNER,SEGMENT_NAME
                                      FROM DBA_SEGMENTS
                                     WHERE TABLESPACE_NAME ='FDM_S_DATA'
                                       AND SEGMENT_TYPE IN ('TABLE')
    AND PARTITIONED = 'NO'
UNION
SELECT 'ALTER TABLE ' || TABLE_OWNER || '.' || TABLE_NAME ||
       ' MODIFY PARTITION ' || PARTITION_NAME || ' ' ||
       DECODE(LOGGING, 'YES', 'LOGGING', 'NOLOGGING') || ';'
  FROM DBA_TAB_PARTITIONS
 WHERE (TABLE_owner,TABLE_NAME,PARTITION_NAME) IN (SELECT owner,SEGMENT_NAME,PARTITION_NAME
                                         FROM DBA_SEGMENTS
                                        WHERE TABLESPACE_NAME ='FDM_S_DATA'
                                          AND SEGMENT_TYPE = 'TABLE PARTITION')
UNION
SELECT 'ALTER TABLE ' || TABLE_OWNER || '.' || TABLE_NAME ||
       ' MODIFY PARTITION ' || SUBPARTITION_NAME || ' ' ||
       DECODE(LOGGING, 'YES', 'LOGGING', 'NOLOGGING') || ';'
  FROM DBA_TAB_SUBPARTITIONS
 WHERE (TABLE_owner,TABLE_NAME,PARTITION_NAME) IN (SELECT owner,SEGMENT_NAME,PARTITION_NAME
                                         FROM DBA_SEGMENTS
                                        WHERE TABLESPACE_NAME ='FDM_S_DATA'
                                          AND SEGMENT_TYPE = 'TABLE SUBPARTITION')
UNION
SELECT 'ALTER INDEX ' || OWNER || '.' || INDEX_NAME || ' ' ||
       DECODE(LOGGING, 'YES', 'LOGGING', 'NOLOGGING') || ' PARALLEL ' ||
       TRIM(DEGREE) || ';'
  FROM DBA_INDEXES
 WHERE PARTITIONED = 'NO'
   AND (OWNER,INDEX_NAME) IN (SELECT OWNER,SEGMENT_NAME
                                FROM DBA_SEGMENTS
                               WHERE TABLESPACE_NAME ='FDM_S_DATA'
                                 AND SEGMENT_TYPE = 'INDEX')
UNION
SELECT 'ALTER INDEX ' || INDEX_OWNER || '.' || INDEX_NAME ||
       ' MODIFY PARTITION ' || PARTITION_NAME || ' ' ||
       DECODE(LOGGING, 'YES', 'LOGGING', 'NOLOGGING') || ';'
  FROM DBA_IND_PARTITIONS
 WHERE (index_OWNER ,index_name,PARTITION_NAME) IN (SELECT OWNER,segment_name,PARTITION_NAME
                                     FROM DBA_SEGMENTS
                                    WHERE TABLESPACE_NAME ='FDM_S_DATA'
                                      AND SEGMENT_TYPE = 'INDEX PARTITION')
UNION
SELECT 'ALTER INDEX ' || INDEX_OWNER || '.' || INDEX_NAME ||
       ' MODIFY PARTITION ' || SUBPARTITION_NAME || ' ' ||
       DECODE(LOGGING, 'YES', 'LOGGING', 'NOLOGGING') || ';'
  FROM DBA_IND_SUBPARTITIONS
 WHERE (index_OWNER ,index_name,PARTITION_NAME) IN (SELECT OWNER,segment_name,PARTITION_NAME
                                     FROM DBA_SEGMENTS
                                    WHERE TABLESPACE_NAME ='FDM_S_DATA'
                                      AND SEGMENT_TYPE = 'INDEX SUBPARTITION')
 ;

spool off

set term on
set echo on
set feedback on
set heading on
set verify on

exit

