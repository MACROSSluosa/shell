set lines 400 pages 49999 

set echo off
set feedback off
set heading off
col owner new_value user_name noprint
COL target_tbs new_value target_tbs NOPRINT ;
col orig_tbs new_value orig_tbs noprint;
col move_syntax format a200

select TRIM(UPPER('&OWNER')) AS owner,
       TRIM(UPPER('&original_tablespace')) as orig_tbs,
       TRIM(UPPER('&target_tablespace')) as target_tbs 
  from dual;

spool part_index_move_&&USER_NAME..sql
set echo  off
set verify off
set term off

select 'ALTER INDEX '||index_OWNER||'.'||index_NAME ||' REBUILD PARTITION '||PARTITION_NAME||' TABLESPACE '||' &target_tbs PARALLEL 16  NOLOGGING ;'  as syntax
from dba_ind_partitions
where tablespace_name = '&orig_tbs'
 and index_owner = upper('&USER_NAME')
 ;
 
spool off

set term on
set echo on
set feedback on
set heading on
set verify on
undefine orig_tablespace ;
undefine orig_tbs
undefine target_tbs ;
undefine user_name ;
undefine TBS_NAME;
