spool BaseInfo.log
set lines 200
set pages 1000
set feedback on

COL TABLESPACE_NAME FORMAT A36
COL USERNAME FORMAT A24
COL SEGMENT_TYPE FORMAT A18


TTITLE  LEFT "Tablespace Base Information"  SKIP 1 -
      LEFT "======================================================================================"
select tablespace_name,
       block_size,
       SEGMENT_SPACE_MANAGEMENT,
       logging,
       EXTENT_MANAGEMENT
  from dba_tablespaces
 where contents ='PERMANENT'
   AND TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
   AND TABLESPACE_NAME = 'FDM_S_DATA'
 order by contents,
          tablespace_name ;
TTITLE OFF          

TTITLE  LEFT "distinct owner in tablespace"  SKIP 1 -
      LEFT "======================================================================================"
select distinct owner,
                tablespace_name 
from DBA_SEGMENTS
where tablespace_name = 'FDM_S_DATA' ;
TTITLE OFF 


TTITLE  LEFT "User Default Tablespace"  SKIP 1 -
      LEFT "======================================================================================"
SELECT USERNAME,
       DEFAULT_TABLESPACE
   FROM DBA_USERS
  WHERE DEFAULT_TABLESPACE IN ('FDM_S_DATA');  
TTITLE OFF       
          

SET LINES 200 PAGES 100
COL OWNER FORMAT A16
COL OBJECT_NAME FORMAT A36
COL OBJECT_TYPE FORMAT A30


TTITLE  LEFT "Invalid Objects CNT"  SKIP 1 -
      LEFT "======================================================================================"
SELECT OWNER,OBJECT_NAME,OBJECT_TYPE,COUNT(*) AS CNT
FROM DBA_OBJECTS 
WHERE STATUS <> 'VALID'
GROUP BY OWNER,OBJECT_NAME,OBJECT_TYPE
ORDER BY 1,3,2;
TTITLE off

TTITLE  LEFT "Invalid Objects DETAIL"  SKIP 1 -
      LEFT "======================================================================================"
SELECT OWNER,OBJECT_NAME,OBJECT_TYPE 
FROM DBA_OBJECTS 
WHERE STATUS <> 'VALID'
ORDER BY 1,3,2;
TTITLE off

TTITLE  LEFT "Invalid Index CNT"  SKIP 1 -
      LEFT "======================================================================================"
COL INDEX_NAME FORMAT A36
SELECT OWNER,INDEX_NAME,COUNT(*) AS CNT
FROM DBA_INDEXES
WHERE STATUS <> 'VALID'
 AND PARTITIONED = 'NO'
GROUP BY OWNER,INDEX_NAME
ORDER BY 1,2;
TTITLE off

TTITLE  LEFT "Invalid Index Detail"  SKIP 1 -
      LEFT "======================================================================================"
COL INDEX_NAME FORMAT A36
SELECT OWNER,INDEX_NAME
FROM DBA_INDEXES
WHERE STATUS <> 'VALID'
 AND PARTITIONED = 'NO'
ORDER BY 1,2;
TTITLE off

TTITLE  LEFT "UnUsable Partition Index CNT"  SKIP 1 -
      LEFT "======================================================================================"
COL INDEX_OWNER FORMAT A24
COL INDEX_NAME FORMAT A36
COL PARTITION_NAME FORMAT A36
SELECT INDEX_OWNER,INDEX_NAME,PARTITION_NAME,count(*)
FROM DBA_IND_PARTITIONS
WHERE STATUS = 'UNUSABLE'
group BY INDEX_OWNER,INDEX_NAME,PARTITION_NAME
ORDER BY 1,2,3;
TTITLE off

TTITLE  LEFT "UnUsable Partition Index Detail"  SKIP 1 -
      LEFT "======================================================================================"
COL INDEX_OWNER FORMAT A24
COL INDEX_NAME FORMAT A36
COL PARTITION_NAME FORMAT A36
SELECT INDEX_OWNER,INDEX_NAME,PARTITION_NAME
FROM DBA_IND_PARTITIONS
WHERE STATUS = 'UNUSABLE'
ORDER BY 1,2,3;
TTITLE off

TTITLE  LEFT "Count Tables In a Tablespace For a User"  SKIP 1 -
      LEFT "======================================================================================"
SELECT OWNER AS USERNAME,
       TABLESPACE_NAME,
       COUNT(*) AS CNT
  FROM DBA_TABLES
 WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
 AND   TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY OWNER,TABLESPACE_NAME;
TTITLE OFF

TTITLE  LEFT "Count Indexes In a Tablespace For a User"  SKIP 1 -
      LEFT "======================================================================================"
SELECT OWNER AS USERNAME,
       TABLESPACE_NAME,
       COUNT(*) AS CNT
  FROM DBA_INDEXES
 WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
 AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY OWNER,TABLESPACE_NAME;
TTITLE OFF


TTITLE  LEFT "Count TAB Partitions In a Tablespace For a User"  SKIP 1 -
      LEFT "======================================================================================"
SELECT TABLE_OWNER AS USERNAME,
       TABLESPACE_NAME,
       COUNT(*) AS CNT
  FROM DBA_TAB_PARTITIONS
 WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
 AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY TABLE_OWNER,TABLESPACE_NAME;
TTITLE OFF

TTITLE  LEFT "count tab subpartitions in a tablespace for a user"  SKIP 1 -
      LEFT "======================================================================================"
SELECT TABLE_OWNER AS USERNAME,
       TABLESPACE_NAME,
       COUNT(*) AS CNT
  FROM DBA_TAB_SUBPARTITIONS
 WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
 AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY TABLE_OWNER,TABLESPACE_NAME;
TTITLE OFF

TTITLE  LEFT "count ind partitions in a tablespace for a user"  SKIP 1 -
      LEFT "======================================================================================"
SELECT INDEX_OWNER AS USERNAME,
       TABLESPACE_NAME,
       COUNT(*) AS CNT
  FROM DBA_IND_PARTITIONS
 WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
 AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY INDEX_OWNER,TABLESPACE_NAME;
TTITLE OFF

TTITLE  LEFT "count ind subpartitions in a tablespace for a user"  SKIP 1 -
      LEFT "======================================================================================"
SELECT INDEX_OWNER AS USERNAME,
       TABLESPACE_NAME,
       COUNT(*) AS CNT
  FROM DBA_IND_SUBPARTITIONS
 WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
 AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY INDEX_OWNER,TABLESPACE_NAME;
TTITLE OFF

TTITLE  LEFT "SEGMENT CNT in a tablespace"  SKIP 1 -
      LEFT "======================================================================================"
SELECT OWNER,
       TABLESPACE_NAME,
       SEGMENT_TYPE,
       count(*) as CNT
  FROM DBA_SEGMENTS
  WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
    AND TABLESPACE_NAME NOT LIKE 'UNDO%'
    AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY OWNER,TABLESPACE_NAME,SEGMENT_TYPE
 ORDER BY TABLESPACE_NAME,OWNER ;
TTITLE OFF

TTITLE  LEFT "SEGMENT SIZE  in a tablespace"  SKIP 1 -
      LEFT "======================================================================================"
SELECT OWNER,
       TABLESPACE_NAME,
       SEGMENT_TYPE,
       ROUND(SUM(BYTES)/1024/1024,0) AS SIZE_MB
  FROM DBA_SEGMENTS
  WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
    AND TABLESPACE_NAME NOT LIKE 'UNDO%'
    AND TABLESPACE_NAME = 'FDM_S_DATA'
 GROUP BY OWNER,TABLESPACE_NAME,SEGMENT_TYPE
 ORDER BY TABLESPACE_NAME,OWNER ;
TTITLE OFF 


COL COLUMN_NAME FORMAT A24
TTITLE  LEFT "LOB Information"  SKIP 1 -
      LEFT "======================================================================================"
select owner,
       table_name,
       column_name,
       segment_name,
       TABLESPACE_NAME,
       INDEX_NAME,
       logging
  from dba_lobs
 where tablespace_name NOT IN ('SYSTEM','SYSAUX','TEMP')
 AND TABLESPACE_NAME = 'FDM_S_DATA';
TTITLE OFF

SET PAGESIZE 999
SET LINESIZE 110
TTITLE  LEFT "Tablespace Information"  SKIP 1 -
      LEFT "======================================================================================"
SET HEAD ON
SET FEEDBACK ON
BREAK ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF total_m ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF free_m  ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF used_m  ON REPORT
col tablespace format a25
col ext_mgt  format a8
col seg_mgt  format a8
col status format a7
set feedback off
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))/1024/1024),2) used_m,
   round((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))*100/d.sumbytes,2) used_pct
  from
    (select
      tablespace_name,   sum(bytes) sumbytes
     from dba_free_space   group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes    
      from dba_data_files     group by tablespace_name) d
    where f.tablespace_name(+) = d.tablespace_name
    order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name
union all
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round((d.sumbytes/1024/1024),2)-round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) used_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)*100/d.sumbytes,2) used_pct
   from
    (select
      tablespace_name,      sum(bytes_used) sumbytes
    -- sum(bytes_cached) sumbytes
     from v$temp_extent_pool     group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes
     from dba_temp_files     group by tablespace_name) d
  where f.tablespace_name(+) = d.tablespace_name
  order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name order by 5;
TTITLE OFF


TTITLE  LEFT "User sys privs"  SKIP 1 -
      LEFT "======================================================================================"
select grantee,
       privilege
  from dba_sys_privs
 where grantee not in ('DBA','SYS','CONNECT','RESOURCE','RECOVERY_CATALOG_OWNER',
    'AQ_ADMINISTRATOR_ROLE','SCHEDULER_ADMIN','WMSYS','SYSTEM','OEM_MONITOR',
    'OEM_ADVISOR','APPQOSSYS','OUTLN','ORACLE_OCM','DBSNMP','DIP','SYSMAN')
   AND GRANTEE NOT LIKE '%FULL_DATABASE'
 UNION
 select grantee,
        GRANTED_ROLE as privilege
  from dba_ROLE_privs
 where grantee not in ('DBA','SYS','CONNECT','RESOURCE','RECOVERY_CATALOG_OWNER',
    'AQ_ADMINISTRATOR_ROLE','SCHEDULER_ADMIN','WMSYS','SYSTEM','OEM_MONITOR',
    'OEM_ADVISOR','APPQOSSYS','OUTLN','ORACLE_OCM','DBSNMP','DIP','SELECT_CATALOG_ROLE','LOGSTDBY_ADMINISTRATOR',
    'EXECUTE_CATALOG_ROLE','HS_ADMIN_ROLE','SYSMAN')
   AND GRANTEE NOT LIKE '%FULL_DATABASE'
 ;
TTITLE off 

TTITLE  LEFT "User TBS QUOTAS"  SKIP 1 -
      LEFT "======================================================================================"
SELECT TABLESPACE_NAME,
       USERNAME,
       ROUND(MAX_BYTES/1024/1024,2)  AS SIZE_MB
   FROM DBA_TS_QUOTAS
  WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX') 
  AND TABLESPACE_NAME = 'FDM_S_DATA';
TTITLE off


set long 49999

TTITLE  LEFT "Table DDL"  SKIP 1 -
      LEFT "======================================================================================"
select dbms_metadata.get_ddl('TABLE',TABLE_NAME,OWNER) AS TABLE_DDL
FROM DBA_TABLES
WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
  AND OWNER IN (SELECT DISTINCT OWNER FROM DBA_SEGMENTS WHERE TABLESPACE_NAME  = 'FDM_S_DATA')
order by owner;
TTITLE OFF

TTITLE  LEFT "INDEX DDL"  SKIP 1 -
      LEFT "======================================================================================"
select dbms_metadata.get_ddl('INDEX',INDEX_NAME,OWNER) AS INDEX_DDL
FROM DBA_INDEXES
WHERE TABLESPACE_NAME NOT IN ('SYSTEM','SYSAUX')
AND OWNER IN (SELECT DISTINCT OWNER FROM DBA_SEGMENTS WHERE TABLESPACE_NAME  = 'FDM_S_DATA')
order by owner;
TTITLE OFF

spool off
