set lines 400 pages 49999

set echo off
set feedback off
set heading off
col owner new_value user_name noprint
COL target_tbs new_value target_tbs NOPRINT ;
col orig_tbs new_value orig_tbs noprint;
col move_syntax format a200

select TRIM(UPPER('&OWNER')) AS owner,
       TRIM(UPPER('&original_tablespace')) as orig_tbs,
       TRIM(UPPER('&target_tablespace')) as target_tbs
  from dual;

spool subpart_index_move_&&USER_NAME..sql
set echo  off
set verify off
set term off

select 'ALTER INDEX '||index_OWNER||'.'||index_NAME ||' REBUILD SUBPARTITION '||SUBPARTITION_NAME||' TABLESPACE '||' &target_tbs PARALLEL 16  ;'  as syntax
from dba_ind_subpartitions
where tablespace_name = upper('&orig_tbs')
 and index_owner = upper('&USER_NAME')
union
select 'ALTER INDEX '||m.index_OWNER||'.'||m.index_NAME ||' REBUILD SUBPARTITION '||SUBPARTITION_NAME||' PARALLEL 16;'  as syntax
from dba_ind_subpartitions m
where m.tablespace_name <> upper('&orig_tbs')
 and m.index_owner = upper('&USER_NAME')
 and exists (select '1'
               from dba_tab_subpartitions n
              where m.index_owner = n.index_owner
                and m.partition_name = n.partition_name
                and m.SUBPARTITION_NAME = n.SUBPARTITION_NAME
                and n.tablespace_name = '&orig_tbs'
                and n.table_owner = upper('&USER_NAME'))
 ;

spool off

set term on
set echo on
set feedback on
set heading on
set verify on
undefine orig_tablespace ;
undefine orig_tbs
undefine target_tbs ;
undefine user_name ;
undefine TBS_NAME;
