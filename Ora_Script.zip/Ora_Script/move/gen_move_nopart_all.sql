
set lines 400 pages 49999

set echo off
set feedback off
set heading off
col owner new_value user_name noprint
COL target_tbs new_value target_tbs NOPRINT ;
col orig_tbs new_value orig_tbs noprint;
col move_syntax format a200

select TRIM(UPPER('&OWNER')) AS owner,
       TRIM(UPPER('&original_tablespace')) as orig_tbs,
       TRIM(UPPER('&target_tablespace')) as target_tbs
  from DUAL;

spool non_part_all_move_&&USER_NAME..sql
set echo  off
set verify off
set term off

select  'ALTER TABLE '||OWNER||'.'||table_NAME ||' MOVE TABLESPACE '||'&target_tbs PARALLEL 16  NOLOGGING ;' as move_syntax
from dba_tables
where tablespace_name = '&orig_tbs'
and owner = upper('&USER_NAME')
order by owner,tablespace_name ;

select 'ALTER INDEX '||m.OWNER||'.'||m.INDEX_NAME ||' REBUILD TABLESPACE '||'&target_tbs PARALLEL 16  NOLOGGING ;'  as syntax
from dba_indexes m
where m.partitioned='NO'
 and exists (select '1' from dba_tables n
               where m.table_owner = n.owner
                 and m.table_name =  n.table_name
                 and n.owner = upper('&USER_NAME')
                 and n.tablespace_name = '&orig_tbs')
 and m.tablespace_name = '&orig_tbs'
union
select 'ALTER INDEX '||m.OWNER||'.'||m.INDEX_NAME ||' REBUILD  PARALLEL 16  NOLOGGING ;'  as syntax
from dba_indexes m
where m.partitioned='NO'
 and exists (select '1' from dba_tables n
               where m.table_owner = n.owner
                 and m.table_name =  n.table_name
                 and n.owner = upper('&USER_NAME')
                 and n.tablespace_name = '&orig_tbs')
 and m.tablespace_name <> '&orig_tbs'
;

spool off

set term on
set echo on
set feedback on
set heading on
set verify on

undefine orig_tablespace ;
undefine orig_tbs
undefine target_tbs ;
undefine user_name ;
undefine TBS_NAME;


