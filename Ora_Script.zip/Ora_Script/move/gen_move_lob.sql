set lines 400 pages 49999 

set echo off
set feedback off
set heading off
col owner new_value user_name noprint
COL target_tbs new_value target_tbs NOPRINT ;
col orig_tbs new_value orig_tbs noprint;
col move_syntax format a200

spool move_lob.sql

select UPPER('&original_tablespace') as orig_tbs,
       UPPER('&target_tablespace') as target_tbs 
  from dual;

select 'alter table '||owner||'.'||table_name||' MOVE lob('||column_name||') store as (tablespace &target_tbs) ;' 
from dba_lobs
where tablespace_NAME='&orig_tbs';
 
spool off

set term on
set echo on
set feedback on
set heading on
set verify on
undefine orig_tablespace ;
undefine orig_tbs
undefine target_tbs ;
undefine user_name ;
undefine TBS_NAME;
