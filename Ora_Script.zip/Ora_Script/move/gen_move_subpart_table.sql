set lines 400 pages 49999

set echo off
set feedback off
set heading off
col owner new_value user_name noprint
COL target_tbs new_value target_tbs NOPRINT ;
col orig_tbs new_value orig_tbs noprint;
col move_syntax format a180

select TRIM(UPPER('&OWNER')) AS owner,
       TRIM(UPPER('&original_tablespace')) as orig_tbs,
       TRIM(UPPER('&target_tablespace')) as target_tbs
  from dual;

spool subpart_table_move_&&USER_NAME..sql
set echo  off
set verify off
set term off

select  'ALTER TABLE '||TABLE_OWNER||'.'||TABLE_NAME ||' MOVE SUBPARTITION '||SUBPARTITION_NAME ||' TABLESPACE '||'&target_tbs PARALLEL 16  ;' as move_syntax
from dba_tab_subpartitions
where tablespace_name = '&orig_tbs'
and   table_owner = upper('&USER_NAME')
order by table_owner,table_name,partition_name ;


spool off

set term on
set echo on
set feedback on
set heading on
set verify on
undefine orig_tablespace ;
undefine orig_tbs
undefine target_tbs ;
undefine user_name ;
undefine TBS_NAME;
