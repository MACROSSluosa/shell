#!/bin/bash
HOSTNAME=`hostname`
IPADDR=`hostname -i`
DT=`date +%Y%m%d`
FILENAME=/tmp/DBA_OraChk_OS_${HOSTNAME}_${DT}.html

if [ -f ${FILENAME} ]
then
>${FILENAME}
else
touch ${FILENAME} 
fi


echo "<html>"         >> ${FILENAME}
echo "<head>"         >> ${FILENAME}
echo "<meta http-equiv="'"Content-Type"'" content="'"text/html; charset=GBK"'">"  >> ${FILENAME}

echo "<meta name="'"generator"'" content="'"OS"'">"  >> ${FILENAME}
echo "<title>Linux OS Simple Report</title>    <style type="'"text/css"'">      body              {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;}      p                 {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;}      table,tr,td       {font:9pt Arial,Helvetica,sans-serif; color:Black; background:#C0C0C0; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px;}      th                {font:bold 9pt Arial,Helvetica,sans-serif; color:#336699; background:#cccc99; padding:0px 0px 0px 0px;}      h1                {font:bold 12pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; border-bottom:1px solid #cccc99; margin-top:0pt; margin-bottom:0pt; padding:0px 0px 0px 0px;}      h2                {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; margin-top:4pt; margin-bottom:0pt;}      a                 {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.link            {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLink          {font:9pt Arial,Helvetica,sans-serif; color:#663300; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkBlue      {font:9pt Arial,Helvetica,sans-serif; color:#0000ff; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkDarkBlue  {font:9pt Arial,Helvetica,sans-serif; color:#000099; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkRed       {font:9pt Arial,Helvetica,sans-serif; color:#ff0000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkDarkRed   {font:9pt Arial,Helvetica,sans-serif; color:#990000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkGreen     {font:9pt Arial,Helvetica,sans-serif; color:#00ff00; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkDarkGreen {font:9pt Arial,Helvetica,sans-serif; color:#009900; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}    </style>" >>${FILENAME}

echo "</head>" >>${FILENAME}


echo "<body BGCOLOR="'"#C0C0C0"'">" >>${FILENAME}

echo "<br>" >>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo " <b>Host Info</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>" >>${FILENAME}


echo "<table width="90%" border="1">   ">>${FILENAME}
echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Host Name</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${HOSTNAME}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}



echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">IP Address</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${IPADDR}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


OS_VERSION=`cat /etc/redhat-release`
KERNEL_VERISON=`uname -r`
RUN_LEVEL=`who -r`
HOST_FILE=`grep -v "^$" /etc/hosts`


echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">OS Version</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${OS_VERSION}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Kernel Version</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${KERNEL_VERISON}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Run Level</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${RUN_LEVEL}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}

echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Host File</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${HOST_FILE}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


IPTABLES=`service iptables status`
SELINUX=`getenforce`

echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">IPTABLES</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${IPTABLES}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}

echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">SELINUX</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${SELINUX}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}

echo "</table> ">>${FILENAME}



###############################
echo "<br>                                                                                  ">>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'"> ">>${FILENAME}
echo " <b>Filesystem Usage</b></font><hr align="'"left"'" width="'"460"'">                  ">>${FILENAME}
echo "<br>" >>${FILENAME}

echo "<table width="'"90%"'" border="'"1"'">                ">>${FILENAME}
echo "<tr>                                                  ">>${FILENAME}
echo "<th align="'"center"'" width="'"40%"'">Filesystem</th> ">>${FILENAME}   
echo "<th align="'"center"'" width="'"10%"'">Size</th>       ">>${FILENAME}
echo "<th align="'"center"'" width="'"10%"'">Used</th>      ">>${FILENAME}
echo "<th align="'"center"'" width="'"10%"'">Avaliable</th>  ">>${FILENAME}
echo "<th align="'"center"'" width="'"10%"'">Use%</th>       ">>${FILENAME} 
echo "<th align="'"center"'" width="'"20%"'">Mounted on</th> ">>${FILENAME}
echo "</tr>                                                  ">>${FILENAME}

df -Ph |grep -v "Filesystem" | while read line
do
VAL1=`echo $line |awk '{print $1}'`
VAL2=`echo $line |awk '{print $2}'`  
VAL3=`echo $line |awk '{print $3}'` 
VAL4=`echo $line |awk '{print $4}'` 
VAL5=`echo $line |awk '{print $5}'` 
VAL6=`echo $line |awk '{print $6}'` 
 
echo "<tr>                                                  ">>${FILENAME} 
echo "<td align="'"left"'" width="'"40%"'">${VAL1}</td>   ">>${FILENAME} 
echo "<td align="'"center"'" width="'"10%"'">${VAL2}</td>   ">>${FILENAME}
echo "<td align="'"center"'" width="'"10%"'">${VAL3}</td>   ">>${FILENAME} 
echo "<td align="'"center"'" width="'"10%"'">${VAL4}</td>   ">>${FILENAME}
echo "<td align="'"center"'" width="'"10%"'">${VAL5}</td>   ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'">${VAL6}</td>    ">>${FILENAME} 
echo "</tr>                                                  ">>${FILENAME}
done
echo "</Table>                                               ">>${FILENAME} 


###################################
echo "<br>                                                                                  ">>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'"> ">>${FILENAME}
echo " <b>Kernel params</b></font><hr align="'"left"'" width="'"460"'">                  ">>${FILENAME}
echo "<br>" >>${FILENAME}
echo "<table width="'"90%"'" border="'"1"'">                ">>${FILENAME}

sysctl -a |grep kernel |while read line
do
echo "<tr>                                                  ">>${FILENAME}
echo "<td align="'"left"'" >$line</td>                      ">>${FILENAME}
done
echo "</table> ">>${FILENAME}


###################################
echo "<br>                                                                                  ">>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'"> ">>${FILENAME}
echo " <b>Net params</b></font><hr align="'"left"'" width="'"460"'">                  ">>${FILENAME}
echo "<br>" >>${FILENAME}
echo "<table width="'"90%"'" border="'"1"'">                ">>${FILENAME}

sysctl -a |grep net |while read line
do
echo "<tr>                                                  ">>${FILENAME}
echo "<td align="'"left"'" >$line</td>                      ">>${FILENAME}
done

echo "</table> ">>${FILENAME}

###################################
echo "<br>                                                                                  ">>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'"> ">>${FILENAME}
echo " <b>Memory Info</b></font><hr align="'"left"'" width="'"460"'">                       ">>${FILENAME}
echo "<br>                                                                                   ">>${FILENAME}
echo "<table width="'"90%"'" border="'"1"'">                                                 ">>${FILENAME}
echo "<tr>                                                                                   ">>${FILENAME}
echo "<th align="'"center"'" width="'"50%"'">Item</th>                                       ">>${FILENAME}
echo "<th align="'"center"'" width="'"30%"'">Value</th>                                      ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">Unit</th>                                       ">>${FILENAME}
echo "</tr>                                                                                  ">>${FILENAME}

cat /proc/meminfo |while read line
do
VAL1=`echo $line |awk '{print $1}'`
VAL2=`echo $line |awk '{print $2}'`
VAL3=`echo $line |awk '{print $3}'`

echo "<tr>                                                                                   ">>${FILENAME}
echo "<td align="'"left"'" width="'"50%"'">${VAL1}</td>                                      ">>${FILENAME}
echo "<td align="'"center"'" width="'"30%"'">${VAL2}</td>                                    ">>${FILENAME}
echo "<td align="'"center"'" width="'"20%"'">${VAL3}</td>                                    ">>${FILENAME}
echo "</tr>                                                                                  ">>${FILENAME}
done


echo "</table>                                                                               ">>${FILENAME}


echo "</body>" >>${FILENAME}

echo "</html>" >>${FILENAME}





