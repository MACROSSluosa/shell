#!/bin/ksh
ls /usr/openv/netbackup/ | grep -q "^exclude_list.BMR"
if [ $? -ne 0 ];then
   echo "exclude_list.BMR* does not exist"
   exit 1;
fi

BMR_NU=`ls /usr/openv/netbackup/ | grep "^exclude_list.BMR" | wc -l`
if [ $BMR_NU -gt 1 ];then
    echo "Too many exclude_list.BMR"
    exit 2
fi

FL=`ls /usr/openv/netbackup/ | grep "^exclude_list.BMR"`
FL="/usr/openv/netbackup/${FL}"

ls -l /|grep ^d|awk '{print "/"$NF}'>1.txt
lsvg -l rootvg|awk '{print $NF}'|egrep -v "rootvg|POINT|N/A|/install">2.txt

>$FL

while read LINE
do
   grep -w -q "$LINE" 2.txt
   if [ $? -ne 0 ];then
     echo "$LINE"|egrep -v "/.dt|/.java|/.veritas|/.ssh|/dev|/etc|/lost|/lpp|/mnt|/mtool|/proc|/rsa|/sbin|/tftpboot|/oracle|/WebSphere|/nbu">> $FL
   fi
done<1.txt
cat $FL
rm 1.txt
rm 2.txt
