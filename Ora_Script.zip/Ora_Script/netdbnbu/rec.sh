#!/bin/sh

oldOraSID=oDCDSDB2
newOraSID=`su - oracle -c env|grep SID|cut -d'=' -f2`


oldHostname=DCDSDB2
newHostname=`hostname`

sed 's/'$oldHostname'/'$newHostname'/' DB-ora-${newOraSID}-arch-1D3-1M.sh >tmp.sh
cp tmp.sh DB-ora-${newOraSID}-arch-1D3-1M.sh

sed 's/'$oldHostname'/'$newHostname'/' DB-ora-${newOraSID}-full-1W1-1M.sh >tmp.sh
cp tmp.sh DB-ora-${newOraSID}-full-1W1-1M.sh

sed 's/'$oldHostname'/'$newHostname'/' DB-ora-${newOraSID}-archivelog-1D3-1M.sh >tmp.sh
cp tmp.sh DB-ora-${newOraSID}-archivelog-1D3-1M.sh

rm tmp.sh
chmod +x *.sh
