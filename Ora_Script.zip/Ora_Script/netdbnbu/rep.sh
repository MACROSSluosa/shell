#!/bin/sh

oldOraSID=oDCDSDB2
newOraSID=`su - oracle -c env|grep SID|cut -d'=' -f2`

mv DB-ora-${oldOraSID}-arch-1D3-1M.sh DB-ora-${newOraSID}-arch-1D3-1M.sh
mv DB-ora-${oldOraSID}-archivelog-1D3-1M.sh DB-ora-${newOraSID}-archivelog-1D3-1M.sh
mv DB-ora-${oldOraSID}-full-1W1-1M.sh DB-ora-${newOraSID}-full-1W1-1M.sh

sed 's/'$oldOraSID'/'$newOraSID'/' DB-ora-${newOraSID}-arch-1D3-1M.sh >tmp.sh
cp tmp.sh DB-ora-${newOraSID}-arch-1D3-1M.sh

sed 's/'$oldOraSID'/'$newOraSID'/' DB-ora-${newOraSID}-full-1W1-1M.sh >tmp.sh
cp tmp.sh DB-ora-${newOraSID}-full-1W1-1M.sh

sed 's/'$oldOraSID'/'$newOraSID'/' DB-ora-${newOraSID}-archivelog-1D3-1M.sh >tmp.sh
cp tmp.sh DB-ora-${newOraSID}-archivelog-1D3-1M.sh

rm tmp*.sh
chmod +x *.sh
