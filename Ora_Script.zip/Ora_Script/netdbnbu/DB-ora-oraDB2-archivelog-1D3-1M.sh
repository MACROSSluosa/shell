ps -ef|grep DB-ora-oraDB2-arch-1D3-1M.sh|grep -v grep > /dev/null
if [ $? -eq 0 ]
then
	echo "rman backup achivelog is active"
else
	/usr/openv/scripts/DB-ora-oraDB2-arch-1D3-1M.sh
fi
