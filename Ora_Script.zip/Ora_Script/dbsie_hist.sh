
for i in  `find . -name "[04,05,06]*lst" -mtime +12 -exec ls -l {} \;|grep "0000" |awk '{print $9}'`
do 
	sizem=0
	cat $i |grep -v "NAME" |grep -v "-" |grep -v "^$" |grep -v "SQL> spool" |grep -v "UNDO" |grep -v "/"|grep -v "SQL>"|grep -v "rows selected" \
	|awk '{print $4}'|awk -F\. '{print $1}'|grep -v ^$|while read line
	do
	sizem=`expr ${sizem} + $line`
	done
	echo $i,$sizem >> /tmp/lirl0712.txt
done
