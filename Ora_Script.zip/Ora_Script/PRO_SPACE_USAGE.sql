create TABLE dbperf.object_space_usage(analyze_date       date not null,
                                analyze_seq        number not null,
                                object_owner       varchar2(30) not null,
                                object_type        varchar2(24) not null,
                                object_name        varchar2(30) not null,
                                partition_name     varchar2(30) null,
                                TABLESPACE_NAME    VARCHAR2(30) NOT NULL,
                                Unformatted_blocks number default 0,
                                fs1_blocks         number default 0,
                                fs2_blocks         number default 0,
                                fs3_blocks         number default 0,
                                fs4_blocks         number default 0,
                                full_blocks        number default 0,
                                all_blocks         number default 0,
                                fs1_pct            number default 0,
                                fs2_pct            number default 0,
                                fs3_pct            number default 0,
                                fs4_pct            number default 0,
                                full_pct           number default 0 ) ;
                          
alter table dbperf.object_space_usage add constraint pk_object_space_usage primary key(analyze_date,analyze_seq) ; 


create or replace procedure PRO_SPACE_USAGE(Arg_OWNER IN VARCHAR2,Arg_TYPE IN VARCHAR2)
is
N_CNT NUMBER;
N_SEQ NUMBER;
a_owner varchar2(36);
a_type  varchar2(36);
v_unformatted_blocks number(20);
v_unformatted_bytes  number(20);
v_fs1_blocks         number(20);
v_fs1_bytes  number(20);
v_fs2_blocks number(20);
v_fs2_bytes  number(20);
v_fs3_blocks number(20);
v_fs3_bytes  number(20);
v_fs4_blocks number(20);
v_fs4_bytes  number(20);
v_full_blocks number(20);
v_full_bytes number(20);
v_all_blocks number(20);
v_analyze_date date;


begin
  a_owner :=upper(arg_owner);
  a_type  :=upper(arg_type);
  N_CNT :=0;
  n_seq :=1;
  select sysdate into v_analyze_date from dual;
  
  if a_owner  = 'SYS' OR A_OWNER = 'SYSTEM' THEN
    RAISE_APPLICATION_ERROR(-20001,'The use shoud not be like sys or system');
  END IF; 
 
 BEGIN
   SELECT COUNT(1) INTO N_CNT FROM DBA_USERS WHERE USERNAME=A_OWNER;
   IF N_CNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20001,'The user does not exists!');
      RETURN;
   END IF;
 END;
 

 IF LENGTH(A_TYPE) = 0 OR A_TYPE IS NULL THEN
   RAISE_APPLICATION_ERROR(-20001,'The type should be defined!') ;
   return;
 END IF;
 
 IF A_TYPE <> 'TABLE' AND  A_TYPE <> 'INDEX' AND A_TYPE <> 'INDEX PARTITION' AND A_TYPE <> 'TABLE PARTITION' THEN
   RAISE_APPLICATION_ERROR(-20001,'The type is not correct!') ;
   return;    
 END IF;
 
 BEGIN
 SELECT NVL(MAX(ANALYZE_SEQ),0) INTO N_SEQ FROM dbperf.object_space_usage ;
   N_SEQ := N_SEQ +1;
 EXCEPTION WHEN NO_DATA_FOUND THEN
   N_SEQ := 1;
 END; 
 

 
 Begin
   for c1 in (select segment_name,
                     segment_type,
                     partition_name,
                     TABLESPACE_NAME
                from dba_segments 
               where owner = a_owner 
                 and segment_type  = a_type
                 and tablespace_name not in ('SYSTEM','SYSAUX')
                 and segment_name not like 'BIN$%'
                 ) loop
     v_unformatted_blocks :=0 ;
     v_fs1_blocks  :=0 ;
     v_fs2_blocks  :=0 ;
     v_fs3_blocks  :=0 ;
     v_fs4_blocks  :=0 ;
     v_full_blocks :=0;
     v_all_blocks  :=0;
     
     BEGIN
     dbms_space.space_usage (a_owner, c1.segment_name, C1.SEGMENT_TYPE,v_unformatted_blocks,v_unformatted_bytes, v_fs1_blocks, v_fs1_bytes, v_fs2_blocks, v_fs2_bytes,v_fs3_blocks, v_fs3_bytes, v_fs4_blocks, v_fs4_bytes, v_full_blocks,v_full_bytes,c1.partition_name);
     EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20001,'space usage analyezd failed '||sqlerrm||':'||c1.segment_name||','||a_owner);
     END;
     begin
       
     select blocks into v_all_blocks 
       from dba_segments
       where owner = a_owner
         and segment_name = c1.segment_name
         and segment_type = a_type 
         AND NVL(PARTITION_NAME,'A') = NVL(C1.PARTITION_NAME,'A') ;
         
     Insert into dbperf.object_space_usage(analyze_date,
                                    analyze_seq,
                                    object_owner,
                                    object_type,
                                    object_name,
                                    unformatted_blocks,
                                    fs1_blocks,
                                    fs2_blocks,
                                    fs3_blocks,
                                    fs4_blocks,
                                    full_blocks,
                                    all_blocks,
                                    partition_name,
                                    tablespace_name
                                    )
            values(v_analyze_date,
                   n_seq,
                   a_owner,
                   a_type,
                   c1.segment_name,
                   v_unformatted_blocks,
                   v_fs1_blocks,
                   v_fs2_blocks,
                   v_fs3_blocks,
                   v_fs4_blocks,
                   v_full_blocks,
                   v_all_blocks,
                   c1.partition_name,
                   c1.tablespace_name) ;
           commit;
       update dbperf.object_space_usage 
          set fs1_pct = round(fs1_blocks /nvl(all_blocks,0) + 0.00000000001 ,1)*100,
              fs2_pct = round(fs2_blocks /nvl(all_blocks,0) + 0.00000000001 ,1)*100,
              fs3_pct = round(fs3_blocks /nvl(all_blocks,0) + 0.00000000001 ,1)*100,
              fs4_pct = round(fs4_blocks /nvl(all_blocks,0) + 0.00000000001 ,1)*100,
              full_pct = round(full_blocks /nvl(all_blocks,0) + 0.00000000001 ,1)*100
         where analyze_date = v_analyze_date ;
       commit;
       N_SEQ := N_SEQ +1 ;
      end;
   end loop;
 end;
 
EXCEPTION WHEN OTHERS THEN
 RAISE_APPLICATION_ERROR(-20001,SQLERRM) ;
 rollback;
end PRO_SPACE_USAGE;
/

