

alter session set nls_date_format='yyyymmdd hh24:mi:ss';
spool migrate_info_collect.log

SET PAGESIZE 999
SET LINESIZE 110
TTITLE  LEFT "Tablespace Information"  SKIP 1 -
      LEFT "======================================================================================"
SET HEAD ON
SET FEEDBACK ON
BREAK ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF total_m ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF free_m  ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF used_m  ON REPORT
col tablespace format a25
col ext_mgt  format a8
col seg_mgt  format a8
col status format a7
set feedback off
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))/1024/1024),2) used_m,
   round((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))*100/d.sumbytes,2) used_pct
  from
    (select
      tablespace_name,   sum(bytes) sumbytes
     from dba_free_space   group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes    
      from dba_data_files     group by tablespace_name) d
    where f.tablespace_name(+) = d.tablespace_name
    order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name
union all
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round((d.sumbytes/1024/1024),2)-round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) used_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)*100/d.sumbytes,2) used_pct
   from
    (select
      tablespace_name,      sum(bytes_used) sumbytes
    -- sum(bytes_cached) sumbytes
     from v$temp_extent_pool     group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes
     from dba_temp_files     group by tablespace_name) d
  where f.tablespace_name(+) = d.tablespace_name
  order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name order by 5;
TTITLE OFF


set lines 200
set pages 3000
col owner format a16
col segment_name format a30

select owner,round(sum(bytes)/1024/1024,2)as size_MB
from dba_segments
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
group by  owner
order by 1,2;

select owner,tablespace_name,round(sum(bytes)/1024/1024,2)as size_MB
from dba_segments
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
group by  owner,tablespace_name
order by 1,2;

select owner,segment_type,round(sum(bytes)/1024/1024,2)as size_MB
from dba_segments
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
group by  owner,segment_type
order by 1,2;

select owner,tablespace_name,segment_type,round(sum(bytes)/1024/1024,2)as size_MB
from dba_segments
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
group by  owner,tablespace_name,segment_type
order by 1,2;

select owner,segment_name,segment_type,round(sum(bytes)/1024/1024,2)as size_MB
from dba_segments
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
group by  owner,segment_name,segment_type
order by 1,2;


set lines 200
set pages 2000
col arch_date format a16
select to_char(first_time,'yyyymmdd') as arch_date,
       count(*) as cnt,
       round(sum(blocks * block_size)/1024/1024,2) as size_mb
from v$archived_log
where dest_id = 1
 and first_time > sysdate - 10
group by to_char(first_time,'yyyymmdd')
order by 1 ;

set lines 200
set pages 2000
col arch_hour format a16
select to_char(first_time,'yyyymmdd hh24') as arch_hour,
       count(*) as cnt,
       round(sum(blocks * block_size)/1024/1024,2) as size_mb
from v$archived_log
where dest_id = 1
 and first_time > sysdate - 10
group by to_char(first_time,'yyyymmdd hh24')
order by 1 ;

set lines 200
select thread#,group#,bytes/1024/1024 as size_mb,members 
from v$log
order by 1,2;

set lines 200
col member format a80
select group#,member 
from v$logfile
order by 1;

set lines 200
set pages 1000
col owner format a16
col table_name format a24
col column_name format a24
col segment_name format a36
col tablespace_name format a24

SELECT  l.owner              owner,
    l.table_name             table_name,
    l.column_name            column_name,
    l.segment_name           segment_name,
    s.tablespace_name        tablespace_name,
    round(s.bytes/1024/1024 ,2)       size_mb,
    l.index_name,
    DECODE(   l.in_row, 'YES',  l.in_row , 'NO' , l.in_row , l.in_row )   in_row
FROM
    dba_lobs     l
  , dba_segments s
WHERE
      l.owner = s.owner
  AND l.segment_name = s.segment_name
  AND l.owner NOT IN (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
ORDER BY
    l.owner
  , l.table_name
  , l.column_name;


set lines 200
col data_type format a36
select owner,data_type ,count(*)
from dba_tab_cols
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
group by owner,data_type
order by 1,2;

set lines 200
set pages 1000
col owner format a16
col table_name format a32
select owner,
       table_name 
from dba_tables 
where COMPRESSION = 'ENABLED'
order by 1,2 ;

set lines 200
set pages 1000
col owner format a16
col table_name format a32
col table_name format a36
select owner,
       table_name,
       index_name 
from dba_indexes 
where COMPRESSION = 'ENABLED'
order by 1,2 ;


set lines 200
set pages 1000
col comp_name format a36
col version format a16
col status format a18
select comp_name,version,status
from dba_registry
order by 1,2 ;


col PLATFORM_NAME_PRINT	format a24
col db_unique_name format a12
SELECT name                                               name
   ,  dbid                                                dbid
   ,  db_unique_name                                      db_unique_name
   ,  platform_name                                       platform_name_print
   ,  protection_mode                                     protection_mode
   ,  log_mode                                            log_mode
   ,  open_mode                                           open_mode
   ,  force_logging                                       force_logging
   ,  flashback_on                                        flashback_on
   ,  controlfile_type                                    controlfile_type
FROM v$database;


col status   format a8
col filename format a80
select status, filename from v$block_change_tracking;

set lines 200
set pages 1000
col acl format a36
col PRINCIPAL format a24
select * from dba_network_acls ;

col host format a80
col owner format a16
col username format a16

select * from dba_db_links ;
 
 
col what format a120 
col log_user format a16
col PRIV_USER format a16
col SCHEMA_USER format a16
select job,log_user,PRIV_USER,SCHEMA_USER,next_date,broken,what
from dba_jobs;


SET LINES 200
SET PAGES 1000
COL OWNER FORMAT A16
COL TABLE_NAME FORMAT A36
COL LOGGING FORMAT A8
select owner,
       table_name,
       logging
from dba_tables
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
  and logging <> 'YES'
ORDER  BY 1,2;


SET LINES 200
SET PAGES 1000
COL OWNER FORMAT A16
COL TABLE_NAME FORMAT A36
col index_name format a36
COL LOGGING FORMAT A8
select owner,
       table_name,
       index_name,
       logging
from dba_indexes
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
  and logging <> 'YES'
ORDER  BY 1,2;


col tbs_name format a32
col file_name format a80
select ts.name as tbs_name,
       df.name as file_name,
       df.status
from v$datafile df,
     v$tablespace ts
where ts.ts# = df.ts#
  and df.status not in ('SYSTEM','ONLINE')
order by 1,2;


col tablespace_name format a24
col logging format a12
col status format a12
select tablespace_name,
       status,
       block_size,
       bigfile,
       LOGGING,
       CONTENTS
from dba_tablespaces ;


select tablespace_name,file_name,status 
from dba_data_files
where status  <> 'AVAILABLE'
order by 1,2;


set lines 200
set pges 2000
col pname format a40
col instance_name_print format a32
col value format a32
col isdefault format a12
col issys_modifiable format a12
SELECT DECODE(p.isdefault
            , 'FALSE'
            , SUBSTR(p.name,0,64)
            ,  SUBSTR(p.name,0,64))   pname
  , DECODE(   p.isdefault
            , 'FALSE'
            , i.instance_name 
            , i.instance_name )      instance_name_print
  , DECODE(   p.isdefault
            , 'FALSE'
            ,  SUBSTR(p.value,0,64) 
            , SUBSTR(p.value,0,64) ) value
  , DECODE(   p.isdefault
            , 'FALSE'
            ,  p.isdefault 
            , p.isdefault)     isdefault
  , DECODE(   p.isdefault
            , 'FALSE'
            , p.issys_modifiable 
            , p.issys_modifiable )                  issys_modifiable
FROM
    gv$parameter p
  , gv$instance  i
WHERE p.inst_id = i.inst_id
ORDER BY i.instance_name,p.name,isdefault ;


col owner format a16
col directory_name format a32
col directory_path  format a80
select * from dba_directories;

col username format a24
col account_status format a20
col default_tablespace format a24
col temporary_tablespace format a24
select username,
       account_status,
       default_tablespace,
       temporary_tablespace,
       profile,
       created
from dba_users
order by created ;

spool off