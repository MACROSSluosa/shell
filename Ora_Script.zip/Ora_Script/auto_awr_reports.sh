
WORKDIR=`dirname $0`
export WORKDIR

export REPORT_INTERVAL_HOURS
sqlplus "/as sysdba" <<EOF
@${WORKDIR}/auto_awr_reports.sql
exit
EOF

