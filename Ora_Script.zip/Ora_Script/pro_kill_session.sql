create or replace procedure sys.kill_session(in_username in varchar2,
                                             in_sid      in number,
                                             in_serial   in number) as
  v_sid              number;
  v_serial           number;
  v_count            number;
  v_username         varchar2(40);
  v_sql_kill_session varchar2(2000);
begin
  select count(*)
    into v_count
    from v$session
   where username = upper(in_username)
     and sid = in_sid
     and serial# = in_serial
     and username in (upper(in_username));
  select username
    into v_username
    from v$session
   where audsid = SYS_CONTEXT('USERENV', 'SESSIONID');
  if v_count = 1 then
    if upper(in_username) = upper(v_username) then
      v_sid              := in_sid;
      v_serial           := in_serial;
      v_sql_kill_session := 'alter system kill session ' || '''' || v_sid || ',' ||
                            v_serial || '''';
      dbms_output.put_line(chr(10));
      dbms_output.put_line('###############################################');
      dbms_output.put_line('Executing ...' || v_sql_kill_session);
      execute immediate v_sql_kill_session;
      dbms_output.put_line('-----------------Finished----------------------');
      dbms_output.put_line('###############################################');
    else
      dbms_output.put_line(chr(10));
      dbms_output.put_line('###############################################');
      dbms_output.put_line('Error : Do NOT permitted to kill session owned by OTHER user !');
      dbms_output.put_line('###############################################');
    end if;
  else
    dbms_output.put_line(chr(10));
    dbms_output.put_line('###############################################');
    dbms_output.put_line('Error : The session does not exists !');
    dbms_output.put_line('###############################################');
  end if;
end;
/
 