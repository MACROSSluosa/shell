set lines 200 pages 1000
col killing_session format a40
col logon_tm format a20 
col machine format a20
col program format a30
col username format a16
Select 'Alter system kill session '''||sid||','||serial#||''';' AS kill_session,
        username,
        to_char(logon_time,'yyyymmdd hh24:mi:ss') as logon_tm,
        program,
        machine ,
        status
From v$session
Where username Not in (Select username 
                         From dba_users 
                        Where default_tablespace  In ('SYSTEM','SYSAUX')
                       ) 
  And status <> 'KILLED'
order by 2,4,5,3
;


