#!/bin/bash
date  

NODE_NO=1
DB_NAME=orcl

ORACLE_OWNER=oracle
GRID_OWNER=grid

INSTALL_BASE_DIRECTORY=/oracle
INSTALL_BASE_VERSION=11.2.0.4

#########################################################
####Do not modify below
#########################################################


NUM=`grep ${ORACLE_OWNER} /etc/passwd |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "${ORACLE_OWNER}: user already exists,will be droped"
userdel ${ORACLE_OWNER}
if [ ! $? -eq 0 ];then
echo "drop user ${ORACLE_OWNER} failed"
exit
fi
fi

NUM=`grep ${GRID_OWNER} /etc/passwd |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "${GRID_OWNER}: user already exists,will be droped"
userdel ${GRID_OWNER}
if [ ! $? -eq 0 ];then
echo "drop user ${GRID_OWNER} failed"
exit
fi
fi

date
echo "drop releated user group"

NUM=`grep dba /etc/group |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "dba group is droped"
groupdel dba
if [ ! $? -eq 0 ];then
echo "drop group dba failed"
exit
fi
fi


NUM=`grep oinstall /etc/group |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "oinstall group is droped"
groupdel oinstall
if [ ! $? -eq 0 ];then
echo "drop group oinstall failed"
exit
fi

fi


NUM=`grep asmdba /etc/group |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "asmdba group is droped"
groupdel asmdba
fi


NUM=`grep asmoper /etc/group |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "asmoper group is droped"
groupdel asmoper
fi


NUM=`grep asmadmin /etc/group |wc -l`
if [ ${NUM} -gt 0 ]
then
date
echo "asmadmin group is droped"
groupdel asmadmin
fi



if [ -d ${INSTALL_BASE_DIRECTORY}/app/oracle/product/${INSTALL_BASE_VERSION}/db_1 ]
then
date
echo "${INSTALL_BASE_DIRECTORY}/app/oracle/product/${INSTALL_BASE_VERSION}/db_1  is droped"
rm -rf ${INSTALL_BASE_DIRECTORY}/app/oracle/product/${INSTALL_BASE_VERSION}/db_1
fi

if [ -d ${INSTALL_BASE_DIRECTORY}/app/oracle ]
then
date
echo "${INSTALL_BASE_DIRECTORY}/app/oracle is droped"
rm -rf ${INSTALL_BASE_DIRECTORY}/app/oracle
fi

if [ -d ${INSTALL_BASE_DIRECTORY}/app/${INSTALL_BASE_VERSION}/grid ]
then
date
echo "${INSTALL_BASE_DIRECTORY}/app/${INSTALL_BASE_VERSION}/grid is droped"
rm -rf ${INSTALL_BASE_DIRECTORY}/app/${INSTALL_BASE_VERSION}/grid
fi

if [ -d ${INSTALL_BASE_DIRECTORY}/app/grid ]
then
date
echo "${INSTALL_BASE_DIRECTORY}/app/grid is droped"
rm -rf ${INSTALL_BASE_DIRECTORY}/app/grid
fi

if [ -d ${INSTALL_BASE_DIRECTORY}/app/oraInventory ]
then
date
echo "${INSTALL_BASE_DIRECTORY}/app/oraInventory is droped"
rm -rf ${INSTALL_BASE_DIRECTORY}/app/oraInventory
fi


if [ -f /lib64/libcap.so.2 ]
then
ln -s /lib64/libcap.so.2  /lib64/libcap.so.1
fi



groupadd -g 1001 oinstall
groupadd -g 1002 dba
groupadd -g 1003 asmadmin
groupadd -g 1004 asmdba
groupadd -g 1005 asmoper

useradd -u 1001 -g oinstall -G asmadmin,asmdba,asmoper ${GRID_OWNER}
useradd -u 1002 -g oinstall -G dba,asmdba ${ORACLE_OWNER}

echo Abcd1234 |passwd --stdin ${GRID_OWNER}
echo Abcd1234 |passwd --stdin ${ORACLE_OWNER}

mkdir -p ${INSTALL_BASE_DIRECTORY}/app/oraInventory
chown -R ${GRID_OWNER}:oinstall ${INSTALL_BASE_DIRECTORY}/app/oraInventory
chmod -R 775 ${INSTALL_BASE_DIRECTORY}/app/oraInventory

mkdir -p ${INSTALL_BASE_DIRECTORY}/app/grid
chown -R ${GRID_OWNER}:oinstall ${INSTALL_BASE_DIRECTORY}/app/grid
chmod -R 775 ${INSTALL_BASE_DIRECTORY}/app/grid

mkdir -p ${INSTALL_BASE_DIRECTORY}/app/${INSTALL_BASE_VERSION}/grid
chown -R ${GRID_OWNER}:oinstall ${INSTALL_BASE_DIRECTORY}/app/${INSTALL_BASE_VERSION}/grid
chmod -R 775 ${INSTALL_BASE_DIRECTORY}/app/${INSTALL_BASE_VERSION}/grid

mkdir -p ${INSTALL_BASE_DIRECTORY}/app/oracle
chown -R ${ORACLE_OWNER}:oinstall ${INSTALL_BASE_DIRECTORY}/app/oracle
chmod -R 775 ${INSTALL_BASE_DIRECTORY}/app/oracle

mkdir -p ${INSTALL_BASE_DIRECTORY}/app/oracle/product/${INSTALL_BASE_VERSION}/db_1
chown -R ${ORACLE_OWNER}:oinstall ${INSTALL_BASE_DIRECTORY}/app/oracle/product/${INSTALL_BASE_VERSION}/db_1
chmod -R 775 ${INSTALL_BASE_DIRECTORY}/app/oracle/product/${INSTALL_BASE_VERSION}/db_1

modprobe bridge

sed -i '/pam_limits.so/d'                                /etc/pam.d/login
sed -i '$a \session required pam_limits.so'              /etc/pam.d/login

sed -i '/kernel.shmmni/d'                                /etc/sysctl.conf
sed -i '/kernel.sem/d'                                   /etc/sysctl.conf
sed -i '/fs.aio-max-nr/d'                                /etc/sysctl.conf
sed -i '/fs.file-max/d'                                  /etc/sysctl.conf
sed -i '/net.core.rmem_default/d'                        /etc/sysctl.conf
sed -i '/net.ipv4.ip_local_port_range/d'                 /etc/sysctl.conf
sed -i '/net.core.rmem_max = 4194304/d'                  /etc/sysctl.conf
sed -i '/net.core.wmem_default = 262144/d'               /etc/sysctl.conf
sed -i '/net.core.wmem_max = 1048576/d'                  /etc/sysctl.conf
sed -i '/vm.swappiness = 0/d'                            /etc/sysctl.conf
sed -i '/vm.dirty_background_ratio = 3/d'                /etc/sysctl.conf
sed -i '/vm.dirty_ratio = 80/d'                          /etc/sysctl.conf
sed -i '/vm.dirty_expire_centisecs = 500/d'              /etc/sysctl.conf
sed -i '/vm.dirty_writeback_centisecs = 100/d'           /etc/sysctl.conf

sed -i '$a \kernel.shmmni = 4096'                        /etc/sysctl.conf
sed -i '$a \kernel.sem = 250 32000 100 128'              /etc/sysctl.conf
sed -i '$a \fs.file-max = 6815744'                       /etc/sysctl.conf
sed -i '$a \fs.aio-max-nr = 1048576'                     /etc/sysctl.conf
sed -i '$a \net.ipv4.ip_local_port_range = 9000 65500'   /etc/sysctl.conf
sed -i '$a \net.core.rmem_default = 262144'              /etc/sysctl.conf
sed -i '$a \net.core.rmem_max = 4194304'                 /etc/sysctl.conf
sed -i '$a \net.core.wmem_default = 262144'              /etc/sysctl.conf
sed -i '$a \net.core.wmem_max = 1048576'                 /etc/sysctl.conf
sed -i '$a \vm.swappiness = 0'                           /etc/sysctl.conf
sed -i '$a \vm.dirty_background_ratio = 3'               /etc/sysctl.conf
sed -i '$a \vm.dirty_ratio = 80'                         /etc/sysctl.conf
sed -i '$a \vm.dirty_expire_centisecs = 500'             /etc/sysctl.conf
sed -i '$a \vm.dirty_writeback_centisecs = 100'          /etc/sysctl.conf

TOTAL_MEMORY=`cat /proc/meminfo|grep MemTotal |awk '{print $2}'`        
echo "Total Memory is:"$TOTAL_MEMORY
PAGESIZE=`getconf PAGE_SIZE`        
echo "PAGE SIZE is:"$PAGESIZE
                                    
SHMALL=`echo "${TOTAL_MEMORY} * 1024 / ${PAGESIZE} "|bc`                
SHMMAX=`echo "${TOTAL_MEMORY} * 1024 / 2" | bc`                         

SHMALL_IN_CONF=`grep "kernel.shmall" /etc/sysctl.conf |awk '{print $3}'`
SHMMAX_IN_CONF=`grep "kernel.shmmax" /etc/sysctl.conf |awk '{print $3}'`

echo "shmall in conf is :"${SHMALL_IN_CONF}                             
echo "calculated shmall is :"${SHMALL}                                  
                                                                        
if [ ${SHMALL_IN_CONF} -ge ${SHMALL} ]                                  
then                                                                    
echo "NOT recommanded modify shmall value in /etc/sysctl.conf"          
else                                                                    
echo "shmall value is ${SHMALL}" 
sed -i '/kernel.shmall/d' /etc/sysctl.conf 
sed -i '$a \kernel.shmall = '$SHMALL''  /etc/sysctl.conf  
fi                                                                      
                                                                        
echo "                     "                                            
echo "shmmax in conf is :"${SHMMAX_IN_CONF}                              
echo "calculated shmmax is :"${SHMMAX}

                                                                        
if [ ${SHMMAX_IN_CONF} -ge ${SHMMAX} ]                                  
then                                                                    
echo "NOT recommanded modify shmmax value in /etc/sysctl.conf"          
else                                                                    
echo "shmall value is ${SHMMAX}"  
sed -i '/kernel.shmmax/d' /etc/sysctl.conf 
sed -i '$a \kernel.shmmax = '$SHMMAX''  /etc/sysctl.conf 
fi  

TMP_CNT1=`grep "^if" /etc/profile |grep "\<${ORACLE_OWNER}\>"  |grep "\<${GRID_OWNER}\>" |grep ""|wc -l`
TMP_CNT2=`grep "ulimit -u 16384 -n 65536" /etc/profile|wc -l`
echo $TMP_CNT1
if [ ${TMP_CNT1} -eq 0 ] && [ ${TMP_CNT2} -eq 0 ]
then
echo "  "                                                                                >>/etc/profile
echo "if [ \$USER = \"${ORACLE_OWNER}\" ] || [ \$USER = \"${GRID_OWNER}\" ]; then"        >>/etc/profile
echo "   if [ \$SHELL = "'"/bin/ksh"'" ]; then"                                >>/etc/profile
echo "      ulimit -p 16384"                                                      >>/etc/profile
echo "      ulimit -n 65536"                                                      >>/etc/profile
echo "    else"                                                                 >>/etc/profile
echo "      ulimit -u 16384 -n 65536"                                             >>/etc/profile
echo "    fi"                                                                   >>/etc/profile
echo "umask 022"                                                            >>/etc/profile
echo "fi"                                                                   >>/etc/profile
fi 

TMP_CNT1=0
TMP_CNT2=0
TMP_CNT1=`grep "^if" /etc/csh.login |grep "\<${ORACLE_OWNER}\>"  |grep "\<${GRID_OWNER}\>" |grep ""|wc -l`
TMP_CNT2=`grep "limit descriptors 65536" /etc/profile|wc -l`
if [ ${TMP_CNT1} -eq 0 ] && [ ${TMP_CNT2} -eq 0 ]
then
echo "             "                                                                      >>/etc/csh.login
echo "if [ \$USER =\"${ORACLE_OWNER}\" ] || [ \$USER = \"${GRID_OWNER}\" ]; then"         >>/etc/csh.login
echo "limit maxproc 16384"                                                                >>/etc/csh.login
echo "limit descriptors 65536"                                                            >>/etc/csh.login
echo "endif"                                                                              >>/etc/csh.login
fi

sed -i '/'"${GRID_OWNER}"' soft nproc 2047/d'                         /etc/security/limits.conf
sed -i '/'"${GRID_OWNER}"' hard nproc 16384/d'                        /etc/security/limits.conf
sed -i '/'"${GRID_OWNER}"' soft nofile 1024/d'                        /etc/security/limits.conf
sed -i '/'"${GRID_OWNER}"' hard nofile 65536/d'                       /etc/security/limits.conf
sed -i '/'"${ORACLE_OWNER}"' soft nproc 2047/d'                       /etc/security/limits.conf
sed -i '/'"${ORACLE_OWNER}"' hard nproc 16384/d'                      /etc/security/limits.conf
sed -i '/'"${ORACLE_OWNER}"' soft nofile 1024/d'                      /etc/security/limits.conf
sed -i '/'"${ORACLE_OWNER}"' hard nofile 65536/d'                     /etc/security/limits.conf


sed -i '$a \'"${GRID_OWNER}"' soft nproc 2047'                         /etc/security/limits.conf
sed -i '$a \'"${GRID_OWNER}"' hard nproc 16384'                        /etc/security/limits.conf
sed -i '$a \'"${GRID_OWNER}"' soft nofile 1024'                        /etc/security/limits.conf
sed -i '$a \'"${GRID_OWNER}"' hard nofile 65536'                       /etc/security/limits.conf
sed -i '$a \'"${ORACLE_OWNER}"' soft nproc 2047'                       /etc/security/limits.conf
sed -i '$a \'"${ORACLE_OWNER}"' hard nproc 16384'                      /etc/security/limits.conf
sed -i '$a \'"${ORACLE_OWNER}"' soft nofile 1024'                      /etc/security/limits.conf
sed -i '$a \'"${ORACLE_OWNER}"' hard nofile 65536'                     /etc/security/limits.conf

sed -i '/'"${GRID_OWNER}"' soft nproc 2047/d'                           /etc/security/limits.d/90-nproc.conf
sed -i '/'"${GRID_OWNER}"' hard nproc 16384/d'                          /etc/security/limits.d/90-nproc.conf
sed -i '/'"${ORACLE_OWNER}"' soft nproc 2047/d'                         /etc/security/limits.d/90-nproc.conf
sed -i '/'"${ORACLE_OWNER}"' hard nproc 16384/d'                        /etc/security/limits.d/90-nproc.conf
                                                           
sed -i '$a \'"${GRID_OWNER}"' soft nproc 2047'                          /etc/security/limits.d/90-nproc.conf
sed -i '$a \'"${GRID_OWNER}"' hard nproc 16384'                         /etc/security/limits.d/90-nproc.conf
sed -i '$a \'"${ORACLE_OWNER}"' soft nproc 2047'                        /etc/security/limits.d/90-nproc.conf
sed -i '$a \'"${ORACLE_OWNER}"' hard nproc 16384'                       /etc/security/limits.d/90-nproc.conf


date
echo "Start to set env variable for grid ..."

sed -i '/ORACLE_BASE/d'                                                                               /home/${GRID_OWNER}/.bash_profile
sed -i '$a \export ORACLE_BASE='"${INSTALL_BASE_DIRECTORY}"'/app/grid'                                /home/${GRID_OWNER}/.bash_profile
sed -i '/ORACLE_HOME/d'                                                                       /home/${GRID_OWNER}/.bash_profile
sed -i '$a \export ORACLE_HOME='"${INSTALL_BASE_DIRECTORY}"'/app/'"${INSTALL_BASE_VERSION}"'/grid'    /home/${GRID_OWNER}/.bash_profile
sed -i '/ORACLE_SID/d'                                                                        /home/${GRID_OWNER}/.bash_profile
sed -i '$a \export ORACLE_SID=+ASM'"${NODE_NO}"''                                                     /home/${GRID_OWNER}/.bash_profile
sed -i '/NLS_LANG/d'                                                                          /home/${GRID_OWNER}/.bash_profile
sed -i '$a \export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK'                                        /home/${GRID_OWNER}/.bash_profile
sed -i '/ORACLE_HOME*OPatch/d'                                                                /home/${GRID_OWNER}/.bash_profile
sed -i '$a \export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH'                           /home/${GRID_OWNER}/.bash_profile
sed -i '/NAME=`hostname`/d'                                                                   /home/${GRID_OWNER}/.bash_profile
sed -i '$a \NAME=`hostname`'                                                                  /home/${GRID_OWNER}/.bash_profile
sed -i '/PS1/d'                                                                               /home/${GRID_OWNER}/.bash_profile
sed -i '$a \PS1="[$NAME:$LOGNAME]:\\\${PWD}>"'                                                /home/${GRID_OWNER}/.bash_profile
sed -i '/umask/d'                                                                             /home/${GRID_OWNER}/.bash_profile
sed -i '$a \umask 022'                                                                        /home/${GRID_OWNER}/.bash_profile



date
echo "Start to set env variable for oracle ..."

sed -i '/ORACLE_BASE/d'                                                                                      /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \export ORACLE_BASE='"${INSTALL_BASE_DIRECTORY}"'/app/oracle'                                         /home/${ORACLE_OWNER}/.bash_profile
sed -i '/ORACLE_HOME/d'                                                                                      /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a export ORACLE_HOME='"${INSTALL_BASE_DIRECTORY}"'/app/oracle/product/'"${INSTALL_BASE_VERSION}"'/db_1'     /home/${ORACLE_OWNER}/.bash_profile
sed -i '/ORACLE_UNQNAME/d'                                                                                   /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \export ORACLE_UNQNAME='"${DB_NAME}"''                                                                /home/${ORACLE_OWNER}/.bash_profile
sed -i '/ORACLE_SID/d'                                                                                       /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \export ORACLE_SID='"${DB_NAME}"''"${NODE_NO}"''                                                          /home/${ORACLE_OWNER}/.bash_profile
sed -i '/ORACLE_HOME*OPatch/d'                                                                               /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH'                                          /home/${ORACLE_OWNER}/.bash_profile
sed -i '/NLS_LANG/d'                                                                                         /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK'                                                       /home/${ORACLE_OWNER}/.bash_profile
sed -i '/NAME=`hostname`/d'                                                                                  /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \NAME=`hostname`'                                                                                 /home/${ORACLE_OWNER}/.bash_profile
sed -i '/PS1/d'                                                                                              /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \PS1="[$NAME:$LOGNAME]:\\\${PWD}>"'                                                               /home/${ORACLE_OWNER}/.bash_profile
sed -i '/umask/d'                                                                                            /home/${ORACLE_OWNER}/.bash_profile
sed -i '$a \umask 022'                                                                                       /home/${ORACLE_OWNER}/.bash_profile



sysctl -p

date
echo "Start to Packages......"
echo "PLS wait ......"
rpm -q --qf '%{NAME}-%{VERSION}-%{RELEASE} (%{ARCH})\n' binutils \
compat-libstdc++-33 \
compat-db \
elfutils-libelf \
elfutils-libelf-devel \
gcc \
gcc-c++ \
glibc \
glibc-common \
glibc-devel \
glibc-headers \
ksh \
libaio \
libaio-devel \
libgcc \
libstdc++ \
libstdc++-devel \
libXp \
make \
xclock \
sysstat \
man \
lsof \
expect \
unzip \
redhat-lsb \
openmotif \
openmotif22 \
openssh-clients \
smartmontools \
unixODBC \
perl \
telnet \
telnet-server \
vsftpd \
ntsysv \
lsscsi \
strace \
sg3_utils \
kexec-tools  \
ftp \
unixODBC-devel |grep "not installed" |awk '{print $2}' |xargs yum install -y

echo "Start to install X Windows"

yum groupinstall "X Window System" -y

echo "Start to install chinese support"

yum groupinstall "Chinese Support" -y 

setenforce 0
sed -i 's/#PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
sed -i '/SELINUX=/d'              /etc/selinux/config
sed -i '$a \SELINUX=disabled'     /etc/selinux/config

sed -i '/anonymous_enable=YES/d'  /etc/vsftpd/vsftpd.conf
sed -i '$a \anonymous_enable=NO' /etc/vsftpd/vsftpd.conf

sed -i 's/crashkernel=auto/crashkernel=128M/' /etc/grub.conf
sed -i 's/transparent_hugepage=never//' /etc/grub.conf  
sed -i 's/rhgb quiet/ transparent_hugepage=never rhgb quiet/' /etc/grub.conf 

date
echo "Start to disable ctrl + alt + delete"
if [ -f /etc/init/control-alt-delete.conf ]
then
mv /etc/init/control-alt-delete.conf /etc/init/control-alt-delete.conf.bak
fi


date
echo "Start to lock account"

passwd -l uucp 
passwd -l bin 
passwd -l daemon 
passwd -l lp 
passwd -l nobody
passwd -l adm
passwd -l games
passwd -l uucp
passwd -l nuucp

date
echo "Start to set TMOUT "
sed -i '/TMOUT=600/d'                                /etc/profile
sed -i '$a \TMOUT=600'                               /etc/profile

date
echo "Start to configure system service"
chkconfig xinetd   on
chkconfig vsftpd   on

chkconfig sendmail  off
chkconfig    ip6tables  off
chkconfig    bluetooth  off
chkconfig    postfix  off
chkconfig    iptables off
chkconfig    NetworkManager off
chkconfig    fingerd off
chkconfig    kdump on





