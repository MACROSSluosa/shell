set lines 200 pages 0
set long 50000
set longchunk 50000
set trimspool off

exec dbms_metadata.SET_TRANSFORM_PARAM(dbms_metadata.session_transform,'STORAGE',FALSE) ; 
exec dbms_metadata.SET_TRANSFORM_PARAM(dbms_metadata.session_transform,'SEGMENT_ATTRIBUTES',FALSE) ;  
EXEC DBMS_METADATA.set_transform_param(DBMS_METADATA.session_transform,'SQLTERMINATOR', TRUE);
EXEC DBMS_METADATA.set_transform_param(DBMS_METADATA.session_transform,'PRETTY', TRUE);


SELECT DBMS_METADATA.GET_DDL('TABLE',UPPER('&TableName'),UPPER('&USERNAME')) from dual;



