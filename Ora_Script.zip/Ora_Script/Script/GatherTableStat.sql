select to_char(sysdate,'yyyymmdd hh24:mi:ss') from dual;
prompt "begin Gather Table's Statstics,Please waiting......"
exec dbms_stats.gather_table_stats('&owner','&table_name',CASCADE => TRUE ,degree => &parallel_count,NO_INVALIDATE => FALSE);
select to_char(sysdate,'yyyymmdd hh24:mi:ss') from dual;
