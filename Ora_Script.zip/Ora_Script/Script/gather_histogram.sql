
set lines 200 pages 0
set feedback off
spool /tmp/gather_histogram.sql
select 'EXEC DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'||CHR(39)||OWNER||CHR(39)||',TABNAME=>'||CHR(39)||TABLE_NAME||CHR(39)||',METHOD_OPT=>'||CHR(39)||'FOR COLUMNS '||COLUMN_NAME||' SIZE AUTO'||CHR(39)||',DEGREE=>4) ;'
from dba_tab_col_statistics
where HISTOGRAM IN ('FREQUENCY','HEIGHT BALANCED')
and owneR not in (select username from dba_users where default_tablespace  in ('SYSTEM','SYSAUX'))
ORDER BY OWNER,TABLE_NAME,COLUMN_NAME ;
spool off

