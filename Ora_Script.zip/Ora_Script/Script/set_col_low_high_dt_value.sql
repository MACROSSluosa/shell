ALTER SESSION SET NLS_DATE_FORMAT='YYYYMMDD HH24MISS';
set linesize 200 pagesize 1000
set serveroutput on
col low_value   new_value low_value   noprint
col high_value  new_value high_value  noprint
col table_owner new_value table_owner noprint
col table_name  new_value table_name  noprint
col column_name new_value column_name noprint

prompt
prompt "---------------------The Date Format----------------------------------"
PROMPT "LOW_VALUE FORMAT :  YYYYMMDD HH24MISS"
PROMPT "HIGH_VALUE FORMAT : YYYYMMDD HH24MISS"
prompt "----------------------------------------------------------------------"

SELECT UPPER('&table_owner') table_owner,
       UPPER('&table_name')  table_name,
       UPPER('&column_name') column_name,
       '&low_value' LOW_VALUE,
       '&high_value' HIGH_VALUE FROM DUAL;


DECLARE
   srec               DBMS_STATS.STATREC;
   v_distcnt          NUMBER;
   v_density          NUMBER;
   v_nullcnt          NUMBER;
   v_avgclen          NUMBER;
   numvals            DBMS_STATS.NUMARRAY;
   charvals           DBMS_STATS.CHARARRAY;
   datevals           DBMS_STATS.DATEARRAY;
BEGIN

	DBMS_STATS.get_column_stats (ownname      => '&TABLE_OWNER',
                                tabname      => '&TABLE_NAME',
                                colname      => '&COLUMN_NAME',
                                distcnt      => v_distcnt,
                                density      => v_density,
                                nullcnt      => v_nullcnt,
                                srec         => srec,
                                avgclen      => v_avgclen
                               );

	
	
   datevals := DBMS_STATS.datearray (TO_DATE('&LOW_VALUE','YYYYMMDD HH24MISS'), TO_DATE('&HIGH_VALUE','YYYYMMDD HH24MISS'));
   
   DBMS_STATS.prepare_column_values (srec, datevals);

   DBMS_STATS.set_column_stats (ownname      => '&TABLE_OWNER',
                                tabname      => '&TABLE_NAME',
                                colname      => '&COLUMN_NAME',
                                distcnt      => v_distcnt,
                                density      => v_density,
                                nullcnt      => v_nullcnt,
                                srec         => srec,
                                avgclen      => v_avgclen
                               );
   COMMIT;
END;
/

prompt
prompt "Set the new low and high date value finished"
prompt
prompt
prompt "new stats info:                    "
prompt
select low_value,high_value from dba_tab_col_statistics where table_name='&table_name' and column_name='&column_name';

declare
min_date date;
max_date date;
begin
dbms_stats.CONVERT_RAW_VALUE('&low_value',min_date);
dbms_stats.CONVERT_RAW_VALUE('&high_value',max_date);
dbms_output.put_line('the New min date is '||min_date);
dbms_output.put_line('the New max date is '||max_date);
end;
/

set serveroutput off
set lines 132 pages 
undefine low_value
undefine high_value
undefine table_owner
undefine table_name
undefine column_name

