set heading off echo off feedback off linesize 132 pagesize 0

---undo���ռ�active״̬�İٷֱ�------------------------
---�����ؼ��֣�ACTIVE UNDO EXTENT REACH----------------
-------------------------------------------------------
select c.tablespace_name || ' ACTIVE UNDO EXTENT REACH ' ||
       round(100 * nvl(d.active_b, 0) / c.sum_b, 0) ||
       '%,please add undo tablespace! --Database Warning '
  from (select a.tablespace_name, sum(bytes) sum_b
          from dba_data_files a, dba_tablespaces b
         where a.tablespace_name = b.tablespace_name
           and b.contents = 'UNDO'
         group by a.tablespace_name) c,
       (select tablespace_name, sum(bytes) active_b
          from dba_undo_extents
         where status = 'ACTIVE'
         group by tablespace_name) d
 where c.tablespace_name = d.tablespace_name(+)
   and round(100 * nvl(d.active_b, 0) / c.sum_b, 0) > 80;
   
---temp���ռ�����ʹ�õĿռ�ٷֱ�------------------------
---�����ؼ��֣�CURRENT TEMP SEGMENT REACH----------------
---------------------------------------------------------
select t.tablespace_name || ' TABLESPACE CURRENT TEMP SEGMENT REACH ' ||
       round(100 * s.current_temp_used / t.sum_temp, 0) || '% --Database Warning '
  from (select /*+ no_merge */
         tablespace_name, sum(bytes) sum_temp
          from dba_temp_files
         group by tablespace_name) t,
       (select /*+ no_merge */
         tablespace_name tablespace_name,
         (used_blocks * (select /*+ no_merge */
                          value
                           from v$parameter
                          where name = 'db_block_size')) current_temp_used
          from gv$sort_segment) s
 where t.tablespace_name = s.tablespace_name
   and round(100 * s.current_temp_used / t.sum_temp, 0) > 80 ;
   
   
---process����ҵ���ֵ���-------------------------------
---�����ؼ��֣�of process limit--------------------------
---------------------------------------------------------
select 'instance ' || a.inst_id || ' oracle process reach ' ||
       round(100 * a.process_count / b.parameter_value, 0) ||
       '% of process limit--Database Warning'
  from (select inst_id, count(*) process_count
          from gv$process
         group by inst_id) a,
       (select /*+ no_merge */
         inst_id, value parameter_value
          from gv$parameter
         where name = 'processes') b
 where a.inst_id = b.inst_id
   and round(100 * a.process_count / b.parameter_value, 0) > 70;


---process������ˮλ���---------------------------------
---�����ؼ��֣�Processes ParameterHigh Water Mask-----------------
---------------------------------------------------------
select 'Database Warning instance ' || inst_id ||
       ' Processes Parameter High Water Mask ,Current value: ' ||
       MAX_UTILIZATION || ' Limit_value: ' || trim(limit_value)
  from (select /*+ no_merge*/
         inst_id, MAX_UTILIZATION, limit_value
          from gv$resource_limit
         where resource_name = 'processes')
 where 100 * MAX_UTILIZATION / limit_value > 85;
   
 
---sequenceʹ����----------------------------------------
----��Ҫ������ط�ʽ-------------------------------------
---�����ؼ��֣�Database Sequence-------------------------
---------------------------------------------------------
select 'Database Warning Sequence ' || a.sequence_owner || '.' || a.sequence_name ||
       ' reach ' || round(100 * (case
                            when INCREMENT_BY < 0 then
                             abs(a.last_number - a.MAX_VALUE) / abs(a.max_value - MIN_VALUE)
                            when INCREMENT_BY > 0 then
                             abs(a.last_number - a.MIN_VALUE) / abs(a.max_value - MIN_VALUE)
                          end),
                          0) || '%'
  from dba_sequences a
 where cycle_flag = 'N'
   and sequence_owner not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX'))
   and round(100 * (case when INCREMENT_BY < 0 then
              abs(a.last_number - a.MAX_VALUE) /
              abs(a.max_value - MIN_VALUE) when INCREMENT_BY > 0 then
              abs(a.last_number - a.MIN_VALUE) /
              abs(a.max_value - MIN_VALUE) end),
             0) >= 80;
   
   
---��Ч����----------------------------------------------
---�����ؼ��֣�Database Found invalid index----------------
---------------------------------------------------------
select 'Database Warning Found invalid index ' || owner || '.' || index_name
  from dba_indexes
 where status not in ('VALID', 'N/A')
union all
select 'database found invalid index ' || index_owner || '.' || index_name
  from dba_ind_partitions
 where status not in ('USABLE', 'N/A')
union all
select 'database found invalid index ' || index_owner || '.' || index_name
  from dba_ind_subpartitions
 where status not in ('USABLE', 'N/A');
 

---PGAй©���-------------------------------------------
---�����ؼ��֣�PGA memory leak---------------------------
---------------------------------------------------------
select 'Database Warning instance ' || inst_id || 'processid ' || spid ||
       ' occupy PGA memory ' || round(pga_alloc_mem / 1024 / 1024, 0) ||
       ' M,there maybe PGA memory leak'
  from gv$process
 where pga_alloc_mem / 1024 / 1024 / 1024 >= 2 ;
 
 
 
---job״̬�ļ��-----------------------------------------
---�����ؼ��֣�Is Broken---------------------------------
---------------------------------------------------------
SELECT 'Database Warning ' || log_user || '.job_id_' || job || ':' || what ||
       'Is Broken '
  FROM dba_jobs
 WHERE broken = 'Y';
 
 
---����10���Ựͬһʱ���ڵ�ĳһ��Դ----------------------
---�����ؼ��֣�Maybe Bad performance---------------------
---------------------------------------------------------
select 'Database Warning Database Has ' || count(*) || ' Sessions ' || 'Waiting for ' || '"' ||
       event || '"' || ' Maybe Bad performance!'
  from gv$session
 where wait_class not in ('Idle', 'Administrative')
   and state = 'WAITING'
   and upper(event) not like '%BACKUP%'
   and upper(event) not like '%NULL%'
 group by event
having count(*) >= 20
   
 
 
---�Ự��ʱ��ȴ���Դ�ļ��------------------------------
---�����ؼ��֣�Had been waiting for Database Resource----
---------------------------------------------------------
select 'Database Warning ORACLE session ' || inst_id || '.' || sid ||
       ' Had been waiting for Database Resource ' || '''' || '''' || event || '''' || '''' ||
       ' for ' || seconds_in_wait || ' seconds! holder is' ||
       blocking_instance || '.' || blocking_session
  from gv$session
 where wait_class not in ('Idle', 'Administrative')
   and state = 'WAITING'
   and seconds_in_wait > = 120
   and upper(event) not like '%BACKUP%'
   and upper(event) not like '%NULL%'
   and upper(event) not like 'PX%'
   and upper(event) not like '%SQL%';
   

   
---������ļ��------------------------------------------
---�����ؼ��֣�The Big Transaction-----------------------
---------------------------------------------------------   
select b.inst_id || '_' || b.sid || '_' || sql_id ||
       ' The Big Transaction modify '||used_urec||' rows had run for ' ||
       (sysdate - a.start_date) * 24 * 60 * 60 || 'seconds ! --Database Warning'
  from gv$transaction a, gv$session b
 where a.addr = b.taddr
   and a.inst_id = b.inst_id
   and a.USED_UREC >= 100000
   and (sysdate - a.start_date) * 24 * 60 * 60 > 14400 ;
   
   

 
---Ӧ���û���״̬����������������±�����----------------
---�����ؼ��֣�Attention:Database User-------------------
--------------------------------------------------------- 
select 'Database Warning Attention:Database User ' || username || ' IS ' || account_status
  from dba_users
 where default_tablespace not in ('SYSTEM', 'SYSAUX', 'USERS')
   and account_status != 'OPEN';  
   


   
---ִ��ʱ�䳬��3��Сʱ��SQL�ļ��------------------------
---�����ؼ��֣�Database long session---------------------
---------------------------------------------------------    
select 'Database Warning Database long session ' || inst_id || '_' || sid || '_' || sql_id || '_' ||
       username || ' Was runing more than ' || elapsed_seconds ||
       ' Seconds!'
  from gv$session_longops 
 where sofar != totalwork
   and username != 'SYS'
   and sql_id is not null
   and elapsed_seconds > 10800
     and Not exists (select '1' from gv$session S where s.inst_id = gv$session_longops.inst_id
                                              and s.sid = gv$session_longops.sid
                                              and (Upper(s.program) like 'RMAN%' OR Upper(s.module) like 'EXP%')
                                              and s.wait_class  in ('Idle', 'Administrative')  
                                              and s.username <> 'SYS'
                   )
 ;
   

