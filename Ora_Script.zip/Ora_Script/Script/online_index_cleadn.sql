                        
DECLARE                                
isClean BOOLEAN;                            
BEGIN                                       
isClean := DBMS_REPAIR.ONLINE_INDEX_CLEAN();
END;                                        
/                                           