set  linesize 200 pagesize 1000
col opname for a20
col target for a15
col pct for a6
col inst_id for 99999
col sid for 9999
select inst_id,
       sid,
       sofar,
       totalwork,
       trunc(sofar * 100 / totalwork) || '%' pct,
       opname,
       target
  from gv$session_longops
 where sofar != totalwork
   and totalwork != 0
 order by inst_id;
