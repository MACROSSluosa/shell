[dpjfds:oracle]:/tmp/awr_import>cat awr_import.sh
export LANG="en_US.UTF-8"
export ORACLE_BASE=/oracle
export ORACLE_HOME=$ORACLE_BASE/product/db10201
export ORACLE_SID=awrrep
export NLS_LANG="SIMPLIFIED CHINESE_CHINA.ZHS16GBK"
export ORA_NLS10=$ORACLE_HOME/nls/data
LD_LIBRARY_PATH=/lib:/usr/lib:/usr/openwin/lib:/usr/local/lib:$ORACLE_HOME/lib:$ORACLE_HOME/network/lib:$ORACLE_HOME/rdbms/li
b
export LD_LIBRARY_PATH
PATH=/bin:/usr/bin:/usr/openwin/bin:/usr/ucb:/usr/sbin:/usr/ccs/bin:/sbin:/usr/local/bin:$ORACLE_HOME/bin:$CRS_HOME/bin:/usr/
bin/X11:/etc:$PATH:$ORACLE_HOME/OPatch:.
export PATH
CLASSPATH=$ORACLE_HOME/JRE/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib:$ORACLE_HOME/rdbms/jlib:$ORACLE_HOME/plsql/jlib:$O
RACLE_HOME/assistants/jlib:$ORACLE_HOME/assistants/dbca/jlib
export CLASSPATH
export DBCA_RAW_CONFIG=/oracle/app/oracle/raw_config.conf
export EDITOR=vi
export AIXTHREAD_SCOPE=S

set -o vi
NAME=`hostname`
PS1="[$NAME:$LOGNAME]:\${PWD}>"
ORACLE_HOME=/oracle/product/db10201
PATH=$PATH:ORACLE_HOME/bin
NOW_DAT=`date "+%m%d"`;
ls -l /data_center/awr/awrimp/|grep dmp|awk '{print $9}'|sed -e 's/.dmp//'>/tmp/dump.list
cat /tmp/dump.list|while read dmpfile
do
sqlplus '/as sysdba'<<EOF
create user awr_stage
  identified by awr_stage
  default tablespace SYSAUX
  temporary tablespace TEMP;
  
alter user awr_stage quota unlimited on SYSAUX;

begin
  /* call PL/SQL routine to load the data into the staging schema */
  dbms_swrf_internal.set_awr_dbid(-2);
  dbms_swrf_internal.awr_load('AWR_STAGE','$dmpfile','DATA_PUMP_DIR');
  dbms_swrf_internal.clear_awr_dbid;
end;
/

begin
  /* call PL/SQL routine to move the data into AWR */
  dbms_swrf_internal.set_awr_dbid(-2);
  dbms_swrf_internal.move_to_awr('AWR_STAGE');
  dbms_swrf_internal.clear_awr_dbid;
end;
/
drop user awr_stage cascade;

prompt
prompt End of AWR Load
EOF
done
cd /data_center/awr 
mv awrimp awrimp$NOW_DAT
mkdir awrimp
chmod 777 awrimp
chmod 777 /data_center/awr/awrimp
