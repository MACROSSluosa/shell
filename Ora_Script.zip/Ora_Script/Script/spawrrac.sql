Rem
Rem $Header: spawrrac.sql 28-feb-2007.18:32:24 cgervasi Exp $
Rem
Rem spawrrac.sql
Rem
Rem Copyright (c) 2007, Oracle. All rights reserved.
Rem
Rem    NAME
Rem      spawrrac.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    cgervasi    03/14/07 - change formatting
Rem    cgervasi    02/28/07 - check in; additional sections
Rem    cdgreen     08/23/06 - Created with cgervasi
Rem

set longchunksize 5000

--
-- Get the report settings


Rem     -------------           Beginning of                -----------
Rem     ------------- Customer Configurable Report Settings -----------

--
-- Snapshot related report settings

-- The default number of days of snapshots to list when displaying the
-- list of snapshots to choose the begin and end snapshot Ids from.
--
--   List all snapshots
--define num_days = '';
--
--   List last 31 days
define num_days = 31;
--
--   List no (i.e. 0) snapshots
-- define num_days = 0;


-- ----------------------------------------

-- Number of events to display in Top Timed Events
define top_n_events = 10;

--
-- SQL related report settings

-- Number of Rows of SQL to display in each SQL section of the report
define top_n_sql = 20;

--
-- Segment Statistics

-- Number of segments to display for each segstat category
define top_n_segstat = 10;


Rem     -------------                End  of                -----------
Rem     ------------- Customer Configurable Report Settings -----------
-- -------------------------------------------------------------------------

--
--

clear break compute;
repfooter off;
ttitle off;
btitle off;
set timing off veri off space 1 flush on pause off termout on numwidth 10;
set echo off feedback off pagesize 60 linesize 185 newpage 1 recsep off;
set trimspool on trimout on define "&" concat "." serveroutput on;
--
--  Must not be modified
--  Bytes to megabytes
define btomb = 1048576;
--  Bytes to kilobytes
define btokb = 1024;

--  Microseconds to milli-seconds
define ustoms = 1000;
--  Microseconds to seconds
define ustos = 1000000;
define cstos = 100;
define cstoms = 10;
define total_event_time_s_th = .001;
define pct_cpu_diff_th = 5;


--
-- Request the DB Id

column instt_num  heading "Inst Num"  format 99999;
column instt_name heading "Instance"  format a12;
column dbb_name   heading "DB Name"   format a12;
column dbbid      heading "DB Id"     format 9999999999 just c;
column host       heading "Host"      format a12;
column instt_tot  heading "Instance|Count"   format 999

prompt
prompt
prompt Instances in this AWR schema
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
select dbid            dbbid
     , db_name         dbb_name
     , count(distinct instance_number) instt_tot
  from dba_hist_database_instance
 group by dbid, db_name
 order by dbid;


prompt
prompt Using &&dbid for database Id


--
--  Set up the binds for dbid and instance_number

variable dbid       number;
begin
  :dbid      :=  &dbid;
end;
/

--
--  Ask how many days of snapshots to display

set termout on;
column instart_fmt noprint;
column inst_name   format a12  heading 'Instance';
column db_name     format a12  heading 'DB Name';
column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a17  heading 'End Interval Time'
column lvl         format 99   heading 'Snap|Level';

prompt
prompt
prompt Specify the number of days of snapshots to choose from
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt Entering the number of days (n) will result in the most recent
prompt (n) days of snapshots being listed.  Pressing <return> without
prompt specifying a number lists all completed snapshots.
prompt
prompt

set heading off;
column num_days new_value num_days noprint;
select    'Listing '
       || decode( nvl('&&num_days', 3.14)
                , 0    , 'no snapshots'
                , 3.14 , 'all Completed Snapshots'
                , 1    , 'the last day''s Completed Snapshots'
                , 'the last &num_days days of Completed Snapshots')
     , nvl('&&num_days', 3.14)  num_days
  from sys.dual;
set heading on;


--
-- List available snapshots

break on inst_name on db_name on host on instart_fmt skip 1;
ttitle off;
column instances_up format 9999 heading 'Instance|Count'
column db_name      new_value db_name
select -- to_char(s.startup_time,' dd Mon "at" HH24:mi:ss')  instart_fmt
       -- di.instance_name                                   inst_name
       di.db_name                                         db_name
     , s.snap_id                                          snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
     , s.snap_level                                       lvl
     , count(1) instances_up
  from dba_hist_snapshot s
     , dba_hist_database_instance di
 where s.dbid              = :dbid
   and di.dbid             = :dbid
   and di.dbid             = s.dbid
   and di.instance_number  = s.instance_number
   and di.startup_time     = s.startup_time
   and s.end_interval_time > (sysdate - &num_days-1)
group by di.db_name
       , s.snap_id
       , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi')
       , s.snap_level
order by db_name, snap_id;

clear break;
ttitle off;


--
--  Ask for the snapshots Id's which are to be compared

prompt
prompt
prompt Specify the Begin and End Snapshot Ids
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt Begin Snapshot Id specified: &&begin_snap
prompt
prompt End   Snapshot Id specified: &&end_snap
prompt


--
--  Set up the snapshot-related binds

variable bid        number;
variable eid        number;
begin
  :bid       :=  &begin_snap;
  :eid       :=  &end_snap;
end;
/

prompt


-- Use report name if specified, otherwise prompt user for output file
-- name (specify default), then begin spooling

set termout off;
column dflt_name new_value dflt_name noprint;
select 'spawrrac_'|| :bid||'_'||:eid dflt_name from dual;
set termout on;

prompt
prompt Specify the Report Name
prompt ~~~~~~~~~~~~~~~~~~~~~~~
prompt The default report file name is &dflt_name..  To use this name,
prompt press <return> to continue, otherwise enter an alternative.
prompt

set heading off;
column report_name new_value report_name noprint;
select 'Using the report name ' || nvl('&&report_name','&dflt_name')
     , decode( instr(nvl('&&report_name','&dflt_name'),'.'), 0, nvl('&&report_name','&dflt_name')||'.lst'
             , nvl('&&report_name','&dflt_name')) report_name
  from sys.dual;
prompt

--
-- Standard formatting

column chr4n      format a4      newline
column ch5        format a5
column ch5        format a5
column ch6        format a6
column ch6n       format a6      newline
column ch7        format a7
column ch7n       format a7      newline
column ch9        format a9
column ch14n      format a14     newline
column ch16t      format a16              trunc
column ch17       format a17
column ch17n      format a17     newline
column ch18n      format a18     newline
column ch19       format a19
column ch19n      format a19     newline
column ch21       format a21
column ch21n      format a21     newline
column ch22       format a22
column ch22n      format a22     newline
column ch23       format a23
column ch23n      format a23     newline
column ch24       format a24
column ch24n      format a24     newline
column ch25       format a25
column ch25n      format a25     newline
column ch20       format a20
column ch20n      format a20     newline
column ch32n      format a32     newline
column ch40n      format a40     newline
column ch42n      format a42     newline
column ch43n      format a43     newline
column ch52n      format a52     newline  just r
column ch53n      format a53     newline
column ch59n      format a59     newline  just r
column ch78n      format a78     newline
column ch80n      format a80     newline

column num3       format             999                 just left
column num3_2     format             999.99
column num3_2n    format             999.99     newline
column num4c      format           9,999
column num4c_2    format           9,999.99
column num4c_2n   format           9,999.99     newline
column num5c      format          99,999
column num6c      format         999,999
column num6c_2    format         999,999.99
column num6c_2n   format         999,999.99     newline
column num6cn     format         999,999        newline
column num7c      format       9,999,999
column num7c_2    format       9,999,999.99
column num8c      format      99,999,999
column num8cn     format      99,999,999        newline
column num8c_2    format      99,999,999.99
column num8cn     format      99,999,999        newline
column num9c      format     999,999,999
column num9cn     format     999,999,999        newline
column num10c     format   9,999,999,999


-- ------------------------------------------------------------------
-- Gather information for use in later sections

/* calculate system totals for use in SQL section  */

set heading off termout off feedback off
ttitle off
repfooter off

col bnuminst new_value bnuminst noprint
col enuminst new_value enuminst noprint
select sum(case when snap_id = :bid then 1 else 0 end) bnuminst
     , sum(case when snap_id = :eid then 1 else 0 end) enuminst
  from dba_hist_snapshot
 where snap_id in (:bid, :eid)
   and dbid    = :dbid;

select 'Warning: number of instances is not equal at begin and end snap'
  from dual
 where &bnuminst != &enuminst;

col tdbtim new_value tdbtim  noprint
col tdbcpu new_value tdbcpu  noprint
col tbgtim new_value tbgtim  noprint
col tbgcpu new_value tbgcpu  noprint
col tgets  new_value tgets   noprint
col trds   new_value trds    noprint
col texecs new_value texecs  noprint
col tclutm new_value tclutm  noprint
col tgccrr new_value tgccrr  noprint
col tgccur new_value tgccur  noprint
col tgccrs new_value tgccrs  noprint
col tgccus new_value tgccus  noprint
col tucm   new_value tucm    noprint
col tur    new_value tur     noprint

select sum(case when e.stat_name = 'DB time'
                then e.value - b.value
                else 0
            end) tdbtim
     , sum(case when e.stat_name = 'DB CPU'
                then e.value - b.value
                else 0
            end) tdbcpu
     , sum(case when e.stat_name = 'background elapsed time'
                then e.value - b.value
                else 0
            end) tbgtim
     , sum(case when e.stat_name = 'background cpu time'
                then e.value - b.value
                else 0
            end) tbgcpu
  from dba_hist_sys_time_model b
     , dba_hist_sys_time_model e
 where e.dbid            = :dbid
   and e.dbid            = b.dbid
   and e.instance_number = b.instance_number
   and e.snap_id         = :eid
   and b.snap_id         = :bid
   and b.stat_id         = e.stat_id
   and e.stat_name in ('DB time','DB CPU'
                      ,'background elapsed time','background cpu time');

select sum(case when e.stat_name = 'session logical reads'
                then e.value - b.value
                else 0
            end) tgets
     , sum(case when e.stat_name = 'physical reads' -- physical reads cache?
                then e.value - b.value
                else 0
            end) trds
     , sum(case when e.stat_name = 'execute count'
                then e.value - b.value
                else 0
            end) texecs
     , sum(case when e.stat_name = 'gc cr blocks received'
                then e.value - b.value
                else 0
            end) tgccrr
     , sum(case when e.stat_name = 'gc current blocks received'
                then e.value - b.value
                else 0
            end) tgccur
     , sum(case when e.stat_name = 'gc cr blocks served'
                then e.value - b.value
                else 0
            end) tgccrs
     , sum(case when e.stat_name = 'gc current blocks served'
                then e.value - b.value
                else 0
            end) tgccus
     , sum(case when e.stat_name = 'user commits'
                then e.value - b.value
                else 0
            end) tucm
     , sum(case when e.stat_name = 'user rollbacks'
                then e.value - b.value
                else 0
            end) tur
  from dba_hist_sysstat b
     , dba_hist_sysstat e
 where e.dbid            = :dbid
   and e.dbid            = b.dbid
   and e.instance_number = b.instance_number
   and e.snap_id         = :eid
   and b.snap_id         = :bid
   and b.stat_id         = e.stat_id
   and e.stat_name in ('session logical reads','physical reads','execute count'
   , 'gc cr blocks received', 'gc current blocks received'
   , 'gc cr blocks served', 'gc current blocks served'
   , 'user commits', 'user rollbacks'
   );
 
select sum(case when e.wait_class = 'Cluster'
                then e.time_waited_micro - b.time_waited_micro
                else 0
            end) tclutm
  from dba_hist_system_event b
     , dba_hist_system_event e
 where e.dbid            = :dbid
   and e.dbid            = b.dbid (+)
   and e.instance_number = b.instance_number (+)
   and e.snap_id         = :eid
   and b.snap_id    (+)  = :bid
   and e.event_id   = b.event_id  (+)
   and e.wait_class = 'Cluster';

variable numinst number;
variable tdbtim number;
variable tdbcpu number;
variable tbgtim number;
variable tbgcpu number;
variable tgets  number;
variable trds   number;
variable texecs number;
variable tclutm number;
variable tgccrr number
variable tgccur number
variable tgccrs number
variable tgccus number
variable tucm   number
variable tur    number


begin
   :numinst := &enuminst;
   :tdbtim := &tdbtim;
   :tdbcpu := &tdbcpu;
   :tbgtim := &tbgtim;
   :tbgcpu := &tbgcpu;
   :tgets  := &tgets;
   :trds   := &trds;
   :texecs := &texecs;
   :tclutm := to_number(trim('&tclutm')); -- to allow it to work in a non-RAC environment
   :tgccrr := &tgccrr;
   :tgccur := &tgccur;
   :tgccrs := &tgccrs;
   :tgccus := &tgccus;
   :tucm   := &tucm;
   :tur    := &tur;
end;
/

-- ------------------------------------------------------------------

spool &report_name;
set newpage 1 heading on

prompt
prompt  Server Performance RAC report for Database &&db_name: Snaps &&begin_snap to &&end_snap
prompt

--
--  Summary Statistics
--

--
--  Print database, instance, parallel, release, host and snapshot
--  information

column dbid            format 9999999999   heading 'DB Id'
column instance_number format 999          heading 'Inst #'
column instance_name   format a9           heading 'Instance'
column host_name       format a10 trunc    heading 'Host'
column startup_time    format a15 trunc    heading 'Startup'
column begin_snap_time format a15 trunc    heading 'Begin Snap Time'
column end_snap_time   format a15 trunc    heading 'End Snap Time'
column ela             format 999,999,990.99 trunc    heading 'Elapsed (min)'
column up_time         format 999,999,990.99 trunc    heading 'Up time (hrs)'
column version         format a15          heading 'Release'
select di.dbid, e.instance_number, di.instance_name, di.host_name
     , to_char(e.startup_time,'DD-Mon-YY HH24:MI') startup_time
     , to_char(b.end_interval_time,'DD-Mon-YY HH24:MI') begin_snap_time
     , to_char(e.end_interval_time,'DD-Mon-YY HH24:MI') end_snap_time
     , di.version
     ,(cast(e.end_interval_time as date)-cast(b.end_interval_time as date))*24*60 ela
     ,(cast(e.end_interval_time as date)-cast(e.startup_time as date))*24 up_time
  from dba_hist_database_instance di
     , dba_hist_snapshot b
     , dba_hist_snapshot e
 where di.dbid            = b.dbid
   and di.instance_number = b.instance_number
   and di.startup_time    = b.startup_time
   and b.snap_id          = :bid
   and b.dbid             = e.dbid
   and b.instance_number  = e.instance_number
   and e.snap_id          = :eid
 order by di.dbid, e.instance_number;

--
-- Error reporting

col warning format a80 heading 'WARNING'

select 'WARNING: An instance was restarted during this interval - Data in the report is invalid' warning
  from dba_hist_snapshot b
     , dba_hist_snapshot e
 where b.snap_id          = :bid
   and b.dbid             = e.dbid
   and b.instance_number  = e.instance_number
   and e.snap_id          = :eid
   and e.startup_time    != b.startup_time;

select 'WARNING: number of instances is not equal at begin and end snap' warning  from dual
 where &bnuminst != &enuminst;


--
-- Cache Sizes

-- check logic to make sure we're getting actual sizes, even if
-- sizes change (i.e. sga_target and in 11g memory_target)
-- This needs to be modified to use memory_target
-- and v$memory_dynamic_components once AWR captures that data

column instance_number format 999          heading 'Inst #'
column sga_target  format a15 heading 'SGA Target'     just r
column db_cache    format a15 heading 'DB Cache size'  just r
column shared_pool format a15 heading 'Shared Pool'    just r
column log_buffer  format a15 heading 'Log Buffer'     just r
column pga_target  format a15 heading 'PGA Target'     just r

select e.instance_number
     , max(case when e.parameter_name = 'sga_target' and e.value > 0 and b.value > 0
            then lpad(to_char(
                    case when b.value = e.value then e.value/&btomb || 'M'
                         else b.value/&btomb || 'M/' ||e.value/&btomb ||'M'
                         end), 15)
            else null
       end) sga_target
     , max(case when e.parameter_name like '%db_cache_size'
            then lpad(to_char(
                    case when b.value = e.value then e.value/&btomb || 'M'
                         else b.value/&btomb || 'M/' ||e.value/&btomb ||'M'
                         end), 15)
       end) db_cache
     , max(case when e.parameter_name like '%shared_pool_size'
            then lpad(to_char(
                    case when b.value = e.value then e.value/&btomb || 'M'
                         else b.value/&btomb || 'M/' || e.value/&btomb ||'M'
                         end), 15)
       end) shared_pool
     , max(case when e.parameter_name like '%log_buffer'
            then lpad(to_char(
                    case when b.value = e.value then e.value/&btokb || 'K'
                         else b.value/&btokb || 'K/' || e.value/&btokb ||'K'
                         end), 15)
       end) log_buffer
     , max(case when e.parameter_name like '%pga_aggregate_target'
            then lpad(to_char(
                    case when b.value = e.value then e.value/&btomb || 'M'
                         else b.value/&btomb || 'M/' || e.value/&btomb ||'M'
                         end), 15)
       end) pga_target
  from dba_hist_parameter b
     , dba_hist_parameter e
 where e.dbid    = :dbid
   and e.snap_id = :eid
   and b.snap_id = :bid
   and b.dbid    = e.dbid
   and b.instance_number = e.instance_number
   and e.parameter_name = b.parameter_name
   and e.parameter_name in ('sga_target','db_cache_size','shared_pool_size'
                           ,'log_buffer','pga_aggregate_target'
                           , '__db_cache_size','__shared_pool_size'
                           , '__pga_aggregate_target')
 group by e.instance_number
 order by e.instance_number;



set newpage 3 termout on heading on;

ttitle lef 'OS Stat ' -
       skip 1 -
           '~~~~~~~' -
       skip 1;

break on report

compute sum of busy_time  on report;
compute sum of idle_time on report;
compute sum of total_time on report;
col num_cpus    format            999 heading 'Num|CPUs'
col load        format            a13 heading 'Load|Begin/End'
col begin_load  format          999.9 heading 'Load|Begin'
col end_load    format          999.9 heading 'Load|End'
col busy_time   format 999,999,999.99 heading 'Busy Time (s)'
col idle_time   format 999,999,999.99 heading 'Idle Time (s)'
col total_time  format 999,999,999.99 heading 'Total time (s)'
col pct_busy    format          999.9 heading '% Busy'
col pct_user    format          999.9 heading '% Usr'
col pct_sys     format          999.9 heading '% Sys'
col pct_wio     format          999.9 heading '% WIO'
col pct_idl     format          999.9 heading '% Idl'

select instance_number
     , num_cpus
     , begin_load
     , end_load
     , 100 * busy_time/(busy_time + idle_time)      pct_busy
     , 100 * user_time/(busy_time + idle_time)      pct_user
     , 100 * sys_time/(busy_time + idle_time)       pct_sys
     , 100 * wio_time/(busy_time + idle_time)       pct_wio
     , 100 * idle_time/(busy_time + idle_time)      pct_idl
     , busy_time
     , idle_time
     , busy_time + idle_time                        total_time
  from (select se.instance_number
             , max(decode(se.stat_name,'NUM_CPUS',se.value,0))         num_cpus
             , max(decode(se.stat_name,'LOAD',se.value,0))             end_load
             , max(decode(sb.stat_name,'LOAD',sb.value,0))             begin_load
             , sum(decode(se.stat_name, 'BUSY_TIME',
                           (se.value - nvl(sb.value,0))/&&cstos, 0))   busy_time
             , sum(decode(se.stat_name, 'IDLE_TIME',
                           (se.value - nvl(sb.value,0))/&&cstos, 0))   idle_time
             , sum(decode(se.stat_name, 'USER_TIME',
                           (se.value - nvl(sb.value,0))/&&cstos, 0))   user_time
             , sum(decode(se.stat_name, 'SYS_TIME',
                           (se.value - nvl(sb.value,0))/&&cstos, 0))   sys_time
             , sum(decode(se.stat_name, 'IOWAIT_TIME',
                           (se.value - nvl(sb.value,0))/&&cstos, 0))   wio_time
          from dba_hist_osstat sb
             , dba_hist_osstat se
         where se.dbid            = :dbid
           and sb.snap_id         = :bid
           and se.snap_id         = :eid
           and se.dbid            = sb.dbid
           and se.instance_number = sb.instance_number
           and se.stat_id         = sb.stat_id
         group by se.instance_number
      ) os
  order by instance_number;

clear breaks

-- ------------------------------------------------------------

set newpage 1

--
-- Time Model Stats
--

ttitle lef 'Time Model ' -
       skip 1 -
       '~~~~~~~~~~' -
       skip 1;

break on report

compute sum of db_cpu  on report;
compute sum of db_time on report;
compute sum of bg_cpu  on report;
compute sum of bg_time on report;
compute sum of sqlexec_time on report;
compute sum of parse_time on report;
compute sum of hparse_time on report;
compute sum of plsql_time on report;
compute sum of java_time on report;

col db_cpu         format 999,999,999.99 heading 'DB CPU (s)'
col db_time        format 999,999,999.99 heading 'DB time (s)'
col bg_cpu         format 999,999,999.99 heading 'bg CPU (s)'
col bg_time        format 999,999,999.99 heading 'bg time (s)'

col sqlexec_time   format 999,999,999.99 heading 'SQL Exec|Ela (s)'
col parse_time     format 999,999,999.99 heading 'Parse Ela (s)'
col hparse_time    format 999,999,999.99 heading 'Hard Parse|Ela (s)'
col plsql_time     format 999,999,999.99 heading 'PL/SQL Ela (s)'
col java_time      format 999,999,999.99 heading 'Java Ela (s)'


select se.instance_number
     , sum(decode(se.stat_name, 'DB time',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos           db_time
     , sum(decode(se.stat_name, 'DB CPU',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos            db_cpu
     , sum(decode(se.stat_name, 'sql execute elapsed time',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos      sqlexec_time
     , sum(decode(se.stat_name, 'parse time elapsed',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos        parse_time
     , sum(decode(se.stat_name, 'hard parse elapsed time',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos       hparse_time
     , sum(case when se.stat_name like '%PL/SQL%'
                then (se.value - nvl(sb.value,0))
                else 0
            end)/&&ustos                                            plsql_time
     , sum(decode(se.stat_name, 'Java execution elapsed time',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos         java_time
     , sum(decode(se.stat_name, 'background elapsed time',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos           bg_time
     , sum(decode(se.stat_name, 'background cpu time',
                   (se.value - nvl(sb.value,0)), 0))/&&ustos            bg_cpu
  from dba_hist_sys_time_model sb
     , dba_hist_sys_time_model se
 where se.dbid            = :dbid
   and sb.snap_id         = :bid
   and se.snap_id         = :eid
   and se.dbid            = sb.dbid
   and se.instance_number = sb.instance_number
   and se.stat_id         = sb.stat_id
 group by se.instance_number
 order by se.instance_number;

set newpage 1

ttitle lef 'Time Model - % of DB time' -
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 1;

col cpu_pct_dbt    format 999,999,999.99 heading 'DB CPU |%DB time'
col bg_cpu_pct_dbt format 999,999,999.99 heading 'bg CPU |%bg time'
col sql_pct_dbt    format 999,999,999.99 heading 'SQL Exec Ela|%DB time'
col parse_pct_dbt  format 999,999,999.99 heading 'Parse Ela|%DB time'
col hparse_pct_dbt format 999,999,999.99 heading 'Hard Parse|%DB time'
col plsql_pct_dbt  format 999,999,999.99 heading 'PL/SQL Ela|%DB time'
col java_pct_dbt   format 999,999,999.99 heading 'Java Ela|%DB time'
col dbt_pct_tdbt   format 999,999,999.99 heading '% Total|DB time'
col bgt_pct_tbgt   format 999,999,999.99 heading '% Total|bg time'


select instance_number
     , db_time/decode(:tdbtim,0,null,:tdbtim)*100         dbt_pct_tdbt
     , db_cpu/decode(db_time,0,null,db_time)*100          cpu_pct_dbt
     , sqlexec_time/decode(db_time,0,null,db_time)*100    sql_pct_dbt
     , parse_time/decode(db_time,0,null,db_time)*100      parse_pct_dbt
     , hparse_time/decode(db_time,0,null,db_time)*100     hparse_pct_dbt
     , plsql_time/decode(db_time,0,null,db_time)*100      plsql_pct_dbt
     , java_time/decode(db_time,0,null,db_time)*100       java_pct_dbt
     , bg_time/decode(:tbgtim,0,null,:tbgtim)*100         bgt_pct_tbgt
     , bg_cpu/decode(bg_time,0,null,bg_time)*100          bg_cpu_pct_dbt
   from (select se.instance_number
        , sum(decode(se.stat_name, 'DB time',
                      (se.value - nvl(sb.value,0)), 0))                db_time
        , sum(decode(se.stat_name, 'DB CPU',
                      (se.value - nvl(sb.value,0)), 0))                 db_cpu
        , sum(decode(se.stat_name, 'sql execute elapsed time',
                      (se.value - nvl(sb.value,0)), 0))           sqlexec_time
        , sum(decode(se.stat_name, 'parse time elapsed',
                      (se.value - nvl(sb.value,0)), 0))             parse_time
        , sum(decode(se.stat_name, 'hard parse elapsed time',
                      (se.value - nvl(sb.value,0)), 0))            hparse_time
        , sum(case when se.stat_name like '%PL/SQL%'
                   then (se.value - nvl(sb.value,0))
                   else 0
               end)/&&ustos                                         plsql_time
        , sum(decode(se.stat_name, 'Java execution elapsed time',
                      (se.value - nvl(sb.value,0)), 0))              java_time
        , sum(decode(se.stat_name, 'background elapsed time',
                      (se.value - nvl(sb.value,0)), 0))                bg_time
        , sum(decode(se.stat_name, 'background cpu time',
                      (se.value - nvl(sb.value,0)), 0))                 bg_cpu
     from dba_hist_sys_time_model sb
        , dba_hist_sys_time_model se
    where se.dbid            = :dbid
      and sb.snap_id         = :bid
      and se.snap_id         = :eid
      and se.dbid            = sb.dbid
      and se.instance_number = sb.instance_number
      and se.stat_id         = sb.stat_id
    group by se.instance_number)
  order by instance_number;


clear breaks;

-- ------------------------------------------------------------------

--
-- SysStats
--

set newpage 0

ttitle skip 1 -
       lef 'SysStat'-
       skip 1 -
           '~~~~~~~'-
       skip 2;

break on report
compute sum of slr      on report
compute sum of slr_ps   on report
compute sum of phyr     on report
compute sum of phyr_ps  on report
compute sum of phyw     on report
compute sum of phyw_ps  on report
compute sum of rdos     on report
compute sum of rdos_ps  on report
compute sum of blkc     on report
compute sum of blkc_ps  on report
compute sum of uc       on report
compute sum of uc_ps    on report
compute sum of ec       on report
compute sum of ec_ps    on report
compute sum of pc       on report
compute sum of pc_ps    on report
compute sum of lc       on report
compute sum of lc_ps    on report
compute avg of slr_pt   on report
compute avg of phyr_pt  on report
compute avg of phyw_pt  on report
compute avg of rdos_pt  on report
compute avg of blkc_pt  on report
compute avg of uc_pt    on report
compute avg of ec_pt    on report
compute avg of pc_pt    on report
compute avg of lc_pt    on report

compute sum of tx       on report
compute sum of tps      on report

col instance_number heading 'I#'           format 999
col blank     heading ''                   format a12
col blank15   heading ''                   format a15
col blank10   heading ''                   format a10
col slr       heading 'Logical|Reads'      format 99,999,999,999
col slr_ps    heading 'Logical|Reads/s'    format 999,999,999.99
col slr_pt    heading 'Logical|Reads/tx'   format 999,999,999.99
col phyr      heading 'Physical|Reads'     format    999,999,999
col phyr_ps   heading 'Physical|Reads/s'   format    9,999,999.9
col phyr_pt   heading 'Physical|Reads/tx'  format    9,999,999.9
col phyw      heading 'Physical|Writes'    format    999,999,999
col phyw_ps   heading 'Physical|Writes/s'  format    9,999,999.9
col phyw_pt   heading 'Physical|Writes/tx' format    9,999,999.9
col rdow      heading 'Redo Writes'        format    999,999,999
col rdow_ps   heading 'Redo |Wrtes/s'      format    9,999,999.9
col rdow_pt   heading 'Redo |Writes/tx'    format    9,999,999.9
col rdos      heading 'Redo|Size (k)'      format    999,999,999
col rdos_ps   heading 'Redo|Size (k)/s'    format    9,999,999.9
col rdos_pt   heading 'Redo|Size (k)/tx'   format    9,999,999.9
col blkc      heading 'Block|Changes'      format    999,999,999
col blkc_ps   heading 'Block|Changes/s'    format    9,999,999.9
col blkc_pt   heading 'Block|Changes/tx'   format    9,999,999.9
col uc        heading 'User|Calls'         format    999,999,999
col uc_ps     heading 'User|Calls/s'       format    9,999,999.9
col uc_pt     heading 'User|Calls/tx'      format    9,999,999.9
col ec        heading 'Execs'              format    999,999,999
col ec_ps     heading 'Execs/s'            format    9,999,999.9
col ec_pt     heading 'Execs/tx'           format    9,999,999.9
col pc        heading 'Parses'             format    999,999,999
col pc_ps     heading 'Parses/s'           format    9,999,999.9
col pc_pt     heading 'Parses/tx'          format    9,999,999.9
col lc        heading 'Logons'             format      9,999,999
col lc_ps     heading 'Logons/s'           format      99,999.99
col lc_pt     heading 'Logons/tx'          format      99,999.99
col s_et      heading 'Elapsed (s)'        noprint
-- col s_et      heading 'Elapsed (s)'
col tx        heading 'Txns'               format    999,999,999
col tps       heading 'Txns/s'             format    9,999,999.9

select se.instance_number
     , sum(decode(se.stat_name, 'session logical reads',  (se.value - nvl(sb.value,0)), 0))        slr
     , sum(decode(se.stat_name, 'physical reads',         (se.value - nvl(sb.value,0)), 0))        phyr
     , sum(decode(se.stat_name, 'physical writes',        (se.value - nvl(sb.value,0)), 0))        phyw
     , sum(decode(se.stat_name, 'redo size',              ((se.value - nvl(sb.value,0))/&&btokb), 0))     rdos
     , sum(decode(se.stat_name, 'db block changes',       (se.value - nvl(sb.value,0)), 0))        blkc
     , sum(decode(se.stat_name, 'user calls',             (se.value - nvl(sb.value,0)), 0))        uc
     , sum(decode(se.stat_name, 'execute count',          (se.value - nvl(sb.value,0)), 0))        ec
     , sum(decode(se.stat_name, 'parse count (total)',    (se.value - nvl(sb.value,0)), 0))        pc
     , sum(decode(se.stat_name, 'logons cumulative',      (se.value - nvl(sb.value,0)), 0))        lc
     , (sum(decode(se.stat_name, 'user commits',           (se.value - nvl(sb.value,0)), 0))
     + sum(decode(se.stat_name, 'user rollbacks',         (se.value - nvl(sb.value,0)), 0)))   tx
  from dba_hist_sysstat sb
     , dba_hist_sysstat se
 where se.dbid            = :dbid
   and sb.snap_id         = :bid
   and se.snap_id         = :eid
   and se.dbid            = sb.dbid
   and se.instance_number = sb.instance_number
   and se.stat_id         = sb.stat_id
   and se.stat_name in
         ( 'session logical reads', 'physical reads'
         , 'physical writes'
         , 'db block changes'
         , 'user calls', 'execute count', 'redo size', 'parse count (total)'
         , 'logons cumulative'
         , 'user commits','user rollbacks'
         )
 group by se.instance_number
 order by se.instance_number;

set newpage 1

ttitle lef 'SysStat per Sec '-
       skip 1 -
           '~~~~~~~~~~~~~~~' -
       skip 2;

select st.instance_number
     , slr/s_et  slr_ps
     , phyr/s_et phyr_ps
     , phyw/s_et phyw_ps
     , rdos/s_et rdos_ps
     , blkc/s_et blkc_ps
     , uc/s_et   uc_ps
     , ec/s_et   ec_ps
     , pc/s_et   pc_ps
     , lc/s_et   lc_ps
     , (ucm+ur)/s_et  tps
     , s_et
  from ( select se.instance_number
              , sum(decode(se.stat_name, 'user commits',           (se.value - nvl(sb.value,0)), 0))   ucm
              , sum(decode(se.stat_name, 'user rollbacks',         (se.value - nvl(sb.value,0)), 0))   ur
              , sum(decode(se.stat_name, 'session logical reads',  (se.value - nvl(sb.value,0)), 0))        slr
              , sum(decode(se.stat_name, 'physical reads',         (se.value - nvl(sb.value,0)), 0))        phyr
              , sum(decode(se.stat_name, 'physical writes',        (se.value - nvl(sb.value,0)), 0))        phyw
              , sum(decode(se.stat_name, 'redo size',              ((se.value - nvl(sb.value,0))/&&btokb), 0))     rdos
              , sum(decode(se.stat_name, 'db block changes',       (se.value - nvl(sb.value,0)), 0))        blkc
              , sum(decode(se.stat_name, 'user calls',             (se.value - nvl(sb.value,0)), 0))        uc
              , sum(decode(se.stat_name, 'execute count',          (se.value - nvl(sb.value,0)), 0))        ec
              , sum(decode(se.stat_name, 'parse count (total)',    (se.value - nvl(sb.value,0)), 0))        pc
              , sum(decode(se.stat_name, 'logons cumulative',      (se.value - nvl(sb.value,0)), 0))        lc
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'session logical reads', 'physical reads'
                , 'physical writes'
                , 'db block changes'
                , 'user calls', 'execute count', 'redo size', 'parse count (total)'
                , 'logons cumulative'
                , 'user commits','user rollbacks'
                )
          group by se.instance_number
       ) st
     , (select e.instance_number
              , extract(DAY     from e.end_interval_time - b.end_interval_time) * 86400
                + extract(HOUR   from e.end_interval_time - b.end_interval_time) * 3600
                + extract(MINUTE from e.end_interval_time - b.end_interval_time) * 60
                + extract(SECOND from e.end_interval_time - b.end_interval_time)                      s_et
          from dba_hist_snapshot e
             , dba_hist_snapshot b
          where e.dbid            = :dbid
            and b.snap_id         = :bid
            and e.snap_id         = :eid
            and e.dbid            = b.dbid
            and e.instance_number = b.instance_number
       ) s
 where st.instance_number = s.instance_number
 order by st.instance_number;

--
-- Per Tx

ttitle lef 'SysStat per Tx '-
       skip 1 -
           '~~~~~~~~~~~~~~' -
       skip 2;

select instance_number
     , slr/(ucm+ur)  slr_pt
     , phyr/(ucm+ur) phyr_pt
     , phyw/(ucm+ur) phyw_pt
     , rdos/(ucm+ur) rdos_pt
     , blkc/(ucm+ur) blkc_pt
     , uc/(ucm+ur)   uc_pt
     , ec/(ucm+ur)   ec_pt
     , pc/(ucm+ur)   pc_pt
     , lc/(ucm+ur)   lc_pt
  from ( select se.instance_number
              , sum(decode(se.stat_name, 'user commits',           (se.value - nvl(sb.value,0)), 0))   ucm
              , sum(decode(se.stat_name, 'user rollbacks',         (se.value - nvl(sb.value,0)), 0))   ur
              , sum(decode(se.stat_name, 'session logical reads',  (se.value - nvl(sb.value,0)), 0))   slr
              , sum(decode(se.stat_name, 'physical reads',         (se.value - nvl(sb.value,0)), 0))   phyr
              , sum(decode(se.stat_name, 'physical writes',        (se.value - nvl(sb.value,0)), 0))   phyw
              , sum(decode(se.stat_name, 'redo size',              ((se.value - nvl(sb.value,0))/&&btokb), 0))  rdos
              , sum(decode(se.stat_name, 'db block changes',       (se.value - nvl(sb.value,0)), 0))   blkc
              , sum(decode(se.stat_name, 'user calls',             (se.value - nvl(sb.value,0)), 0))   uc
              , sum(decode(se.stat_name, 'execute count',          (se.value - nvl(sb.value,0)), 0))   ec
              , sum(decode(se.stat_name, 'parse count (total)',    (se.value - nvl(sb.value,0)), 0))   pc
              , sum(decode(se.stat_name, 'logons cumulative',      (se.value - nvl(sb.value,0)), 0))   lc
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'session logical reads', 'physical reads'
                , 'physical writes'
                , 'db block changes'
                , 'user calls', 'execute count', 'redo size', 'parse count (total)'
                , 'logons cumulative'
                , 'user commits', 'user rollbacks'
                )
          group by se.instance_number
       )
  order by instance_number;

-- ------------------------------------------------------------------

set newpage 0
--
-- RAC
--

ttitle skip 1 -
       lef 'SysStat and GE Misc - RAC '-
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

compute sum of gccrr     on report
compute sum of gccrr_ps  on report
compute sum of gccrs     on report
compute sum of gccrs_ps  on report
compute sum of gccur     on report
compute sum of gccur_ps  on report
compute sum of gccus     on report
compute sum of gccus_ps  on report
compute sum of gccpu     on report
compute sum of ipccpu_ps on report
compute sum of ipccpu    on report
compute sum of gccpu_ps  on report
compute sum of gcms      on report
compute sum of gcms_ps   on report
compute sum of gems      on report
compute sum of gems_ps   on report
compute sum of mra      on report
compute sum of mra_ps   on report
compute sum of msd      on report
compute sum of msd_ps   on report
compute sum of msi      on report
compute sum of msi_ps   on report
compute sum of gcl      on report
compute sum of gcl_ps   on report
compute sum of gcf      on report
compute sum of gcf_ps   on report

compute avg of gccrr_pt  on report
compute avg of gccrs_pt  on report
compute avg of gccur_pt  on report
compute avg of gccus_pt  on report
compute avg of ipccpu_pt on report
compute avg of gccpu_pt  on report
compute avg of gcms_pt   on report
compute avg of gems_pt   on report
compute avg of mra_pt   on report
compute avg of msd_pt   on report
compute avg of msi_pt   on report
compute avg of gcl_pt   on report
compute avg of gcf_pt   on report

col gccrr     heading 'GC CR|Blocks|Received'            format     99,999,999
col gccrr_ps  heading 'GC CR|Blocks|Received/s'          format     999,999.99
col gccrs     heading 'GC CR|Blocks|Served'              format     99,999,999
col gccrs_ps  heading 'GC CR|Blocks|Served/s'            format     999,999.99
col gccur     heading 'GC Current|Blocks|Received'       format     99,999,999
col gccur_ps  heading 'GC Current|Blocks|Received/s'     format     999,999.99
col gccus     heading 'GC Current|Blocks|Served'         format     99,999,999
col gccus_ps  heading 'GC Current|Blocks|Served/s'       format     999,999.99
col gccpu     heading 'GC CPU (s)'                       format      9,999,999
col gccpu_ps  heading 'GC|CPU(s) /s'                     format      99,999.99
col ipccpu    heading 'IPC|CPU (s)'                      format      9,999,999
col ipccpu_ps heading 'IPC|CPU (s)/s'                    format      99,999.99
col gcms      heading 'GC Messages|Sent'                 format  9,999,999,999
col gcms_ps   heading 'GC Messages|Sent/s'               format  99,999,999.99
col gems      heading 'GE Messages|Sent'                 format     99,999,999
col gems_ps   heading 'GE Messages|Sent/s'               format     999,999.99
col mra       heading 'Msgs Rcvd|Actual'                 format     99,999,999
col mra_ps    heading 'Msgs Rcvd|Actual/s'               format     999,999.99
col msd       heading 'Msgs Sent|Direct'                 format     99,999,999
col msd_ps    heading 'Msgs Sent|Direct/s'               format     999,999.99
col msi       heading 'Msgs Sent|Indirect'               format     99,999,999
col msi_ps    heading 'Msgs Sent|Indirect/s'             format     999,999.99

col gcl       heading 'GC Blks|Lost'                     format       99,999
col gcl_ps    heading 'GC Blks|Lost/s'                   format        999.9
col gcf       heading 'GC CR|Failure'                    format      999,999
col gcf_ps    heading 'GC CR|Fail/s'                     format      9,999.9

col gccrr_pt  heading 'GC CR|Blocks|Received/tx'         format     999,999.99
col gccrs_pt  heading 'GC CR|Blocks|Served/tx'           format     999,999.99
col gccur_pt  heading 'GC Current|Blocks|Received/tx'    format     999,999.99
col gccus_pt  heading 'GC Current|Blocks|Served/tx'      format     999,999.99
col gccpu_pt  heading 'GC|CPU (s)/tx'                    format      99,999.99
col ipccpu_pt heading 'IPC|CPU (s)/tx'                   format      99,999.99
col gcms_pt   heading 'GC Messages|Sent/tx'              format  99,999,999.99
col gems_pt   heading 'GE Messages|Sent/tx'              format     999,999.99
col mra_pt    heading 'Msgs Rcvd|Actual/tx'              format     999,999.99
col msd_pt    heading 'Msgs Sent|Direct/tx'              format     999,999.99
col msi_pt    heading 'Msgs Sent|Indirect/tx'            format     999,999.99
col gcl_pt    heading 'GC Blks|Lost/tx'                  format          999.9
col gcf_pt    heading 'GC CR|Fail|/tx'                   format        9,999.9

/* check stat for gc current cr failure */

select ss.instance_number
     , gccur
     , gccrr
     , gccus
     , gccrs
     , gccpu
     , ipccpu
     , gcms
     , gems
     , mra
     , msd
     , msi
     , gcl
     , gcf
  from ( select se.instance_number
              , sum(decode(se.stat_name, 'gc current blocks received',  (se.value - nvl(sb.value,0)), 0))  gccur
              , sum(decode(se.stat_name, 'gc cr blocks received',  (se.value - nvl(sb.value,0)), 0))       gccrr
              , sum(decode(se.stat_name, 'gc current blocks served',    (se.value - nvl(sb.value,0)), 0))  gccus
              , sum(decode(se.stat_name, 'gc cr blocks served',    (se.value - nvl(sb.value,0)), 0))       gccrs
              , sum(decode(se.stat_name, 'gc CPU used by this session', (se.value - nvl(sb.value,0))/&&cstos, 0))  gccpu
              , sum(decode(se.stat_name, 'IPC CPU used by this session', (se.value - nvl(sb.value,0))/&&cstos, 0)) ipccpu
              , sum(decode(se.stat_name, 'gcs messages sent',  (se.value - nvl(sb.value,0)), 0))           gcms
              , sum(decode(se.stat_name, 'ges messages sent',  (se.value - nvl(sb.value,0)), 0))           gems
              , sum(decode(se.stat_name, 'gc blocks lost',  (se.value - nvl(sb.value,0)), 0))              gcl
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'gc cr blocks received','gc current blocks received'
                , 'gc cr blocks served','gc current blocks served'
                , 'gc CPU used by this session', 'IPC CPU used by this session'
                , 'gcs messages sent', 'ges messages sent'
                , 'gc blocks lost'
                )
         group by se.instance_number
       ) ss
     , ( select se.instance_number
             , sum(decode(se.name, 'messages received actual',  (se.value - nvl(sb.value,0)), 0))   mra
             , sum(decode(se.name, 'messages sent directly',    (se.value - nvl(sb.value,0)), 0))   msd
             , sum(decode(se.name, 'messages sent indirectly',  (se.value - nvl(sb.value,0)), 0))   msi
          from dba_hist_dlm_misc sb
             , dba_hist_dlm_misc se
         where se.dbid            = :dbid
           and sb.snap_id         = :bid
           and se.snap_id         = :eid
           and se.dbid            = sb.dbid
           and se.instance_number = sb.instance_number
           and se.statistic#      = sb.statistic#
           and se.name in ('messages received actual', 'messages sent directly', 'messages sent indirectly')
         group by se.instance_number
       ) dlm
     , ( select se.instance_number
              , sum(decode(se.event_name, 'gc cr failure',  (se.total_waits - nvl(sb.total_waits,0)), 0))    gcf
           from dba_hist_system_event se
              , dba_hist_system_event sb
          where se.dbid            = :dbid
            and sb.snap_id    (+)  = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid (+)
            and se.instance_number = sb.instance_number (+)
            and se.event_id        = sb.event_id (+)
            and se.event_name = 'gc cr failure'
          group by se.instance_number
        ) sw
  where dlm.instance_number = ss.instance_number
    and sw.instance_number  = ss.instance_number
  order by ss.instance_number;

set newpage 1
ttitle skip 1 -
       lef 'SysStat and GE Misc (per Sec) - RAC '-
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

select ss.instance_number
     , gccur/s_et  gccur_ps
     , gccrr/s_et  gccrr_ps
     , gccus/s_et  gccus_ps
     , gccrs/s_et  gccrs_ps
     , gccpu/s_et  gccpu_ps
     , ipccpu/s_et ipccpu_ps
     , gcms/s_et   gcms_ps
     , gems/s_et   gems_ps
     , mra/s_et    mra_ps
     , msd/s_et    msd_ps
     , msi/s_et    msi_ps
     , gcl/s_et    gcl_ps
     , gcf/s_et    gcf_ps
  from ( select se.instance_number
              , sum(decode(se.stat_name, 'gc current blocks received',  (se.value - nvl(sb.value,0)), 0))  gccur
              , sum(decode(se.stat_name, 'gc cr blocks received',  (se.value - nvl(sb.value,0)), 0))       gccrr
              , sum(decode(se.stat_name, 'gc current blocks served',  (se.value - nvl(sb.value,0)), 0))    gccus
              , sum(decode(se.stat_name, 'gc cr blocks served',    (se.value - nvl(sb.value,0)), 0))       gccrs
              , sum(decode(se.stat_name, 'gc CPU used by this session', (se.value - nvl(sb.value,0))/&&cstos, 0))  gccpu
              , sum(decode(se.stat_name, 'IPC CPU used by this session', (se.value - nvl(sb.value,0))/&&cstos, 0)) ipccpu
              , sum(decode(se.stat_name, 'gcs messages sent',  (se.value - nvl(sb.value,0)), 0))           gcms
              , sum(decode(se.stat_name, 'ges messages sent',  (se.value - nvl(sb.value,0)), 0))           gems
              , sum(decode(se.stat_name, 'gc blocks lost',  (se.value - nvl(sb.value,0)), 0))              gcl
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'gc cr blocks received','gc current blocks received'
                , 'gc cr blocks served','gc current blocks served'
                , 'gc CPU used by this session', 'IPC CPU used by this session'
                , 'gcs messages sent', 'ges messages sent'
                , 'gc blocks lost','gc current cr failure'
                )
         group by se.instance_number
       ) ss
     , ( select se.instance_number
             , sum(decode(se.name, 'messages received actual',  (se.value - nvl(sb.value,0)), 0))   mra
             , sum(decode(se.name, 'messages sent directly',    (se.value - nvl(sb.value,0)), 0))   msd
             , sum(decode(se.name, 'messages sent indirectly',  (se.value - nvl(sb.value,0)), 0))   msi
          from dba_hist_dlm_misc sb
             , dba_hist_dlm_misc se
         where se.dbid            = :dbid
           and sb.snap_id         = :bid
           and se.snap_id         = :eid
           and se.dbid            = sb.dbid
           and se.instance_number = sb.instance_number
           and se.statistic#      = sb.statistic#
           and se.name in ('messages received actual', 'messages sent directly', 'messages sent indirectly')
         group by se.instance_number
       ) dlm
     , ( select se.instance_number
              , sum(decode(se.event_name, 'gc cr failure',  (se.total_waits - nvl(sb.total_waits,0)), 0))   gcf
           from dba_hist_system_event se
              , dba_hist_system_event sb
          where se.dbid            = :dbid
            and sb.snap_id   (+)   = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid (+)
            and se.instance_number = sb.instance_number (+)
            and se.event_id        = sb.event_id (+)
            and se.event_name = 'gc cr failure'
          group by se.instance_number
        ) sw
     , (select e.instance_number
              , extract(DAY     from e.end_interval_time - b.end_interval_time) * 86400
                + extract(HOUR   from e.end_interval_time - b.end_interval_time) * 3600
                + extract(MINUTE from e.end_interval_time - b.end_interval_time) * 60
                + extract(SECOND from e.end_interval_time - b.end_interval_time)          s_et
          from dba_hist_snapshot e
             , dba_hist_snapshot b
          where e.dbid            = :dbid
            and b.snap_id         = :bid
            and e.snap_id         = :eid
            and e.dbid            = b.dbid
            and e.instance_number = b.instance_number
       ) s
 where ss.instance_number = s.instance_number
   and dlm.instance_number = ss.instance_number
   and sw.instance_number  = ss.instance_number
 order by ss.instance_number;

ttitle skip 1 -
       lef 'SysStat and GE Misc (per Tx) - RAC '-
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

select ss.instance_number
     , gccur/(ucm+ur)  gccur_pt
     , gccrr/(ucm+ur)  gccrr_pt
     , gccus/(ucm+ur)  gccus_pt
     , gccrs/(ucm+ur)  gccrs_pt
     , gccpu/(ucm+ur)  gccpu_pt
     , ipccpu/(ucm+ur) ipccpu_pt
     , gcms/(ucm+ur)   gcms_pt
     , gems/(ucm+ur)   gems_pt
     , mra/(ucm+ur)    mra_pt
     , msd/(ucm+ur)    msd_pt
     , msi/(ucm+ur)    msi_pt
     , gcl/(ucm+ur)    gcl_pt
     , gcf/(ucm+ur)    gcf_pt
  from ( select se.instance_number
              , sum(decode(se.stat_name, 'gc current blocks received',  (se.value - nvl(sb.value,0)), 0))  gccur
              , sum(decode(se.stat_name, 'gc cr blocks received',  (se.value - nvl(sb.value,0)), 0))       gccrr
              , sum(decode(se.stat_name, 'gc current blocks served',    (se.value - nvl(sb.value,0)), 0))  gccus
              , sum(decode(se.stat_name, 'gc cr blocks served',    (se.value - nvl(sb.value,0)), 0))       gccrs
              , sum(decode(se.stat_name, 'gc CPU used by this session', (se.value - nvl(sb.value,0))/&&cstos, 0))  gccpu
              , sum(decode(se.stat_name, 'IPC CPU used by this session', (se.value - nvl(sb.value,0))/&&cstos, 0)) ipccpu
              , sum(decode(se.stat_name, 'gcs messages sent',  (se.value - nvl(sb.value,0)), 0))           gcms
              , sum(decode(se.stat_name, 'ges messages sent',  (se.value - nvl(sb.value,0)), 0))           gems
              , sum(decode(se.stat_name, 'gc blocks lost',  (se.value - nvl(sb.value,0)), 0))              gcl
              , sum(decode(se.stat_name, 'user commits',           (se.value - nvl(sb.value,0)), 0))       ucm
              , sum(decode(se.stat_name, 'user rollbacks',         (se.value - nvl(sb.value,0)), 0))       ur
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'gc cr blocks received','gc current blocks received'
                , 'gc cr blocks served','gc current blocks served'
                , 'gc CPU used by this session', 'IPC CPU used by this session'
                , 'gcs messages sent', 'ges messages sent'
                , 'gc blocks lost','gc current cr failure'
                , 'user commits'     , 'user rollbacks'
                )
         group by se.instance_number
       ) ss
     , ( select se.instance_number
             , sum(decode(se.name, 'messages received actual',  (se.value - nvl(sb.value,0)), 0))   mra
             , sum(decode(se.name, 'messages sent directly',    (se.value - nvl(sb.value,0)), 0))   msd
             , sum(decode(se.name, 'messages sent indirectly',  (se.value - nvl(sb.value,0)), 0))   msi
          from dba_hist_dlm_misc sb
             , dba_hist_dlm_misc se
         where se.dbid            = :dbid
           and sb.snap_id         = :bid
           and se.snap_id         = :eid
           and se.dbid            = sb.dbid
           and se.instance_number = sb.instance_number
           and se.statistic#      = sb.statistic#
           and se.name in ('messages received actual', 'messages sent directly', 'messages sent indirectly')
         group by se.instance_number
       ) dlm
     , ( select se.instance_number
              , sum(decode(se.event_name, 'gc cr failure',  (se.total_waits - nvl(sb.total_waits,0)), 0))   gcf
           from dba_hist_system_event se
              , dba_hist_system_event sb
          where se.dbid            = :dbid
            and sb.snap_id    (+)  = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid (+)
            and se.instance_number = sb.instance_number (+)
            and se.event_id        = sb.event_id (+)
            and se.event_name = 'gc cr failure'
          group by se.instance_number
        ) sw
 where ss.instance_number = dlm.instance_number
   and sw.instance_number = ss.instance_number
 order by ss.instance_number;

clear breaks
-- ------------------------------------------------------------

--
-- GC Summaries
--

set newpage 0;

ttitle skip 1 -
       'Global Cache Efficiency Percentages' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2 -
'     +----- Buffer Access -------+' -
       skip 1;

col lc  format 999,990.99 heading 'Local %'
col rc  format 9990.99 heading 'Remote %'
col dsk format 9990.99 heading 'Disk %'

select st.instance_number
     , (100*(1-(phyrc + gccrrv + gccurv)/(cgfc+dbfc)))   lc
     , (100*(gccurv+gccrrv)/(cgfc+dbfc))                 rc
     , (100*phyrc/(cgfc+dbfc))                           dsk
  from ( select se.instance_number
              , sum(decode(se.stat_name,'gc cr blocks received'
                   , (se.value - nvl(sb.value,0)), 0 ))               gccrrv
              , sum(decode(se.stat_name,'gc current blocks received'
                   , (se.value - nvl(sb.value,0)), 0 ))               gccurv
              , sum(decode(se.stat_name,'physical reads cache'
                   , (se.value - nvl(sb.value,0)), 0 ))               phyrc
              , sum(decode(se.stat_name,'consistent gets from cache'
                   , (se.value - nvl(sb.value,0)), 0 ))               cgfc
              , sum(decode(se.stat_name,'db block gets from cache'
                   , (se.value - nvl(sb.value,0)), 0 ))               dbfc
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'gc cr blocks received', 'gc current blocks received'
                , 'physical reads cache'
                , 'consistent gets from cache', 'db block gets from cache'
                )
           group by se.instance_number) st
  order by instance_number;
 
set newpage 1

ttitle 'Global Cache and Enqueue Workload Characteristics'-
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'-
       skip 2 -
'             +--------------- CR Blocks ------------------+ +------------ Current Blocks ---------------+' -
       skip 1 -
'      GE Get |---------- Time (ms) -------------| Log Flush |---------- Time (ms) ------------| Log Flush' -
       skip 1;

col gegt    format 99990.9 heading 'Tm(ms)'
col gccrrt  format 99990.9 heading 'Receive'
col gccurt  format 99990.9 heading 'Receive'
col gccrbt  format 99990.9 heading 'Build'
col gccrst  format 99990.9 heading 'Send'
col gccrft  format 99990.9 heading 'Flush'
col gccrflp format 99990.9 heading 'CR Srvd %'
col gccupt  format 99990.9 heading 'Pin'
col gccust  format 99990.9 heading 'Send'
col gccuft  format 99990.9 heading 'Flush'
col gccuflp format 999990.9 heading 'CU Srvd%'
select st.instance_number
     , glgt*&cstoms/(glag+glsg)                  gegt
     , gccrrt*&cstoms/gccrrv                     gccrrt
     , gccrbt*&cstoms/gccrsv                     gccrbt
     , gccrst*&cstoms/gccrsv                     gccrst
     , gccrft*&cstoms/gccrfl                     gccrft
     , gccrfl/gccrsv*100                         gccrflp
     , gccurt*&cstoms/gccurv                     gccurt
     , gccupt*&cstoms/gccusv                     gccupt
     , gccust*&cstoms/gccusv                     gccust
     , gccuft*&cstoms/gccufl                     gccuft
     , gccufl/gccusv*100                         gccuflp
  from ( select se.instance_number
              , sum(decode(se.stat_name,'gc cr blocks received'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccrrv
              , sum(decode(se.stat_name,'gc cr block receive time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccrrt
              , sum(decode(se.stat_name,'gc current blocks received'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccurv
              , sum(decode(se.stat_name,'gc current block receive time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccurt
              , sum(decode(se.stat_name,'gc cr blocks served'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccrsv
              , sum(decode(se.stat_name,'gc cr block build time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccrbt
              , sum(decode(se.stat_name,'gc cr block send time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccrst
              , sum(decode(se.stat_name,'gc cr block flush time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccrft
              , sum(decode(se.stat_name,'gc current blocks served'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccusv
              , sum(decode(se.stat_name,'gc current block pin time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccupt
              , sum(decode(se.stat_name,'gc current block send time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccust
              , sum(decode(se.stat_name,'gc current block flush time'
                   , (se.value - nvl(sb.value,0)), 0 ))             gccuft
              , sum(decode(se.stat_name,'global enqueue get time'
                   , (se.value - nvl(sb.value,0)), 0 ))             glgt
              , sum(decode(se.stat_name,'global enqueue gets sync'
                   , (se.value - nvl(sb.value,0)), 0 ))             glsg
              , sum(decode(se.stat_name,'global enqueue gets async'
                   , (se.value - nvl(sb.value,0)), 0 ))             glag
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.stat_id         = sb.stat_id
            and se.stat_name in
                ( 'gc cr blocks received', 'gc cr block receive time'
                , 'gc current blocks received', 'gc current block receive time'
                , 'gc cr blocks served', 'gc cr block build time'
                , 'gc cr block flush time', 'gc cr block send time'
                , 'gc current block pin time', 'gc current blocks served'
                , 'gc current block send time', 'gc current block flush time'
                , 'global enqueue get time'
                , 'global enqueue gets sync', 'global enqueue gets async'
                )
           group by se.instance_number) st
     , ( select e.instance_number
              , sum(e.flushes - b.flushes)    gccrfl
           from dba_hist_cr_block_server b
              , dba_hist_cr_block_server e
          where b.snap_id          = :bid
            and e.snap_id          = :eid
            and e.dbid             = :dbid
            and e.dbid             = b.dbid
            and b.instance_number  = e.instance_number
          group by e.instance_number) crfl
     , ( select e.instance_number
              , sum((e.flush1+e.flush10+e.flush100+e.flush1000+e.flush10000)
                             - (b.flush1+b.flush10+b.flush100+b.flush1000+b.flush10000)) gccufl
           from dba_hist_current_block_server b
              , dba_hist_current_block_server e
           where b.snap_id          = :bid
            and e.snap_id          = :eid
            and e.dbid             = :dbid
            and e.dbid             = b.dbid
            and b.instance_number  = e.instance_number
          group by e.instance_number)     cufl
 where st.instance_number = crfl.instance_number
   and st.instance_number = cufl.instance_number
 order by instance_number;

ttitle 'Global Cache and Enqueue Messaging Statistics' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2 -
'     +---- Queue Time (ms)----+ +- Process Time-+ +---- % Messages Sent -----+'

col msgsqt  format 99990.9   heading 'Sent'
col msgsqtk format 99990.9   heading 'on ksxp'
col msgrqt  format 99990.9   heading 'Received'
col pmpt    format 99990.9   heading 'GCS msgs'
col npmpt   format 99990.9   heading 'GES msgs'
col dmsdp   format 9990.99  heading 'Direct'
col dmsip   format 9990.99  heading 'Indirect'
col dmfcp   format 9990.99  heading 'Flow Ctrl '

select st.instance_number
     , msgsqt/msgsq                 msgsqt
     , msgsqtk/msgsqk               msgsqtk
     , msgrqt/msgrq                 msgrqt
     , pmpt/pmrv                    pmpt
     , npmpt/npmrv                  npmpt
     , 100*dmsd/(dmsd+dmsi+dmfc)    dmsdp
     , 100*dmsi/(dmsd+dmsi+dmfc)    dmsip
     , 100*dmfc/(dmsd+dmsi+dmfc)    dmfcp
  from ( select se.instance_number
              , sum(decode(se.name,'msgs sent queued'
                   , (se.value - nvl(sb.value,0)), 0 ))         msgsq
              , sum(decode(se.name,'msgs sent queue time (ms)'
                   , (se.value - nvl(sb.value,0)), 0 ))         msgsqt
              , sum(decode(se.name,'msgs sent queue time on ksxp (ms)'
                   , (se.value - nvl(sb.value,0)), 0 ))         msgsqtk
              , sum(decode(se.name,'msgs sent queued on ksxp'
                   , (se.value - nvl(sb.value,0)), 0 ))         msgsqk
              , sum(decode(se.name,'msgs received queue time (ms)'
                   , (se.value - nvl(sb.value,0)), 0 ))         msgrqt
              , sum(decode(se.name,'msgs received queued'
                   , (se.value - nvl(sb.value,0)), 0 ))         msgrq
              , sum(decode(se.name,'gcs msgs received'
                   , (se.value - nvl(sb.value,0)), 0 ))         pmrv
              , sum(decode(se.name,'gcs msgs process time(ms)'
                   , (se.value - nvl(sb.value,0)), 0 ))         pmpt
              , sum(decode(se.name,'ges msgs received'
                   , (se.value - nvl(sb.value,0)), 0 ))         npmrv
              , sum(decode(se.name,'ges msgs process time(ms)'
                   , (se.value - nvl(sb.value,0)), 0 ))         npmpt
              , sum(decode(se.name,'messages sent directly'
                   , (se.value - nvl(sb.value,0)), 0 ))         dmsd
              , sum(decode(se.name,'messages sent indirectly'
                   , (se.value - nvl(sb.value,0)), 0 ))         dmsi
              , sum(decode(se.name,'messages flow controlled'
                   , (se.value - nvl(sb.value,0)), 0 ))         dmfc
           from dba_hist_dlm_misc sb
              , dba_hist_dlm_misc se
          where se.dbid            = :dbid
            and sb.snap_id         = :bid
            and se.snap_id         = :eid
            and se.dbid            = sb.dbid
            and se.instance_number = sb.instance_number
            and se.statistic#      = sb.statistic#
            and se.name            = sb.name
            and se.name in ( 'msgs sent queued', 'msgs sent queue time (ms)'
                , 'msgs sent queue time on ksxp (ms)', 'msgs sent queued on ksxp'
                , 'msgs received queue time (ms)', 'msgs received queued'
                , 'gcs msgs received', 'gcs msgs process time(ms)'
                , 'ges msgs received', 'ges msgs process time(ms)'
                , 'messages sent directly', 'messages sent indirectly'
                , 'messages flow controlled'
                )
           group by se.instance_number) st
 order by instance_number;
-- ------------------------------------------------------------------


--
--  Wait Classes
--
set newpage 0

ttitle skip 1 -
       lef 'System Wait Class '-
       skip 1 -
           '~~~~~~~~~~~~~~~~~' -
       skip 2;

break on report
compute sum of usr_io  on report;
compute sum of sys_io on report;
compute sum of other  on report;
compute sum of appl   on report;
compute sum of comm   on report;
compute sum of netw   on report;
compute sum of conc   on report;
compute sum of conf   on report;
compute sum of clu    on report;
compute sum of dbc    on report;

compute avg of usr_io_pct  on report;
compute avg of sys_io_pct on report;
compute avg of other_pct  on report;
compute avg of appl_pct   on report;
compute avg of comm_pct   on report;
compute avg of netw_pct   on report;
compute avg of conc_pct   on report;
compute avg of conf_pct   on report;
compute avg of clu_pct    on report;
compute avg of dbc_pct    on report;

col usr_io     format  9,999,999.99 heading 'User I/O(s)'
col usr_io_pct format  9,999,999.99 heading 'User I/O'
col sys_io     format  9,999,999.99 heading 'Sys I/O(s)'
col sys_io_pct format  9,999,999.99 heading 'Sys I/O'
col other      format  9,999,999.99 heading 'Other(s)'
col other_pct  format  9,999,999.99 heading 'Other'
col appl       format  9,999,999.99 heading 'Applic (s)'
col appl_pct   format  9,999,999.99 heading 'Applic'
col comm       format  9,999,999.99 heading 'Commit (s)'
col comm_pct   format  9,999,999.99 heading 'Commit'
col netw       format  9,999,999.99 heading 'Network (s)'
col netw_pct   format  9,999,999.99 heading 'Network'
col conc       format  9,999,999.99 heading 'Concurcy (s)'
col conc_pct   format  9,999,999.99 heading 'Concurcy'
col conf       format  9,999,999.99 heading 'Config (s)'
col conf_pct   format  9,999,999.99 heading 'Config'

col clu        format  9,999,999.99 heading 'Cluster (s)'
col clu_pct    format  9,999,999.99 heading 'Cluster'
col db_time    format 99,999,999.99 heading 'DB time'
col dbc        format  9,999,999.99 heading 'DB CPU (s)'
col dbc_pct    format  9,999,999.99 heading 'DB CPU'

-- col dbt noprint

select s.instance_number
     , usr_io/&ustos          usr_io
     , sys_io/&ustos          sys_io
     , other/&ustos            other
     , appl/&ustos              appl
     , comm/&ustos              comm
     , conc/&ustos              conc
     , conf/&ustos              conf
     , netw/&ustos              netw
     , clu/&ustos                clu
     , dbc/&ustos                dbc
     , dbt/&ustos            db_time
  from
   (select se.instance_number
        , sum(decode(se.wait_class, 'User I/O',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))      usr_io
        , sum(decode(se.wait_class, 'System I/O',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))      sys_io
        , sum(decode(se.wait_class, 'Other',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))       other
        , sum(decode(se.wait_class, 'Application',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))        appl
        , sum(decode(se.wait_class, 'Commit',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))        comm
        , sum(decode(se.wait_class, 'Concurrency',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))        conc
        , sum(decode(se.wait_class, 'Configuration',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))        conf
        , sum(decode(se.wait_class, 'Network',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))        netw
        , sum(decode(se.wait_class, 'Cluster',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))         clu
     from dba_hist_system_event sb
        , dba_hist_system_event se
    where se.dbid            = :dbid
      and sb.snap_id   (+)   = :bid
      and se.snap_id         = :eid
      and se.dbid            = sb.dbid (+)
      and se.instance_number = sb.instance_number
      and se.event_id        = sb.event_id (+)
      and se.total_waits     > nvl(sb.total_waits,0)
      and se.wait_class   != 'Idle'
    group by se.instance_number) s
  , (select e.instance_number
         , sum(decode(e.stat_name,'DB time' ,
                      (e.value - nvl(b.value,0)),0))              dbt
         , sum(decode(e.stat_name,'DB CPU' ,
                      (e.value - nvl(b.value,0)),0))              dbc
      from dba_hist_sys_time_model e
         , dba_hist_sys_time_model b
     where e.dbid            = :dbid
       and e.dbid            = b.dbid
       and e.instance_number = b.instance_number
       and e.snap_id         = :eid
       and b.snap_id         = :bid
       and b.stat_id         = e.stat_id
       and e.stat_name in ('DB time','DB CPU')
    group by e.instance_number) st
where s.instance_number = st.instance_number
 order by s.instance_number;

set newpage 1

ttitle skip 1 -
       lef 'System Wait Class -  % of DB time ' -
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

col db_time format 99,999,999.99 heading '% Total|DB time'
select s.instance_number
     , usr_io/decode(dbt,0,null,dbt)*100      usr_io_pct
     , sys_io/decode(dbt,0,null,dbt)*100      sys_io_pct
     , other/decode(dbt,0,null,dbt)*100        other_pct
     , appl/decode(dbt,0,null,dbt)*100          appl_pct
     , comm/decode(dbt,0,null,dbt)*100          comm_pct
     , conc/decode(dbt,0,null,dbt)*100          conc_pct
     , conf/decode(dbt,0,null,dbt)*100          conf_pct
     , netw/decode(dbt,0,null,dbt)*100          netw_pct
     , clu/decode(dbt,0,null,dbt)*100           clu_pct
     , dbc/decode(dbt,0,null,dbt)*100           dbc_pct
     , dbt/decode(:tdbtim,0,null,:tdbtim)*100   db_time
   from ( select se.instance_number
        , sum(decode(se.wait_class, 'User I/O',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))         usr_io
        , sum(decode(se.wait_class, 'System I/O',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))         sys_io
        , sum(decode(se.wait_class, 'Other',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))          other
        , sum(decode(se.wait_class, 'Application',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           appl
        , sum(decode(se.wait_class, 'Commit',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           comm
        , sum(decode(se.wait_class, 'Concurrency',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           conc
        , sum(decode(se.wait_class, 'Configuration',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           conf
        , sum(decode(se.wait_class, 'Network',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           netw
        , sum(decode(se.wait_class, 'Cluster',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))            clu
     from dba_hist_system_event sb
        , dba_hist_system_event se
    where se.dbid            = :dbid
      and sb.snap_id    (+)  = :bid
      and se.snap_id         = :eid
      and se.dbid            = sb.dbid (+)
      and se.instance_number = sb.instance_number
      and se.event_id        = sb.event_id (+)
      and se.total_waits     > nvl(sb.total_waits,0)
      and se.wait_class     != 'Idle'
    group by se.instance_number) s
  , (select e.instance_number
         , sum(decode(e.stat_name,'DB time' ,
                      (e.value - nvl(b.value,0)),0))              dbt
         , sum(decode(e.stat_name,'DB CPU' ,
                      (e.value - nvl(b.value,0)),0))              dbc
      from dba_hist_sys_time_model e
         , dba_hist_sys_time_model b
     where e.dbid            = :dbid
       and e.dbid            = b.dbid
       and e.instance_number = b.instance_number
       and e.snap_id         = :eid
       and b.snap_id         = :bid
       and b.stat_id         = e.stat_id
       and e.stat_name in ('DB time','DB CPU')
    group by e.instance_number) t
 where s.instance_number = t.instance_number
 order by s.instance_number;

clear breaks

--
-- System Wait Class as % of Total Db time

set newpage 1

ttitle skip 1 -
       lef 'System Wait Class -  % of Total DB time ' -
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

col b4 format a4 heading '    '

select '    '   b4
     , sum(usr_io)/decode(:tdbtim,0,null,:tdbtim)*100   usr_io_pct
     , sum(sys_io)/decode(:tdbtim,0,null,:tdbtim)*100   sys_io_pct
     , sum(other)/decode(:tdbtim,0,null,:tdbtim)*100    other_pct
     , sum(appl)/decode(:tdbtim,0,null,:tdbtim)*100     appl_pct
     , sum(comm)/decode(:tdbtim,0,null,:tdbtim)*100     comm_pct
     , sum(conc)/decode(:tdbtim,0,null,:tdbtim)*100     conc_pct
     , sum(conf)/decode(:tdbtim,0,null,:tdbtim)*100     conf_pct
     , sum(netw)/decode(:tdbtim,0,null,:tdbtim)*100     netw_pct
     , sum(clu)/decode(:tdbtim,0,null,:tdbtim)*100      clu_pct
     , sum(dbc)/decode(:tdbtim,0,null,:tdbtim)*100      dbc_pct
   from ( select se.instance_number
        , sum(decode(se.wait_class, 'User I/O',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))         usr_io
        , sum(decode(se.wait_class, 'System I/O',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))         sys_io
        , sum(decode(se.wait_class, 'Other',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))          other
        , sum(decode(se.wait_class, 'Application',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           appl
        , sum(decode(se.wait_class, 'Commit',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           comm
        , sum(decode(se.wait_class, 'Concurrency',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           conc
        , sum(decode(se.wait_class, 'Configuration',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           conf
        , sum(decode(se.wait_class, 'Network',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))           netw
        , sum(decode(se.wait_class, 'Cluster',
                      (se.time_waited_micro
                          - nvl(sb.time_waited_micro,0)), 0))            clu
     from dba_hist_system_event sb
        , dba_hist_system_event se
    where se.dbid            = :dbid
      and sb.snap_id    (+)  = :bid
      and se.snap_id         = :eid
      and se.dbid            = sb.dbid (+)
      and se.instance_number = sb.instance_number
      and se.event_id        = sb.event_id (+)
      and se.total_waits     > nvl(sb.total_waits,0)
      and se.wait_class     != 'Idle'
    group by se.instance_number) s
  , (select e.instance_number
         , sum(decode(e.stat_name,'DB time' ,
                      (e.value - nvl(b.value,0)),0))              dbt
         , sum(decode(e.stat_name,'DB CPU' ,
                      (e.value - nvl(b.value,0)),0))              dbc
      from dba_hist_sys_time_model e
         , dba_hist_sys_time_model b
     where e.dbid            = :dbid
       and e.dbid            = b.dbid
       and e.instance_number = b.instance_number
       and e.snap_id         = :eid
       and b.snap_id         = :bid
       and b.stat_id         = e.stat_id
       and e.stat_name in ('DB time','DB CPU')
    group by e.instance_number) t
where s.instance_number = t.instance_number;

clear breaks


-- ------------------------------------------------------------------

set newpage 0

ttitle skip 1 -
       lef 'Top Timed Events '-
       skip 1 -
           '~~~~~~~~~~~~~~~~' -
       skip 2;

break on instance_number skip 1
col nm     format a40 trunc    heading 'Event'
col wc     format a8 trunc     heading 'Wait|Class'
col twt    format    9,999,999 heading 'Waits'
col pctto  format        999.9 heading '%Time|-outs'
col tto    format    9,999,999
col ttm    format 9,999,999.99 heading 'Total Wait|Time(s)'
col rnk    format          999 noprint
col avtm   format       9999.9 heading 'Avg|Wait|(ms)'
col pctdbt format       999.99 heading '% of|DB time'

/* compute totals per instance, average wait time, and pct of db time */
select s.instance_number
     , s.wc
     , s.nm
     , s.twt
     -- , tm.dbt/&ustos
     , case when s.twt = 0 then to_number(null)
            else s.tto/s.twt*100
       end  pctto
     , ttm/&ustos   ttm
     , case when s.twt = 0 then to_number(null)
            else s.ttm/s.twt/&ustoms
       end  avtm
     , case when dbt = 0 then to_number(null)
            else s.ttm/tm.dbt*100
       end  pctdbt
     , rnk
  from (
   /* only select the top 10 events per instance */
   select * from (
      /* combine and rank the two sources - system_event and time_model */
      select instance_number
           , wc
           , nm
           , twt
           , tto
           , ttm
           , rank() over (partition by instance_number
                    order by (ttm) desc) rnk
       from (
         ( /* select events per instance */
           select e.event_name                                      nm
              ,   e.wait_class                                      wc
              , e.instance_number
              , e.total_waits - nvl(b.total_waits,0)               twt
              , e.total_timeouts - nvl(b.total_timeouts,0)         tto
              , (e.time_waited_micro - nvl(b.time_waited_micro,0)) ttm
          from dba_hist_system_event e
             , dba_hist_system_event b
          where e.snap_id = :eid
            and b.snap_id (+) = :bid
            and e.dbid    = :dbid
            and e.dbid    = b.dbid (+)
            and e.instance_number = b.instance_number (+)
            and e.event_id        = b.event_id (+)
            and e.event_name      = b.event_name (+)
            and e.wait_class     != 'Idle'
         )
         union all
         ( /* select time for DB CPU */
            select se.stat_name                                    nm
                , null                                             wc
                , se.instance_number
                , null                                            twt
                , null                                            tto
                , (se.value - nvl(sb.value,0))                    ttm
             from dba_hist_sys_time_model se
                , dba_hist_sys_time_model sb
            where se.snap_id  = :eid
              and sb.snap_id  = :bid
              and se.dbid     = :dbid
              and se.dbid     = sb.dbid
              and se.instance_number = sb.instance_number
              and se.stat_name       = 'DB CPU'
              and se.stat_name       = sb.stat_name
              and se.stat_id         = sb.stat_id
         )
      )
   )
   where rnk <= &&top_n_events) s
 , ( select se.instance_number
          , (se.value - nvl(sb.value,0))   dbt
       from dba_hist_sys_time_model se
          , dba_hist_sys_time_model sb
      where se.snap_id  = :eid
        and sb.snap_id  = :bid
        and se.dbid     = :dbid
        and se.dbid     = sb.dbid
        and se.instance_number = sb.instance_number
        and se.stat_name       = 'DB time'
        and se.stat_name       = sb.stat_name
        and se.stat_id         = sb.stat_id
    ) tm
where s.instance_number = tm.instance_number
order by instance_number,rnk;

clear breaks

 
repfooter center -
   '-------------------------------------------------------------';

--
-- SQL Reporting

-- Get the captured vs. total workload ratios

set newpage none
set heading off
set termout off
ttitle off
repfooter off

col bufcappct new_value bufcappct noprint
col getsa     new_value getsa     noprint
col phycappct new_value phycappct noprint
col phyra     new_value phyra     noprint
col execappct new_value execappct noprint
col exea      new_value exea      noprint
col prscappct new_value prscappct noprint
col prsea     new_value prsea     noprint
col cpucappct new_value cpucappct noprint
col elacappct new_value elacappct noprint
col dbcpua    new_value dbcpua    noprint
col dbcpu_s   new_value dbcpu_s   noprint
col dbtima    new_value dbtima    noprint
col dbtim_s   new_value dbtim_s   noprint
col clucappct new_value clucappct noprint
col clutm_s   new_value clutm_s   noprint


select case when :tgets = 0 then to_number(null)
            else 100*buffer_gets_delta/:tgets
       end                                            bufcappct
     , :tgets                                         getsa
     , case when :trds = 0 then to_number(null)
            else 100*disk_reads_delta/:trds
       end                                            phycappct
     , :trds                                          phyra
     , case when :texecs = 0 then to_number(null)
             else 100*executions_delta/:texecs
       end                                            execappct
     , :texecs                                        exea
     , case when :tdbcpu = 0 then to_number(null)
            else 100*cpu_time_delta/:tdbcpu
       end                                            cpucappct
     , :tdbcpu                                        dbcpua
     , :tdbcpu/&&ustos                                dbcpu_s
     , case when :tdbtim = 0 then to_number(null)
            else 100*elapsed_time_delta/:tdbtim
       end                                            elacappct
     , :tdbtim                                        dbtima
     , :tdbtim/&&ustos                                dbtim_s
     , case when :tclutm = 0 then to_number(null)
            else 100*clwait_delta/:tclutm
       end                                            clucappct
     , :tclutm/&&ustos                                clutm_s
from (
   select sum(case when st.command_type = 47 then 0
               else e.buffer_gets_delta
              end)                                    buffer_gets_delta
        , sum(case when st.command_type = 47 then 0
               else e.disk_reads_delta
              end)                                    disk_reads_delta
        , sum(e.executions_delta)                     executions_delta
        , sum(case when st.command_type = 47 then 0
                   else e.cpu_time_delta
              end)                                    cpu_time_delta
        , sum(case when st.command_type = 47 then 0
                   else e.elapsed_time_delta
              end)                                    elapsed_time_delta
        , sum(case when st.command_type = 47 then 0
                   else e.clwait_delta
              end)                                    clwait_delta
     from dba_hist_sqlstat e
        , dba_hist_sqltext st
    where e.snap_id            > :bid
      and e.snap_id           <= :eid
      and e.dbid               = :dbid
      and e.sql_id             = st.sql_id
      and e.dbid               = st.dbid);


------------------------------------------------------------

set newpage 0
set termout on;
set heading on;
repfooter center -
   '-------------------------------------------------------------';

--
-- SQL ordered by Elapsed

ttitle skip 1 -
       lef 'SQL ordered by Elapsed Time (Global)'-
       skip 1 -
       '-> Total DB time (s): ' format 99,999,999,999 dbtim_s -
       skip 1 -
       '-> Captured SQL accounts for ' format 990.9 elacappct '% of Total DB time' -
       skip 2;

break on sql_id skip 1
col sql_id       format a13           heading 'SQL Id'
col sqt          format a50  trunc    heading 'SQL Text'
col execs        format      9,999,999  heading 'Execs'
col gets         format  9,999,999,999  heading 'Gets'
col bpe          format  999,999,999.9  heading 'per Exec'
col reads        format    999,999,999  heading 'Reads'
col rpe          format    9,999,999.9  heading 'per Exec'
col rws          format    999,999,999  heading 'Rows'
col rwpe         format    9,999,999.9  heading 'per Exec'
col cpu_time     format     999,999.99  heading 'CPU (s)'
col cppe         format     999,999.99   heading 'per Exec(s)'
col elapsed_time format   9,999,999.99  heading 'Ela (s)'
col elpe         format   9,999,999.99   heading 'per Exec(s)'
col clwait_time  format     999,999.99  heading 'Clu (s)'
col clpe         format     999,999.99  heading 'per Exe(s)'

col nl           format  a13 newline  heading ''
col bp           heading ''
col ela_pct_dbt  format  9,999,999.99  heading '% of DB time'
col cpu_pct      format    999,990.99  heading '% of DB CPU'
col gets_pct     format 99,999,990.99 heading '% of Gets'
col rds_pct      format   9999,990.99  heading '% of Reads'
col execs_pct    format       9990.99  heading '% of Execs'
col clwait_pct   format    999,999.99  heading '% of CluTm'

col ep           format a10       heading ''
col sqtn         format a50 trunc heading ''

select s.sql_id
     , elapsed_time/&ustos   elapsed_time
     , cpu_time/&ustos       cpu_time
     , gets
     , reads
     , rws
     , clwait_time/&ustos    clwait_time
     , execs
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),1,50) sqt
     , '             ' nl
     , elapsed_time/&ustos/decode(execs,0,null,execs)          elpe
     , cpu_time/&ustos/decode(execs,0,null,execs)              cppe
     , gets/decode(execs,0,null,execs)                         bpe
     , reads/decode(execs,0,null,execs)                        rpe
     , rws/decode(execs,0,null,execs)                          rwpe
     , clwait_time/&ustos/decode(execs,0,null,execs)           clpe
     , '          '    ep
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),51,50)   sqtn
     , '            ' nl
     , elapsed_time/decode(:tdbtim,0,null,:tdbtim)*100         ela_pct_dbt
     -- , '                                                                ' bp
     , cpu_time/decode(:tdbcpu,0,null,:tdbcpu)*100             cpu_pct
     , gets/decode(:tgets,0,null,:tgets)*100                   gets_pct
     , reads/decode(:trds,0,null,:trds)*100                    rds_pct
     , '            '                                          bp
     , clwait_time/decode(:tclutm,0,null,:tclutm)*100          clwait_pct
     , execs/decode(:texecs,0,null,:texecs)*100                execs_pct
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),101,50)  sqtn
  from
   (select * from
      ( select sql_id
           , sum(executions_delta)      execs
           , sum(buffer_gets_delta)     gets
           , sum(disk_reads_delta)      reads
           , sum(rows_processed_delta)  rws
           , sum(cpu_time_delta)        cpu_time
           , sum(elapsed_time_delta)         elapsed_time
           , sum(clwait_delta)         clwait_time
        from dba_hist_sqlstat
       where snap_id  > :bid
         and snap_id <= :eid
         and dbid     = :dbid
       group by sql_id
       order by sum(elapsed_time_delta) desc)
    where rownum <= &&top_n_sql ) s
  , dba_hist_sqltext st
 where st.dbid = :dbid
   and st.sql_id = s.sql_id
 order by elapsed_time desc;

--
-- SQL ordered by CPU

ttitle skip 1 -
       lef 'SQL ordered by CPU Time (Global)'-
       skip 1 -
       '-> Total DB CPU (s): ' format 99,999,999,999 dbcpu_s -
       skip 1 -
       '-> Captured SQL accounts for ' format 990.9 cpucappct '% of Total DB CPU' -
       skip 2;

select s.sql_id
     , cpu_time/&ustos       cpu_time
     , elapsed_time/&ustos   elapsed_time
     , gets
     , reads
     , rws
     , clwait_time/&ustos    clwait_time
     , execs
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),1,50) sqt
     , '             ' nl
     , cpu_time/&ustos/decode(execs,0,null,execs)           cppe
     , elapsed_time/&ustos/decode(execs,0,null,execs)       elpe
     , gets/decode(execs,0,null,execs)                      bpe
     , reads/decode(execs,0,null,execs)                     rpe
     , rws/decode(execs,0,null,execs)                       rwpe
     , clwait_time/&ustos/decode(execs,0,null,execs)        clpe
     , '          '    ep
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),51,50)   sqtn
     , '            ' nl
     , cpu_time/decode(:tdbcpu,0,null,:tdbcpu)*100 cpu_pct
     -- , '                                                                  ' bp
     , elapsed_time/decode(:tdbtim,0,null,:tdbtim)*100       ela_pct_dbt
     , gets/decode(:tgets,0,null,:tgets)*100                 gets_pct
     , reads/decode(:trds,0,null,:trds)*100                  rds_pct
     , '            '                                        bp
     , clwait_time/decode(:tclutm,0,null,:tclutm)*100        clwait_pct
     , execs/decode(:texecs,0,null,:texecs)*100              execs_pct
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),101,50)  sqtn
  from
   (select * from
      ( select sql_id
           , sum(executions_delta)      execs
           , sum(buffer_gets_delta)     gets
           , sum(disk_reads_delta)      reads
           , sum(rows_processed_delta)  rws
           , sum(cpu_time_delta)        cpu_time
           , sum(elapsed_time_delta)         elapsed_time
           , sum(clwait_delta)         clwait_time
        from dba_hist_sqlstat
       where snap_id  > :bid
         and snap_id <= :eid
         and dbid     = :dbid
       group by sql_id
       order by sum(cpu_time_delta) desc)
    where rownum <= &&top_n_sql ) s
  , dba_hist_sqltext st
 where st.dbid = :dbid
   and st.sql_id = s.sql_id
 order by cpu_time desc;

--
-- SQL ordered by Gets

ttitle skip 1 -
       lef 'SQL ordered by Gets (Global)'-
       skip 1 -
       '-> Total Buffer Gets: ' format 99,999,999,999 getsa -
       skip 1 -
       '-> Captured SQL accounts for   ' format 990.9 bufcappct '% of Total Buffer Gets' -
       skip 2;

select s.sql_id
     , gets
     , reads
     , elapsed_time/&ustos   elapsed_time
     , cpu_time/&ustos       cpu_time
     , rws
     , clwait_time/&ustos    clwait_time
     , execs
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),1,50) sqt
     , '             ' nl
     , gets/decode(execs,0,null,execs)                      bpe
     , reads/decode(execs,0,null,execs)                     rpe
     , elapsed_time/&ustos/decode(execs,0,null,execs)       elpe
     , cpu_time/&ustos/decode(execs,0,null,execs)           cppe
     , rws/decode(execs,0,null,execs)                       rwpe
     , clwait_time/&ustos/decode(execs,0,null,execs)        clpe
     , '          '    ep
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),51,50)   sqtn
     , '            ' nl
     , gets/decode(:tgets,0,null,:tgets)*100                gets_pct
     -- , '                                                               ' bp
     , reads/decode(:trds,0,null,:trds)*100                 rds_pct
     , elapsed_time/decode(:tdbtim,0,null,:tdbtim)*100  ela_pct_dbt
     , cpu_time/decode(:tdbcpu,0,null,:tdbcpu)*100          cpu_pct
     , '            '                                            bp
     , clwait_time/decode(:tclutm,0,null,:tclutm)*100     clwait_pct
     , execs/decode(:texecs,0,null,:texecs)*100            execs_pct
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),101,50)  sqtn
  from
   (select * from
      ( select sql_id
           , sum(executions_delta)      execs
           , sum(buffer_gets_delta)     gets
           , sum(disk_reads_delta)      reads
           , sum(rows_processed_delta)  rws
           , sum(cpu_time_delta)        cpu_time
           , sum(elapsed_time_delta)         elapsed_time
           , sum(clwait_delta)         clwait_time
        from dba_hist_sqlstat
       where snap_id  > :bid
         and snap_id <= :eid
         and dbid     = :dbid
       group by sql_id
       order by sum(buffer_gets_delta) desc)
    where rownum <= &&top_n_sql ) s
  , dba_hist_sqltext st
 where st.dbid = :dbid
   and st.sql_id = s.sql_id
 order by gets desc;

--
-- SQL ordered by Reads

ttitle skip 1 -
       lef 'SQL ordered by Reads (Global)'-
       skip 1 -
       '-> Total Disk Reads: ' format 99,999,999,999 phyra -
       skip 1 -
       '-> Captured SQL accounts for  ' format 990.9 phycappct '% of Total Disk Reads' -
       skip 2;

select s.sql_id
     , reads
     , gets
     , elapsed_time/&ustos   elapsed_time
     , cpu_time/&ustos       cpu_time
     , rws
     , clwait_time/&ustos    clwait_time
     , execs
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),1,50) sqt
     , '             ' nl
     , reads/decode(execs,0,null,execs)                     rpe
     , gets/decode(execs,0,null,execs)                      bpe
     , elapsed_time/&ustos/decode(execs,0,null,execs)       elpe
     , cpu_time/&ustos/decode(execs,0,null,execs)           cppe
     , rws/decode(execs,0,null,execs)                       rwpe
     , clwait_time/&ustos/decode(execs,0,null,execs)        clpe
     , '          '    ep
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),51,50)   sqtn
     , '            ' nl
     , reads/decode(:trds,0,null,:trds)*100              rds_pct
     -- , '                                                                 ' bp
     , gets/decode(:tgets,0,null,:tgets)*100            gets_pct
     , elapsed_time/decode(:tdbtim,0,null,:tdbtim)*100  ela_pct_dbt
     , cpu_time/decode(:tdbcpu,0,null,:tdbcpu)*100       cpu_pct
     , '            '                                         bp
     , clwait_time/decode(:tclutm,0,null,:tclutm)*100  clwait_pct
     , execs/decode(:texecs,0,null,:texecs)*100         execs_pct
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),101,50)   sqtn
  from
   (select * from
      ( select sql_id
           , sum(executions_delta)      execs
           , sum(buffer_gets_delta)     gets
           , sum(disk_reads_delta)      reads
           , sum(rows_processed_delta)  rws
           , sum(cpu_time_delta)        cpu_time
           , sum(elapsed_time_delta)         elapsed_time
           , sum(clwait_delta)         clwait_time
        from dba_hist_sqlstat
       where snap_id  > :bid
         and snap_id <= :eid
         and dbid     = :dbid
       group by sql_id
       order by sum(disk_reads_delta) desc)
    where rownum <= &&top_n_sql ) s
  , dba_hist_sqltext st
 where st.dbid = :dbid
   and st.sql_id = s.sql_id
 order by reads desc;

--
-- SQL ordered by Cluster Time

ttitle skip 1 -
       lef 'SQL ordered by Cluster Time (Global)'-
       skip 1 -
       '-> Total Cluster Wait Time (s): ' format 99,999,999,999 clutm_s -
       skip 1 -
       '-> Captured SQL accounts for ' format 990.9 clucappct '% of Total Cluster Wait Time' -
       skip 2;

select s.sql_id
     , clwait_time/&ustos    clwait_time
     , elapsed_time/&ustos   elapsed_time
     , cpu_time/&ustos       cpu_time
     , gets
     , reads
     , rws
     , execs
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),1,50) sqt
     , '             ' nl
     , clwait_time/&ustos/decode(execs,0,null,execs)        clpe
     , elapsed_time/&ustos/decode(execs,0,null,execs)       elpe
     , cpu_time/&ustos/decode(execs,0,null,execs)           cppe
     , gets/decode(execs,0,null,execs)                      bpe
     , reads/decode(execs,0,null,execs)                     rpe
     , rws/decode(execs,0,null,execs)                       rwpe
     , '          '    ep
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),51,50)   sqtn
     , '            ' nl
     , clwait_time/decode(:tclutm,0,null,:tclutm)*100    clwait_pct
     -- , '                                                                  ' bp
     , elapsed_time/decode(:tdbtim,0,null,:tdbtim)*100  ela_pct_dbt
     , cpu_time/decode(:tdbcpu,0,null,:tdbcpu)*100          cpu_pct
     , gets/decode(:tgets,0,null,:tgets)*100               gets_pct
     , reads/decode(:trds,0,null,:trds)*100                 rds_pct
     , '            '                                            bp
     , execs/decode(:texecs,0,null,:texecs)*100           execs_pct
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),101,50)  sqtn
  from
   (select * from
      ( select sql_id
           , sum(executions_delta)      execs
           , sum(buffer_gets_delta)     gets
           , sum(disk_reads_delta)      reads
           , sum(rows_processed_delta)  rws
           , sum(cpu_time_delta)        cpu_time
           , sum(elapsed_time_delta)         elapsed_time
           , sum(clwait_delta)         clwait_time
        from dba_hist_sqlstat
       where snap_id  > :bid
         and snap_id <= :eid
         and dbid     = :dbid
       group by sql_id
       order by sum(clwait_delta) desc)
    where rownum <= &&top_n_sql ) s
  , dba_hist_sqltext st
 where st.dbid = :dbid
   and st.sql_id = s.sql_id
 order by clwait_time desc;

--
-- SQL ordered by Executions

ttitle skip 1 -
       lef 'SQL ordered by Executions (Global)'-
       skip 2;

select s.sql_id
     , execs
     , elapsed_time/&ustos   elapsed_time
     , cpu_time/&ustos       cpu_time
     , gets
     , reads
     , rws
     , clwait_time/&ustos    clwait_time
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),1,50) sqt
     , '             ' nl
     , '          '    ep
     , elapsed_time/&ustos/decode(execs,0,null,execs)       elpe
     , cpu_time/&ustos/decode(execs,0,null,execs)           cppe
     , gets/decode(execs,0,null,execs)                      bpe
     , reads/decode(execs,0,null,execs)                     rpe
     , rws/decode(execs,0,null,execs)                       rwpe
     , clwait_time/&ustos/decode(execs,0,null,execs)  clpe
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),51,50)   sqtn
     , '            ' nl
     , execs/decode(:texecs,0,null,:texecs)*100        execs_pct
     -- , '                                                                              ' bp
     , elapsed_time/decode(:tdbtim,0,null,:tdbtim)*100  ela_pct_dbt
     , cpu_time/decode(:tdbcpu,0,null,:tdbcpu)*100          cpu_pct
     , gets/decode(:tgets,0,null,:tgets)*100               gets_pct
     , reads/decode(:trds,0,null,:trds)*100                 rds_pct
     , '            '                                            bp
     , clwait_time/decode(:tclutm,0,null,:tclutm)*100    clwait_pct
     , substr(regexp_replace(st.sql_text,'(\s)+',' '),101,50)  sqtn
  from
   (select * from
      ( select sql_id
           , sum(executions_delta)      execs
           , sum(buffer_gets_delta)     gets
           , sum(disk_reads_delta)      reads
           , sum(rows_processed_delta)  rws
           , sum(cpu_time_delta)        cpu_time
           , sum(elapsed_time_delta)         elapsed_time
           , sum(clwait_delta)         clwait_time
        from dba_hist_sqlstat
       where snap_id  > :bid
         and snap_id <= :eid
         and dbid     = :dbid
       group by sql_id
       order by sum(executions_delta) desc)
    where rownum <= &&top_n_sql ) s
  , dba_hist_sqltext st
 where st.dbid = :dbid
   and st.sql_id = s.sql_id
 order by execs desc;

clear breaks

--
-- Segment Statistics
--
-- review use of pivot/unpivot syntax in 11g

ttitle skip 1 -
       lef 'Segment Statistics (Global)'-
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 1 -
       lef '-> % Total shows % of statistic for each segment compared to the global system total ' -
       skip 1 -
       lef '   (logical reads, physical reads, gc [cr|cu] blocks [recv|serv])' -
       skip 1 -
       lef '-> % Capture shows % of statistic for each segment compared to the total captured ' -
       skip 1 -
       lef '   by AWR for all segments during the snapshot interval' -
       skip 2 ;

break on statistic_name skip 1

column owner           heading 'Owner'           format a10 trunc
column statistic_name  heading 'Statistic'       format a22
column tablespace_name heading 'Tablespace|Name' format a10 trunc
column object_type     heading 'Obj.|Type'       format a5 trunc
column object_name     heading 'Object|Name'     format a20 trunc
column subobject_name  heading 'Subobject|Name'  format a10 trunc
column value           heading 'Value'           format 999,999,999
column ratio           heading '%Capture' format 999.9
column pct             heading '%Total'   format 999.9
column rnk             format 999 noprint


select ss.stat_name                                            statistic_name
     , n.owner
     , n.tablespace_name
     , n.object_name
     , case when length(n.subobject_name) < 11
            then n.subobject_name
            else substr(n.subobject_name,length(n.subobject_name)-9)
       end                                                     subobject_name
     , n.object_type
     , value
     , case when stat_name = 'logical reads'         then value/:tgets*100
            when stat_name = 'physical reads'        then value/:trds*100
            when stat_name = 'gc cr blocks received' then value/:tgccrr*100
            when stat_name = 'gc cu blocks received' then value/:tgccur*100
            when stat_name = 'gc cr blocks served'   then value/:tgccrs*100
            when stat_name = 'gc cu blocks served'   then value/:tgccus*100
            else null
       end                                                                pct
     , (ratio_to_report(value) over (partition by stat_name))*100       ratio
     , rnk
  from ( /* now unpivot the result set for display purposes */
      select dataobj#
           , obj#
           , dbid
           , stat_name
           , case when stat_name = 'logical reads'          then lr
                  when stat_name = 'buffer busy waits'      then bbw
                  when stat_name = 'db block changes'       then dbc
                  when stat_name = 'physical reads'         then pr
                  when stat_name = 'physical writes'        then pw
                  when stat_name = 'physical reads direct'  then prd
                  when stat_name = 'physical writes direct' then pwd
                  when stat_name = 'ITL waits'              then iw
                  when stat_name = 'row lock waits'         then rlw
                  when stat_name = 'gc cr blocks served'    then gcrs
                  when stat_name = 'gc cu blocks served'    then gcus
                  when stat_name = 'gc buffer busy'         then gbb
                  when stat_name = 'gc cr blocks received'  then gcrr
                  when stat_name = 'gc cu blocks received'  then gcur
                  when stat_name = 'table scans'            then ts
                  else 0
             end  value
           , case when stat_name = 'logical reads'          then rnk_lr
                  when stat_name = 'buffer busy waits'      then rnk_bbw
                  when stat_name = 'db block changes'       then rnk_dbc
                  when stat_name = 'physical reads'         then rnk_pr
                  when stat_name = 'physical writes'        then rnk_pw
                  when stat_name = 'physical reads direct'  then rnk_prd
                  when stat_name = 'physical writes direct' then rnk_pwd
                  when stat_name = 'ITL waits'              then rnk_iw
                  when stat_name = 'row lock waits'         then rnk_rlw
                  when stat_name = 'gc cr blocks served'    then rnk_gcrs
                  when stat_name = 'gc cu blocks served'    then rnk_gcus
                  when stat_name = 'gc buffer busy'         then rnk_gbb
                  when stat_name = 'gc cr blocks received'  then rnk_gcrr
                  when stat_name = 'gc cu blocks received'  then rnk_gcur
                  when stat_name = 'table scans'            then rnk_ts
                  else 0
             end  rnk
        from ( /* select top n for each statistic */
             select * from
                (/* select objects and rank per statistic*/
                select e.dataobj#
                     , e.obj#
                     , e.dbid
                     , sum(logical_reads_delta)          lr
                     , sum(buffer_busy_waits_delta)      bbw
                     , sum(db_block_changes_delta)       dbc
                     , sum(physical_reads_delta)         pr
                     , sum(physical_writes_delta)        pw
                     , sum(physical_reads_direct_delta)  prd
                     , sum(physical_writes_direct_delta) pwd
                     , sum(itl_waits_delta)              iw
                     , sum(row_lock_waits_delta)         rlw
                     , sum(gc_cr_blocks_served_delta)    gcrs
                     , sum(gc_cu_blocks_served_delta)    gcus
                     , sum(gc_buffer_busy_delta)         gbb
                     , sum(gc_cr_blocks_received_delta)  gcrr
                     , sum(gc_cu_blocks_received_delta)  gcur
                     , sum(table_scans_delta)            ts
                     , rank () over (order by
                          sum(logical_reads_delta)     desc)         rnk_lr
                     , rank () over (order by
                          sum(buffer_busy_waits_delta) desc)        rnk_bbw
                     , rank () over (order by
                          sum(db_block_changes_delta)  desc)        rnk_dbc
                     , rank () over (order by
                          sum(physical_reads_delta)    desc)         rnk_pr
                     , rank () over (order by
                          sum(physical_writes_delta)   desc)         rnk_pw
                     , rank () over (order by
                          sum(physical_reads_direct_delta)  desc)   rnk_prd
                     , rank () over (order by
                          sum(physical_writes_direct_delta) desc)   rnk_pwd
                     , rank () over (order by
                          sum(itl_waits_delta)         desc)         rnk_iw
                     , rank () over (order by
                          sum(row_lock_waits_delta)    desc)        rnk_rlw
                     , rank () over (order by
                          sum(gc_cr_blocks_served_delta) desc)     rnk_gcrs
                     , rank () over (order by
                          sum(gc_cu_blocks_served_delta) desc)     rnk_gcus
                     , rank () over (order by
                          sum(gc_buffer_busy_delta)      desc)      rnk_gbb
                     , rank () over (order by
                          sum(gc_cr_blocks_received_delta) desc)   rnk_gcrr
                     , rank () over (order by
                          sum(gc_cu_blocks_received_delta) desc)   rnk_gcur
                     , rank () over (order by
                          sum(table_scans_delta)         desc)       rnk_ts
                 from dba_hist_seg_stat  e
                where e.dbid    = :dbid
                  and snap_id   > :bid
                  and snap_id   <= :eid
                group by e.dataobj#, e.obj#, e.dbid
               )
             where rnk_lr   <= &top_n_segstat
                or rnk_bbw  <= &top_n_segstat
                or rnk_dbc  <= &top_n_segstat
                or rnk_pr   <= &top_n_segstat
                or rnk_pw   <= &top_n_segstat
                or rnk_prd  <= &top_n_segstat
                or rnk_pwd  <= &top_n_segstat
                or rnk_iw   <= &top_n_segstat
                or rnk_rlw  <= &top_n_segstat
                or rnk_gcrs <= &top_n_segstat
                or rnk_gcus <= &top_n_segstat
                or rnk_gbb  <= &top_n_segstat
                or rnk_gcrr <= &top_n_segstat
                or rnk_gcur <= &top_n_segstat
                or rnk_ts   <= &top_n_segstat
             )  r
           , ( /* used to generate cartesian join for unpivot */
              select 'logical reads'          stat_name from dual union all
              select 'buffer busy waits'      stat_name from dual union all
              select 'db block changes'       stat_name from dual union all
              select 'physical reads'         stat_name from dual union all
              select 'physical writes'        stat_name from dual union all
              select 'physical reads direct'  stat_name from dual union all
              select 'physical writes direct' stat_name from dual union all
              select 'ITL waits'              stat_name from dual union all
              select 'row lock waits'         stat_name from dual union all
              select 'gc cr blocks served'    stat_name from dual union all
              select 'gc cu blocks served'    stat_name from dual union all
              select 'gc buffer busy'         stat_name from dual union all
              select 'gc cr blocks received'  stat_name from dual union all
              select 'gc cu blocks received'  stat_name from dual union all
              select 'table scans'            stat_name from dual
            ) d
      ) ss
   , dba_hist_seg_stat_obj n
 where ss.dataobj# = n.dataobj#
   and ss.obj#     = n.obj#
   and ss.dbid     = n.dbid
   and ss.rnk     <= &top_n_segstat
   and value       > 0
order by stat_name, value desc;

clear breaks

--
-- SysStat Section

ttitle skip 1 -
       lef 'SysStat (Global) '-
       skip 1 -
           '~~~~~~~~~~~~~~~~' -
       skip 2;

column st  format a64                  heading 'Statistic' trunc;
column dif format 9,999,999,999,990    heading 'Total';
column ps  format       999,999,990.9  heading 'per Second';
column pt  format         9,999,990.9  heading 'per Trans';

select ss.stat_name              st
     , sum(ss.dif)               dif
     , sum(ss.dif/s_et)          ps
     , sum(ss.dif)/(:tucm+:tur)  pt
  from
   ( select se.stat_name
        , se.instance_number
        , sum(se.value - nvl(sb.value,0))          dif
     from dba_hist_sysstat se
        , dba_hist_sysstat sb
    where se.dbid            = :dbid
      and sb.snap_id (+)     = :bid
      and se.snap_id         = :eid
      and se.dbid            = sb.dbid (+)
      and se.instance_number = sb.instance_number (+)
      and se.stat_id         = sb.stat_id (+)
      and se.value           > nvl(sb.value,0)
      and se.stat_name  not in ('logons current'
                              , 'opened cursors current'
                              , 'workarea memory allocated'
                              , 'session cursor cache count'
                              , 'session pga memory'
                              , 'session pga memory max'
                              , 'session uga memory'
                              , 'session uga memory max'
                             )
    group by se.stat_name, se.instance_number) ss
  , (select e.instance_number
        , extract(DAY    from e.end_interval_time - b.end_interval_time) * 86400
        + extract(HOUR   from e.end_interval_time - b.end_interval_time) * 3600
        + extract(MINUTE from e.end_interval_time - b.end_interval_time) * 60
        + extract(SECOND from e.end_interval_time - b.end_interval_time)  s_et
       from dba_hist_snapshot e
          , dba_hist_snapshot b
      where e.dbid            = :dbid
        and b.snap_id         = :bid
        and e.snap_id         = :eid
        and e.dbid            = b.dbid
        and e.instance_number = b.instance_number
    ) s
 where ss.instance_number = s.instance_number
 group by ss.stat_name
 order by ss.stat_name;



--
-- Misc GES RAC Statistics

ttitle skip 1 -
       lef 'Global Enqueue Statistics (Global) '-
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

column st  format a64                  heading 'Statistic' trunc;
column dif format 9,999,999,999,990    heading 'Total';
column ps  format       999,999,990.9  heading 'per Second';
column pt  format         9,999,990.9  heading 'per Trans';

select ss.name                   st
     , sum(ss.dif)               dif
     , sum(ss.dif/s_et)          ps
     , sum(ss.dif)/(:tucm+:tur)  pt
  from
   ( select se.name
        , se.instance_number
        , sum(se.value - nvl(sb.value,0))          dif
     from dba_hist_dlm_misc se
        , dba_hist_dlm_misc sb
    where se.dbid            = :dbid
      and sb.snap_id (+)     = :bid
      and se.snap_id         = :eid
      and se.dbid            = sb.dbid (+)
      and se.instance_number = sb.instance_number (+)
      and se.statistic#      = sb.statistic# (+)
      and se.name            = sb.name (+)
      and se.value           > nvl(sb.value,0)
    group by se.name, se.instance_number) ss
  , (select e.instance_number
        , extract(DAY    from e.end_interval_time - b.end_interval_time) * 86400
        + extract(HOUR   from e.end_interval_time - b.end_interval_time) * 3600
        + extract(MINUTE from e.end_interval_time - b.end_interval_time) * 60
        + extract(SECOND from e.end_interval_time - b.end_interval_time)  s_et
       from dba_hist_snapshot e
          , dba_hist_snapshot b
      where e.dbid            = :dbid
        and b.snap_id         = :bid
        and e.snap_id         = :eid
        and e.dbid            = b.dbid
        and e.instance_number = b.instance_number
    ) s
 where ss.instance_number = s.instance_number
 group by ss.name
 order by ss.name;
 
clear breaks

-- ------------------------------------------------------------------

set newpage 0;

ttitle skip 1 -
       lef 'SysStat (Absolute Values) '-
       skip 1 -
           '~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2 -
       '     +--- Sessions --+ +------ Open Cursors -----+ +- Session Cached Cursors -+'

break on report;
compute sum of blc   on report
compute sum of elc   on report
compute sum of bocc  on report
compute sum of eocc  on report
compute sum of bsccc on report
compute sum of esccc on report

col blc    format       999,999 heading 'Begin'
col elc    format       999,999 heading 'End'
col bocc   format 9,999,999,999 heading 'Begin'
col eocc   format   999,999,999 heading 'End'
col bsccc  format 9,999,999,999 heading 'Begin'
col esccc  format   999,999,999 heading 'End'

select se.instance_number
     , sum(case when se.stat_name = 'logons current'
            then sb.value
            else 0
       end)  blc
     , sum(case when se.stat_name = 'logons current'
            then se.value
            else 0
       end)  elc
     , sum(case when se.stat_name = 'opened cursors current'
            then sb.value
            else 0
       end)  bocc
     , sum(case when se.stat_name = 'opened cursors current'
            then se.value
            else 0
       end)  eocc
     , sum(case when se.stat_name = 'session cursor cache count'
            then sb.value
            else 0
       end)  bsccc
     , sum(case when se.stat_name = 'session cursor cache count'
            then se.value
            else 0
       end)  esccc
  from dba_hist_sysstat se
     , dba_hist_sysstat sb
 where se.dbid          = :dbid
 and sb.snap_id (+)     = :bid
 and se.snap_id         = :eid
 and se.dbid            = sb.dbid (+)
 and se.instance_number = sb.instance_number (+)
 and se.stat_id         = sb.stat_id (+)
 and se.stat_name  in ('logons current'
                     , 'opened cursors current'
                     , 'session cursor cache count'
                      )
 group by se.instance_number
 order by se.instance_number;
 
clear breaks

-- ------------------------------------------------------------------

set newpage 2;
--
-- PGA

ttitle 'PGA Aggregate Target Statistics' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 1 -
       '-> all stats are reported in Mb' -
       skip 2 -
       '     +- PGA Aggr Target -+ +-- Auto PGA Target --+ +--- PGA Mem Alloc ---+ +--- Auto Workareas --+ +-- Manual Workarea --+ +-- Global Mem Bound --+'
 
col baptp  format   999,990.9 heading 'Begin'
col eaptp  format   999,990.9 heading 'End'
col bapat  format 9,999,990.9 heading 'Begin'
col eapat  format   999,990.9 heading 'End'
col btpa   format 9,999,990.9 heading 'Begin'
col etpa   format   999,990.9 heading 'End'
col btpuaw format 9,999,990.9 heading 'Begin'
col etpuaw format   999,990.9 heading 'End'
col btpumw format 9,999,990.9 heading 'Begin'
col etpumw format   999,990.9 heading 'End'
col bgmb   format 9,999,990.9 heading 'Begin'
col egmb   format   999,990.9 heading 'End'

select se.instance_number
     , sum(case when se.name='aggregate PGA target parameter'
                then sb.value
                else 0
           end)/&&btomb baptp
     , sum(case when se.name='aggregate PGA target parameter'
                then se.value
                else 0
           end)/&&btomb eaptp
     , sum(case when se.name='aggregate PGA auto target'
                then sb.value
                else 0
           end)/&&btomb bapat
     , sum(case when se.name='aggregate PGA auto target'
                then se.value
                else 0
           end)/&&btomb eapat
     , sum(case when se.name='total PGA allocated'
                then sb.value
                else 0
           end)/&&btomb btpa
     , sum(case when se.name='total PGA allocated'
                then se.value
                else 0
           end)/&&btomb etpa
     , sum(case when se.name='total PGA used for auto workareas'
                then sb.value
                else 0
           end)/&&btomb btpuaw
     , sum(case when se.name='total PGA used for auto workareas'
                then se.value
                else 0
           end)/&&btomb etpuaw
     , sum(case when se.name='total PGA used for manual workareas'
                then sb.value
                else 0
           end)/&&btomb btpumw
     , sum(case when se.name='total PGA used for manual workareas'
                then se.value
                else 0
           end)/&&btomb etpumw
     , sum(case when se.name='global memory bound'
                then sb.value
                else 0
           end)/&&btomb bgmb
     , sum(case when se.name='global memory bound'
                then se.value
                else 0
           end)/&&btomb egmb
  from dba_hist_pgastat sb
     , dba_hist_pgastat se
 where sb.snap_id  = :bid
   and se.snap_id  = :eid
   and se.dbid     = :dbid
   and se.dbid     = sb.dbid
   and se.instance_number = sb.instance_number
   and se.name     = sb.name
 group by se.instance_number
 order by se.instance_number;
 
clear breaks

-- ------------------------------------------------------------------

ttitle 'Process Memory Summary' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~' -
       skip 1 -
       '-> Max Alloc is Maximum PGA allocation size at snapshot time' -
       skip 1 -
       '-> Hist Alloc is the Historical Maximum Allocation for still-connected processes' -
       skip 1 -
       '-> Num Procs or Allocs: For Begin/End snapshot lines, it is the number of processes ' -
       skip 1 -
       '   For Category lines, it is the number of allocations' -
       skip 1 -
       '-> Allocation sizes are displayed in Mb' -
       skip 1 -
       '-> ordered by instance, Allocated Total (End) desc' -
       skip 2 -
'                +---- Allocated --+ +----- Used ------+ +--- Avg Alloc ---+ +--- Std Dev ---+ +--- Max Alloc ---+ +---- Hist Max ---+ +- Num Procs -+ +- Num Allocs +'

break on instance_number
col category format         a10 heading 'Category'
col bat      format    99,990.9 heading 'Begin'
col eat      format    99,990.9 heading 'End'
col but      format    99,990.9 heading 'Begin'
col eut      format    99,990.9 heading 'End'
col baa      format    99,990.9 heading 'Begin'
col eaa      format    99,990.9 heading 'End'
col bas      format     9,990.9 heading 'Begin'
col eas      format     9,990.9 heading 'End'
col bam      format    99,990.9 heading 'Begin'
col eam      format    99,990.9 heading 'End'
col bmam     format    99,990.9 heading 'Begin'
col emam     format    99,990.9 heading 'End'
col bnp      format      99,999 heading 'Begin'
col enp      format      99,999 heading 'End'
col bnza     format      99,999 heading 'Begin'
col enza     format      99,999 heading 'End'

select se.instance_number
     , se.category
     , sum(sb.allocated_total)/&&btomb bat
     , sum(se.allocated_total)/&&btomb eat
     , sum(sb.used_total)/&&btomb      but
     , sum(se.used_total)/&&btomb      eut
     , sum(sb.allocated_avg)/&&btomb   baa
     , sum(se.allocated_avg)/&&btomb   eaa
     , sum(sb.allocated_stddev)/&&btomb bas
     , sum(se.allocated_stddev)/&&btomb eas
     , sum(sb.allocated_max)/&&btomb    bam
     , sum(se.allocated_max)/&&btomb    eam
     , sum(sb.max_allocated_max)/&&btomb bmam
     , sum(se.max_allocated_max)/&&btomb emam
     , sum(sb.num_processes)               bnp
     , sum(se.num_processes)               enp
     , sum(sb.non_zero_allocs)             bnza
     , sum(se.non_zero_allocs)             enza
  from dba_hist_process_mem_summary sb
     , dba_hist_process_mem_summary se
 where sb.snap_id = :bid
   and se.snap_id = :eid
   and se.dbid    = :dbid
   and se.dbid    = sb.dbid
   and se.instance_number = sb.instance_number
   and se.category = sb.category
group by se.instance_number,se.category
order by se.instance_number,sum(se.allocated_total)/&&btomb desc;

clear breaks

-- ------------------------------------------------------------------

set newpage 0;
--
-- CR Server

repfooter off

ttitle skip 1 -
       'CR Blocks Served Statistics' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;

break on report

compute sum of gccr on report
compute sum of gccu on report
compute sum of dr   on report
compute sum of ur   on report
compute sum of tr   on report
compute sum of cr   on report
compute sum of pr   on report
compute sum of zr   on report
compute sum of drr  on report
compute sum of fr   on report
compute sum of fdc  on report
compute sum of fc   on report
compute sum of fge  on report
compute sum of fls  on report
compute sum of fq   on report
compute sum of fqf  on report
compute sum of fmt  on report
compute sum of lw   on report
compute sum of er   on report

col gccr format 99,999,999 heading 'CR Block|Requests'
col gccu format 99,999,999 heading 'CU Block|Requests'
col dr   format 99,999,999 heading 'Data Block|Requests'
col ur   format    999,999 heading 'Undo|Requests'
col tr   format 99,999,999 heading 'TX Block|Requests'
col cr   format 99,999,999 heading 'Current|Results'
col pr   format     99,999 heading 'Priv|Res'
col zr   format  9,999,999 heading 'Zero|Results'
col drr  format     99,999 heading 'Dsk Rd|Res'
col fr   format     99,999 heading 'Fail|Res'
col fdc  format  9,999,999 heading 'Fairness|Down Conv'
col fc   format    999,999 heading 'Fairness|Clears'
col fge  format    999,999 heading 'FreeGC|Elems'
col fls  format  9,999,999 heading 'Flushes'
col fq   format     99,999 heading 'Flush|Queued'
col fqf  format      9,999 heading 'Flush|QFull'
col fmt  format      9,999 heading 'Flush|MaxTm'
col lw   format    999,999 heading 'Light|Works'
col er   format        999 heading 'Errs'

select e.instance_number
     , sum(e.cr_requests - b.cr_requests)            gccr
     , sum(e.current_requests - b.current_requests)  gccu
     , sum(e.data_requests - b.data_requests)  dr
     , sum(e.undo_requests - b.undo_requests)  ur
     , sum(e.tx_requests   - b.tx_requests)    tr
     , sum(e.current_results - b.current_results) cr
     , sum(e.private_results - b.private_results) pr
     , sum(e.zero_results    - b.zero_results)    zr
     , sum(e.disk_read_results - b.disk_read_results) drr
     , sum(e.fail_results    - b.fail_results)    fr
     , sum(e.fairness_down_converts - b.fairness_down_converts) fdc
     , sum(e.fairness_clears - b.fairness_clears) fc
     , sum(e.free_gc_elements - b.free_gc_elements) fge
     , sum(e.flushes - b.flushes)    fls
     , sum(e.flushes_queued - b.flushes_queued) fq
     , sum(e.flush_queue_full - b.flush_queue_full) fqf
     , sum(e.flush_max_time   - b.flush_max_time)   fmt
     , sum(e.light_works      - b.light_works)      lw
     , sum(e.errors           - b.errors)           er
  from dba_hist_cr_block_server b
     , dba_hist_cr_block_server e
 where b.snap_id          = :bid
   and e.snap_id          = :eid
   and e.dbid             = :dbid
   and e.dbid             = b.dbid
   and b.instance_number  = e.instance_number
 group by e.instance_number;


--
-- Current Block Server

set newpage 1

ttitle skip 1 -
       'Current Blocks Served Statistics' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 2;


break on report
compute  sum of pins    on report
compute  sum of flushes on report
compute  sum of writes  on report

col pins       heading Pins       format 99,999,999
col flushes    heading Flushes    format 99,999,999
col writes     heading Writes     format 99,999,999
col pin1       heading '% <1ms'   format 990.99
col pin10      heading '% <10ms'  format 990.99
col pin100     heading '% <100ms' format 990.99
col pin1000    heading '% <1s'    format 990.99
col pin10000   heading '% <10s'   format 990.99
col flush1     heading '% <1ms'   format 990.99
col flush10    heading '% <10ms'  format 990.99
col flush100   heading '% <100ms' format 990.99
col flush1000  heading '% <1s'    format 990.99
col flush10000 heading '% <10s'   format 990.99
col write1     heading '% <1ms'   format 990.99
col write10    heading '% <10ms'  format 990.99
col write100   heading '% <100ms' format 990.99
col write1000  heading '% <1s'    format 990.99
col write10000 heading '% <10s'   format 990.99
select instance_number
     , pins
     , pin1/pins*100         pin1
     , pin10/pins*100        pin10
     , pin100/pins*100       pin100
     , pin1000/pins*100      pin1000
     , pin10000/pins*100     pin10000
     , flushes
     , flush1/flushes*100     flush1
     , flush10/flushes*100    flush10
     , flush100/flushes*100   flush100
     , flush1000/flushes*100  flush1000
     , flush10000/flushes*100 flush10000
     , writes
     , write1/writes*100      write1
     , write10/writes*100     write10
     , write100/writes*100    write100
     , write1000/writes*100   write1000
     , write10000/writes*100  write10000
  from (
   select e.instance_number
        , sum((e.pin1 + e.pin10 + e.pin100 + e.pin1000 + e.pin10000) -
              (b.pin1 + b.pin10 + b.pin100 + b.pin1000 + b.pin10000))   pins
        , sum(e.pin1     - b.pin1)                                  pin1
        , sum(e.pin10    - b.pin10)                                 pin10
        , sum(e.pin100   - b.pin100)                                pin100
        , sum(e.pin1000  - b.pin1000)                               pin1000
        , sum(e.pin10000 - b.pin10000)                              pin10000
        , sum((e.flush1 + e.flush10 + e.flush100 + e.flush1000 + e.flush10000) -
              (b.flush1 + b.flush10 + b.flush100 + b.flush1000 + b.flush10000))   flushes
        , sum(e.flush1     - b.flush1)                              flush1
        , sum(e.flush10    - b.flush10)                             flush10
        , sum(e.flush100   - b.flush100)                            flush100
        , sum(e.flush1000  - b.flush1000)                           flush1000
        , sum(e.flush10000 - b.flush10000)                          flush10000
        , sum((e.write1 + e.write10 + e.write100 + e.write1000 + e.write10000) -
              (b.write1 + b.write10 + b.write100 + b.write1000 + b.write10000))   writes
        , sum(e.write1     - b.write1)                              write1
        , sum(e.write10    - b.write10)                             write10
        , sum(e.write100   - b.write100)                            write100
        , sum(e.write1000  - b.write1000)                           write1000
        , sum(e.write10000 - b.write10000)                          write10000
     from dba_hist_current_block_server b
        , dba_hist_current_block_server e
    where b.snap_id = :bid
      and e.snap_id = :eid
      and e.dbid             = :dbid
      and e.dbid             = b.dbid
      and b.instance_number  = e.instance_number
    group by e.instance_number)
order by instance_number;

clear breaks

-- ------------------------------------------------------------------


ttitle 'Global Cache Transfer Stats  '-
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~~~~~~~~~' -
       skip 1 -
       '-> Immediate  (Immed) - Block Transfer NOT impacted by Remote Processing Delays' -
       skip 1 -
       '   Busy        (Busy) - Block Transfer impacted by Remote Contention' -
       skip 1 -
       '   Congested (Congst) - Block Transfer impacted by Remote System Load' -
       skip 1 -
           '-> ordered by instance_number, CR + Current Blocks Received desc' -
       skip 2 -
           '                        -------------- CR -------------  ----------- Current -----------';

break on instance_number

column inst     format 990         heading 'Src|Inst#'
column class    format a12         heading 'Block|Class' trunc
column totcr    format 99,999,990  heading 'Blocks|Received'
column totcu    format 99,999,990  heading 'Blocks|Received'
column blkimm   format 999.9       heading '%|Immed'
column blkbus   format 999.9       heading '%|Busy'
column blkcgt   format 999.9       heading '%|Congst'

select  instance_number
     , instance       inst
     , class          class
     , totcr
     , decode(totcr,0, to_number(NULL),cr_block/totcr*100)          blkimm
     , decode(totcr,0, to_number(NULL),cr_busy/totcr*100)           blkbus
     , decode(totcr,0, to_number(NULL),cr_congested/totcr*100)      blkcgt
     , totcu
     , decode(totcu,0, to_number(NULL),current_block/totcu*100)     blkimm
     , decode(totcu,0, to_number(NULL),current_busy/totcu*100)      blkbus
     , decode(totcu,0, to_number(NULL),current_congested/totcu*100) blkcgt
   from (select e.instance_number
        , e.instance
        , case when e.class in ('data block','undo header','undo block')
               then e.class
               else 'others'
           end       class
        , sum(e.cr_block - nvl(b.cr_block,0))                cr_block
        , sum(e.cr_busy - nvl(b.cr_busy,0))                  cr_busy
        , sum(e.cr_congested - nvl(b.cr_congested,0))        cr_congested
        , sum(e.current_block - nvl(b.current_block,0))      current_block
        , sum(e.current_busy - nvl(b.current_busy,0))        current_busy
        , sum(e.current_congested - nvl(b.current_congested,0)) current_congested
        , sum(e.cr_block - nvl(b.cr_block,0))
            + sum(e.cr_busy - nvl(b.cr_busy,0))
            + sum(e.cr_congested - nvl(b.cr_congested,0))           totcr
        , sum(e.current_block - nvl(b.current_block,0))
            + sum(e.current_busy - nvl(b.current_busy,0))
            + sum(e.current_congested - nvl(b.current_congested,0)) totcu
     from dba_hist_inst_cache_transfer e
        , dba_hist_inst_cache_transfer b
    where e.snap_id    = :eid
      and b.snap_id    = :bid
      and e.dbid            = :dbid
      and e.instance_number = b.instance_number
      and e.dbid            = b.dbid
      and e.class            = b.class
      and e.instance         = b.instance
   group by e.instance_number, e.instance
          , case when e.class in ('data block','undo header','undo block')
               then e.class
               else 'others'
           end)
where totcr + totcu > 0
order by instance_number, totcr + totcu desc;


clear breaks
-- ------------------------------------------------------------------

--
-- Parameters
set newpage 0;

ttitle 'init.ora Parameters ' -
       skip 1 -
       '~~~~~~~~~~~~~~~~~~~ ' -
       skip 1 -
       'DB: ' db_name ' ' -
       'Snaps: ' format 99999999 begin_snap '-' format 99999999 end_snap -
       skip 1 -
       '-> ''*'' indicates same value across all instances' -
       skip 2;

break on parameter_name
column parameter_name  format a29      heading 'Parameter Name'         trunc;
column bval            format a53      heading 'Begin value'
column eval            format a14      heading 'End value|(if different)' trunc just c;
column inst_id         format a3       heading 'I#'

with pval as (
     select e.parameter_name
          , e.instance_number
          , b.value                                bval
          , decode(b.value, e.value, ' ', e.value) eval
          , count(*)                               instcnt
       from dba_hist_parameter b
          , dba_hist_parameter e
      where b.snap_id(+)         = :bid
        and e.snap_id            = :eid
        and e.dbid               = :dbid
        and b.dbid(+)            = e.dbid
        and b.instance_number(+) = e.instance_number
        and b.parameter_name(+)            = e.parameter_name
        and translate(e.parameter_name, '_', '#') not like '##%'
        and (   nvl(b.isdefault, 'X')   = 'FALSE'
             or nvl(b.ismodified,'X')  != 'FALSE'
             or     e.ismodified       != 'FALSE'
             or nvl(e.value,0)         != nvl(b.value,0)
            )
  group by e.parameter_name
         , b.value
         , decode(b.value, e.value, ' ', e.value)
         , rollup(e.instance_number)
  )
select /* get identical parameters */
       parameter_name
     , '  *'             inst_id
     , bval
     , eval
  from pval
 where instance_number is null and instcnt = :numinst
union all
select /* get parameters that are not the same for all instances */
       parameter_name
     , lpad(to_char(instance_number),3)  inst_id
     , bval
     , eval
  from pval
 where instance_number is not null and instcnt < :numinst
   and parameter_name not in (select /*first part of query */
                                     parameter_name
                                from pval
                               where instance_number is null
                                 and instcnt = :numinst)
order by parameter_name, inst_id;

clear breaks

repfooter center -
   '-------------------------------------------------------------';

-- ------------------------------------------------------------------


prompt
prompt End of Report ( &report_name )
prompt
spool off;
set termout off;
clear columns sql;
ttitle off;
btitle off;
repfooter off;
set linesize 78 termout on feedback 6;
undefine begin_snap
undefine end_snap
undefine db_name
undefine dbid
undefine inst_num
undefine num_days
undefine report_name
undefine top_n_sql
undefine top_pct_sql
undefine top_n_events
undefine top_n_segstat
undefine btime
undefine etime
undefine num_rows_per_hash
whenever sqlerror continue;

--
--  End of script file;


