set linesize 200 pagesize 1000
select * from table(dbms_xplan.display_cursor('&sql_id',0,'ADVANCED'));