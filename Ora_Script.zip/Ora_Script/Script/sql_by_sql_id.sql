set linesize 200 pagesize 1000
select inst_id, sql_text
  from gv$sqltext
 where sql_id = '&sql_id'
 order by inst_id, piece ;