 with tmp_lock_holder as
  (select *
     from (select w.inst_id || '_' || w.sid waiting_sid,
                  h.inst_id || '_' || h.sid holder_sid,
                  w.type,
                  w.request,
                  h.lmode,
                  w.ctime,
                  w.id1,
                  w.id2
             from gv_lock_bak w, gv_lock_bak h
            where w.type = h.type
              and w.id1 = h.id1
              and w.id2 = h.id2
              and w.request > 0
              and h.lmode > 0))
 select lpad(' ', (level - 1) * 5) || decode(level, 1, '', '|==> ') ||
        waiting_sid "�ỰID",
        decode(type, 'TM', '����', 'TX', '����', type) "������������",
        request "��������ģʽ",
        lmode "��������ģʽ",
        ctime "�ȴ�����ʱ��",
        id1,
        id2
   from (select *
           from (select holder_sid waiting_sid,
                        null holder_sid,
                        'None' as type,
                        null request,
                        null lmode,
                        null ctime,
                        null id1,
                        null id2
                   from tmp_lock_holder
                 minus
                 select waiting_sid,
                        null holder_sid,
                        'None' as type,
                        null request,
                        null lmode,
                        null ctime,
                        null id1,
                        null id2
                   from tmp_lock_holder
                 union all
                 select * from tmp_lock_holder)
          where waiting_sid != holder_sid
             or holder_sid is null)
  start with holder_sid is null
 connect by prior waiting_sid = holder_sid;