set lines 200
set pages 1000
COL OBJECT_OWNER FORMAT A16
select 'TABLE FULL SCAN' AS FULL_TYPE,
       t.sql_id,
       p.plan_hash_value,
       p.object_owner,
       p.object_name 
  from v$sqlarea t, v$sql_plan p
 where t.hash_value=p.hash_value
   and p.operation='TABLE ACCESS'
   and p.options='FULL'
 union
 select 'INDEX FULL SCAN',
       t.sql_id,
       p.plan_hash_value,
       p.object_owner,
       p.object_name 
  from v$sqlarea t, v$sql_plan p
 where t.hash_value=p.hash_value
   and p.operation='INDEX'
   and p.options='FULL SCAN'
 ;
  
