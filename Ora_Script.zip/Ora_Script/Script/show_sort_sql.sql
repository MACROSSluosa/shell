set lines 200 pages 1000
col sid_serial format a24
col mb_used format 999999999
col tablespace format a16
col sql_id format a14
SELECT S.sid || ',' || S.serial#  sid_serial,
S.username,
Q.sql_id,
round(T.blocks * TBS.block_size / 1024 / 1024,0) mb_used,
T.tablespace,  
T.sqladdr address,
Q.hash_value
FROM v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS
WHERE T.session_addr = S.saddr
AND T.sqladdr = Q.address(+)
and  t.sqlhash = q.hash_value(+)
and t.sql_id =  q.sql_id
AND T.tablespace = TBS.tablespace_name
ORDER BY 4;

