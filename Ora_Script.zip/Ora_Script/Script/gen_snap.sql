exec dbms_workload_repository.create_snapshot();

