set linesize 200 pagesize 1000
select sql_text
  from v$session a, v$sqltext b
 where a.sql_id = b.sql_id
   and a.sid = &sid
 order by b.piece  ;