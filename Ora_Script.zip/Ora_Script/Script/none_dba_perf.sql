create user dbperf identified by dbperf default tablespace users;

grant create session                            to dbperf;

grant select any dictionary                     to dbperf;

grant advisor                                   to dbperf;

grant select on v_$active_session_history       to dbperf;

create synonym dbperf.v$active_session_history  for sys.v_$active_session_history;

grant execute on sys.dbms_workload_repository   to dbperf;

grant execute on sys.dbms_advisor               to dbperf;

grant execute on sys.dbms_sys_error             to dbperf;

grant execute on sys.prvt_advisor               to dbperf;

grant execute on sys.dbms_space                 to dbperf;

grant execute on sys.dbms_sqltune               to dbperf;

granr execute on sys.dbms_metadata              to dbperf;

grant select on WRH$_SQLSTAT to dbperf;

create synonym dbperf.WRH$_SQLSTAT for sys.WRH$_SQLSTAT;


grant select on WRM$_SNAPSHOT to dbperf;

grant select on wri$_optstat_tab_history to dbperf;

grant select on wri$_optstat_ind_history to dbperf;

grant select any table to dbperf;

create synonym dbperf.WRM$_SNAPSHOT for sys.WRM$_SNAPSHOT;

create synonym dbperf.wri$_optstat_tab_history for sys.wri$_optstat_tab_history;

