CLEAR COLUMNS BREAKS COMPUTES
COLUMN tablespace   FORMAT a20             HEADING 'Tablespace Name'
COLUMN sizeb        FORMAT 999,999,999     HEADING 'Used Size'
COLUMN sizea        FORMAT 999,999,999     HEADING 'Tablespace Size'
COLUMN status       FORMAT a12             HEADING 'Status'
COLUMN pct          FORMAT a8              HEADING 'Used Pct'


CLEAR COMPUTES BREAKS

BREAK ON tablespace on report
COMPUTE sum LABEL "Total: " OF sizeb  ON report

select a.tablespace_name tablespace
      ,b.status                             status
      ,b.bytes                              sizeb
      ,a.bytes                              sizea
      ,round(100*(b.bytes/a.bytes),2)||'%'  pct
from
   (select tablespace_name
          ,sum(bytes)/1024/1024 bytes
    from dba_data_files
    group by tablespace_name) a,
   (select tablespace_name
          ,status
          ,sum(bytes)/1024/1024 bytes
    from dba_undo_extents
    group by tablespace_name,status) b
where a.tablespace_name=b.tablespace_name
order by 1,2;

