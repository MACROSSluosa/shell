#!/bin/ksh
export ORACLE_SID=$ORACLE_SID
LOG_PATH=$ORACLE_BASE/admin/chk_ora
LOGFILE=$LOG_PATH/MonUndo.log

sqlplus -S  "/as sysdba" <<EOF >>$LOGFILE
set lines 200 pages 900
set feedback off
col inst_id format 999999
col end_TM format a16
col tbsname format a12
col tablespace_name format a12

select to_char(sysdate,'yyyymmdd hh24:mi:ss') as MonTime,
        tablespace_name,
        round(sum(bytes)/1024/1024,2) as Size_Mb,
        sum(blocks)          as TotBlks,
        status
   from dba_undo_extents
  group by tablespace_name,status
  order by tablespace_name,status;

exit;
EOF

file_size=`du -sm $LOGFILE| awk '{print $1}'`
if [ $file_size -gt 8 ]
then
cp $LOGFILE $LOGFILE.`date +"%Y%m%d%H%M"`
>$LOGFILE
fi

find $LOG_PATH -name 'MonUndo.log*' -mtime +90 -exec rm {} \;


