set lines 200 pages 1000
col tablespace_name format a36
col status format a12

col PROTECTION_MODE format a24
col PLATFORM_NAME format a24
col PROTECTION_LEVEL format a24

alter session set nls_date_format='YYYYMMDD HH24:MI:SS' ;
prompt 
prompt -- versiom
select * from v$version;

prompt
prompt --db info
select dbid,
       name,
       platform_name,
       log_mode,
       controlfile_type,
       open_mode,
       protection_mode,
       protection_level,
       database_role 
 from v$database;
 
 
PROMPT
promp --dba_registry
col comp_name format a36
select comp_name,
       version,
       status
  from dba_registry; 

prompt
prompt -- character set
select * from nls_database_parameters where parameter like '%CHARACTERSET%';

PROMPT
promp --v$block_change_tracking
select * from v$block_change_tracking;


PROMPT
promp --dba_hist_wr_control
select * from dba_hist_wr_control;



prompt
prompt --v$log
SELECT thread#,
       group#,
       members,
       bytes/1024/1024 as size_mb,
       status,
       archived
 from  v$log ;


SELECT
  SUBSTR(TO_CHAR(first_time, 'YYYY-MM-DD HH:MI:SS'),1,10)  DAY
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'00',1,0)) H00
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'01',1,0)) H01
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'02',1,0)) H02
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'03',1,0)) H03
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'04',1,0)) H04
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'05',1,0)) H05
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'06',1,0)) H06
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'07',1,0)) H07
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'08',1,0)) H08
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'09',1,0)) H09
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'10',1,0)) H10
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'11',1,0)) H11
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'12',1,0)) H12
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'13',1,0)) H13
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'14',1,0)) H14
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'15',1,0)) H15
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'16',1,0)) H16
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'17',1,0)) H17
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'18',1,0)) H18
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'19',1,0)) H19
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'20',1,0)) H20
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'21',1,0)) H21
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'22',1,0)) H22
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'23',1,0)) H23
  , COUNT(*)                                                                      TOTAL
FROM
  v$log_history  a
GROUP BY SUBSTR(TO_CHAR(first_time, 'YYYY-MM-DD HH:MI:SS'),1,10)
ORDER BY SUBSTR(TO_CHAR(first_time, 'YYYY-MM-DD HH:MI:SS'),1,10)
;


prompt
prompt -- from v$datafile
set lines 200
col tablespace_name format a30
col file_name format a44
select b.name as tablespace_name,
       a.name as file_name,
       a.file#,
       a.block1_offset,
       a.status
  from v$datafile a ,
       v$tablespace b
 where a.ts#=b.ts#
order by 1,3,2;


prompt
prompt --- undo extents
select tablespace_name,
       status,
       round(sum(bytes)/1024/1012,0) as size_mb
from dba_undo_extents
group by tablespace_name,
         status
order by 1,2;

prompt
prompt -----sort segment
select  s.tablespace_name                                         tablespace_name
       ,round((used_blocks*block_size)/1024/1024,0)               used_blocks_mb
       ,round((free_blocks*block_size)/1024/1024,0)               free_blocks_mb
       ,round((total_blocks*block_size)/1024/1024,0)              total_blocks_mb
       ,round((max_used_blocks*block_size)/1024/1024,0)           max_used_blocks_mb
       ,round((max_sort_blocks*block_size)/1024/1024,0)           max_sort_blocks_mb
from v$sort_segment s,dba_tablespaces t
where s.tablespace_name=t.tablespace_name
order by s.tablespace_name;

prompt
prompt -----resource limit
select * from v$resource_limit;


col sequence_owner format a24
col sequence_name format a24
col last_number format 999999999999999999999999
col max_value   format 9999999999999999999999999999999
prompt 
prompt  -- sequence
select a.sequence_owner,
        a.sequence_name,
        a.last_number,
        a.max_value,
        round(a.last_number/a.max_value,2) as pct,
        a.cycle_flag 
from dba_sequences a  
where cycle_flag='N'
  and sequence_owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
order by 5;

prompt
prompt -- parameter
col name format a36
col value format a36
select inst_id,
       name,
       value 
  from gv$parameter 
 where name in('cluster_database','cluster_database_instances','db_block_size','cpu_count');
 
prompt
prompt -- undefault parameter
col name format a36
col value format a80
select name,
       value 
 from gv$parameter 
 where isdefault ='FALSE' order by name;
 
prompt
prompt -- user info
select username,
       account_status,
       created,
       default_tablespace,
       temporary_tablespace 
 from dba_users order by created;
 
prompt
prompt -- datafile total size
select round(sum(bytes)/1024/1024/1024,1) datafile_size_g from dba_data_files;

prompt
prompt -- tempfile total size
select round(sum(bytes)/1024/1024/1024,1) temp_size_g from dba_temp_files;

prompt 
prompt --datafile total nums
select count(*) datafile_nums from dba_data_files;

prompt
prompt -- tablespace total size
select tablespace_name,sum(bytes)/1024/1024 from dba_data_files group by tablespace_name order by 2;

prompt
prompt --tablespace total free size
select tablespace_name,sum(bytes)/1024/1024 from dba_free_space group by tablespace_name order by 2;

prompt
prompt --segment total size
select round(sum(bytes)/1024/1024/1024,1) segment_size_g from dba_segments;

prompt
prompt --datafile info
col file_name format a40
select file_name,
       file_id,
       tablespace_name,
       round(bytes/1024/1024,1) size_m,
       autoextensible,
       round(maxbytes/1024/1024,1) max_m,
       online_status 
  from dba_data_files order by tablespace_name,file_id;
  
prompt
prompt --datafile info
col file_name format a40
select file_name,
       file_id,
       tablespace_name,
       round(bytes/1024/1024,1) size_m,
       autoextensible,
       round(maxbytes/1024/1024,1) max_m
  from dba_temp_files order by tablespace_name,file_id;


prompt
prompt --v$datafile
select b.name as tablespace_name, 
a.name as file_name, 
a.file#, 
a.block1_offset, 
a.status 
from v$datafile a , 
v$tablespace b 
where a.ts#=b.ts# 
order by 1,3,2; 


PROMPT
prompt --Invalid Index
select owner , index_name,'IVALID INDEX'
  from dba_indexes
 where status not in ('VALID', 'N/A')
union all
select index_owner , index_name,'IVALID INDEX PARTITION'
  from dba_ind_partitions
 where status not in ('USABLE', 'N/A')
union all
select  index_owner ,index_name,'IVALID INDEX SUBPARTITION'
  from dba_ind_subpartitions
 where status not in ('USABLE', 'N/A');

prompt 
prompt --job status
col what format a80
SELECT
job,
substr(what,1,80) as what,
broken,
failures
FROM
dba_jobs
WHERE
( broken = 'Y' AND   failures > 0 ) or
( broken = 'N' AND   failures > 0 );

prompt 
prompt -- Invalid Object
col owner format a24
col object_type format a36
col object_name format a36
SELECT owner, object_type, object_name, status 
FROM dba_objects
WHERE status <> 'VALID'
ORDER BY owner,object_type,object_name;

prompt
prompt --Invalid constraints
col constraint_name format a36
col table_name format a36
SELECT OWNER,
       CONSTRAINT_NAME,
       CONSTRAINT_TYPE,
       TABLE_NAME
 FROM DBA_CONSTRAINTS 
WHERE STATUS='DISABLED';

prompt
prompt --Invalid Triggers
col trigger_name format a36
col trigger_type format a16

SELECT OWNER,
      TRIGGER_NAME,
      TRIGGER_TYPE,
      table_name
 FROM DBA_TRIGGERS 
WHERE STATUS='DISABLED';


prompt
prompt --recover file
select file# 
  from v$recover_file ;
  

prompt
prompt -- 2pc pending
select count(*) from dba_2pc_pending ;


prompt 
prompt -- long ops
select  l.sid                         sid
       ,l.username                    username
       ,opname                        opname
       ,s.sql_id                      sql_id
       ,sofar                         sofar
       ,totalwork                     totalwork
       ,elapsed_seconds               elapsed
       ,time_remaining                remaining
       ,message                       message
from  v$session_longops l
     ,v$session         s
where l.sid=s.sid
and s.status='ACTIVE'
and time_remaining > 0
order by start_time desc;

PROMPT
prompt --user object nums
select owner, object_type, count(*)
  from dba_objects
 where owner not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX'))
 group by owner, object_type
 order by 1, 3;
 
PROMPT
prompt -- user segment info
select owner,
       segment_type,
       count(*)  as cnt,
       round(sum(bytes) / 1024 / 1024, 1) size_m
  from dba_segments
 where owner not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX'))
 group by owner, segment_type
 order by 1, 3;


prompt
PROMPT -- TABLE NO INDEX
select owner,table_name from dba_tables where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
MINUS
select TABLE_owner,table_name from dba_INDEXES where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX')) ;

PROMPT 
PROMPT --TABLE NO PK OR UNIQUE
select owner,table_name from dba_tables where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
MINUS
select owner,table_name 
from dba_CONSTRAINTS 
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX')) 
  AND constraint_type = 'P' OR (constraint_type = 'u');


prompt 
prompt -- non part table and size > 1024mb
select owner,table_name 
from dba_tables 
where owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
  and partitioned = 'NO' 
minus
select m.owner,m.segment_name
from (
SELECT OWNER,SEGMENT_NAME,nvl(round(sum(bytes)/1024/1024,0),0) as size_mb
 FROM DBA_SEGMENTS
where segment_type = 'TABLE'
  and owner not in (select username from dba_users where default_tablespace in ('SYSTEM','SYSAUX'))
 group by owner,segment_name
 ) m
 where  m.size_mb <=1024;
 
 
PROMPT 
PROMPT -- TABLE DEGREE <> 1
 select owner,table_name,degree from dba_tables where trim(degree) <> '1';

prompt
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
  from dba_tablespaces a,
       (select d.tablespace_name tablespace_name,
               round((d.sumbytes / 1024 / 1024), 2) total_m,
               round(decode(f.sumbytes, null, 0, f.sumbytes) / 1024 / 1024,
                     2) free_m,
               round(((d.sumbytes - decode(f.sumbytes, null, 0, f.sumbytes)) / 1024 / 1024),
                     2) used_m,
               round((d.sumbytes - decode(f.sumbytes, null, 0, f.sumbytes)) * 100 /
                     d.sumbytes,
                     2) used_pct
          from (select tablespace_name, sum(bytes) sumbytes
                  from dba_free_space
                 group by tablespace_name) f,
               (select tablespace_name, sum(bytes) sumbytes
                  from dba_data_files
                 group by tablespace_name) d
         where f.tablespace_name(+) = d.tablespace_name
         order by d.tablespace_name) b
 where a.tablespace_name = b.tablespace_name
union all
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
  from dba_tablespaces a,
       (select d.tablespace_name tablespace_name,
               round((d.sumbytes / 1024 / 1024), 2) total_m,
               round((d.sumbytes / 1024 / 1024), 2) -
               round(decode(f.sumbytes, null, 0, f.sumbytes) / 1024 / 1024,
                     2) free_m,
               round(decode(f.sumbytes, null, 0, f.sumbytes) / 1024 / 1024,
                     2) used_m,
               round(decode(f.sumbytes, null, 0, f.sumbytes) * 100 /
                     d.sumbytes,
                     2) used_pct
          from (select tablespace_name, sum(bytes_used) sumbytes
                  from v$temp_extent_pool
                 group by tablespace_name) f,
               (select tablespace_name, sum(bytes) sumbytes
                  from dba_temp_files
                 group by tablespace_name) d
         where f.tablespace_name(+) = d.tablespace_name
         order by d.tablespace_name) b
 where a.tablespace_name = b.tablespace_name
 order by 5;
 
COLUMN backup_name           FORMAT a130   HEADING 'Backup Name'          ENTMAP off
COLUMN start_time            FORMAT a75    HEADING 'Start Time'           ENTMAP off
COLUMN elapsed_time          FORMAT a75    HEADING 'Elapsed Time'         ENTMAP off
COLUMN status                              HEADING 'Status'               ENTMAP off
COLUMN input_type                          HEADING 'Input Type'           ENTMAP off
COLUMN output_device_type                  HEADING 'Output Devices'       ENTMAP off
COLUMN input_size                          HEADING 'Input Size'           ENTMAP off
COLUMN output_size                         HEADING 'Output Size'          ENTMAP off
COLUMN output_rate_per_sec                 HEADING 'Output Rate Per Sec'  ENTMAP off

SELECT
  r.command_id                                     backup_name
  ,TO_CHAR(r.start_time, 'mm/dd/yyyy HH24:MI:SS')  start_time
  ,r.time_taken_display                            elapsed_time
  , DECODE(   r.status
            , 'COMPLETED'
            ,  r.status 
            , 'RUNNING'
            ,  r.status 
            , 'FAILED'
            ,  r.status 
            ,  r.status 
    )                         status
  , r.input_type              input_type
  , r.output_device_type      output_device_type
  ,  r.input_bytes_display             input_size
  ,  r.output_bytes_display            output_size
  ,  r.output_bytes_per_sec_display    output_rate_per_sec
FROM
    (select
         command_id
       , start_time
       , time_taken_display
       , status
       , input_type
       , output_device_type
       , input_bytes_display
       , output_bytes_display
       , output_bytes_per_sec_display
     from v$rman_backup_job_details
     order by start_time DESC
    ) r
WHERE
    rownum < 21;  


prompt
prompt --sgastat pool sum
select pool,
       round(sum(bytes)/1024,2) as size_kb
from v$sgastat
group by pool ;

prompt
prompt --pgastat
col name format a40
col value format 9999999999999999999999999999
select * from v$pgastat ;

prompt
prompt --process
select spid,
       addr,
       PROGRAM,
       PGA_USED_MEM,
       PGA_ALLOC_MEM,
       PGA_MAX_MEM
  from v$process
 where PGA_USED_MEM/1024/1024 > 128 ;
 
prompt
prompt -- process nums
select count(*) from v$process ;

PROMPT 
PROMPT -- SYSAUX USAGE
col OCCUPANT_NAME format a40
SELECT OCCUPANT_NAME,SPACE_USAGE_KBYTES
FROM V$SYSAUX_OCCUPANTS
where SPACE_USAGE_KBYTES/1024 >128
ORDER BY 2,1 ;


prompt
prompt -- FK tithout index
select owner,table_name
  from (SELECT /*+ rule */
         acc.owner, acc.table_name, acc.column_name, acc.position
          FROM dba_cons_columns acc, dba_constraints ac
         WHERE ac.constraint_name = acc.constraint_name
           AND ac.constraint_type = 'R'
           and ac.owner  in
               (select /*+ no_merge */
                 username
                  from dba_users
                 where default_tablespace not in
                       ('SYSTEM', 'SYSAUX', 'USERS'))
        MINUS
        SELECT /*+ rule */
         table_owner owner, table_name, column_name, column_position
          FROM dba_ind_columns
         where index_owner  in
               (select /*+ no_merge */
                 username
                  from dba_users
                 where default_tablespace not in
                       ('SYSTEM', 'SYSAUX', 'USERS')))
 ORDER BY owner,table_name, position, column_name;

prompt
prompt --All users:
col username format a16
col DEFAULT_TABLESPACE format a36
col TEMPORARY_TABLESPACE format a24
col create format a20
col ACCOUNT_STATUS format a24

SELECT USERNAME,
       DEFAULT_TABLESPACE,
       TEMPORARY_TABLESPACE,
       TO_CHAR(CREATED,'YYYYMMDD') AS CREATED,
       ACCOUNT_STATUS
FROM DBA_USERS
WHERE DEFAULT_TABLESPACE NOT IN ('SYSTEM','SYSAUX') ;

prompt
prompt
prompt --user with sysdba or sysoper
select * from V$PWFILE_USERS;

col grantee format a16
col privilege format a30

prompt
prompt
prompt --user privilege:
SELECT grantee,privilege
from dba_sys_privs
where grantee in (select username from dba_users where default_tablespace not in ('SYSTEM','SYSAUX'))
UNION
SELECT GRANTEE, GRANTED_ROLE
FROM DBA_ROLE_PRIVS
WHERE GRANTEE in (select username from dba_users where default_tablespace not in ('SYSTEM','SYSAUX')) ;

col tablespace_name format a20

prompt
prompt
prompt --tablespace quotas for user
SELECT USERNAME ,
       TABLESPACE_NAME ,
       DECODE(MAX_BYTES,-1,'UNLIMITED',MAX_BYTES/1024/1024) QUOTA_MB
FROM DBA_TS_QUOTAS;

prompt
prompt ----Full Scan sql
select 'TABLE FULL SCAN' AS FULL_TYPE,
       t.sql_id,
       p.plan_hash_value,
       p.object_owner,
       p.object_name 
  from v$sqlarea t, v$sql_plan p
 where t.hash_value=p.hash_value
   and p.operation='TABLE ACCESS'
   and p.options='FULL'
   and P.object_owner <> 'SYS'
 union
 select 'INDEX FULL SCAN',
       t.sql_id,
       p.plan_hash_value,
       p.object_owner,
       p.object_name 
  from v$sqlarea t, v$sql_plan p
 where t.hash_value=p.hash_value
   and p.operation='INDEX'
   and p.options='FULL SCAN'
   AND P.object_owner <> 'SYS'
 ;

PROMPT 
PROMPT-- TABLE DEFRAGMENT
SELECT EST.OWNER,
       EST.TABLE_NAME,
       EST.est_size_mb,
       ACT.act_size_mb,
       ROUND((1-EST.est_size_mb/ACT.act_size_mb)*100,2) AS PCT
FROM 
(select owner ,table_name,round(avg_row_len*nvl(num_rows,0)/1024/1024/0.85,0) as est_size_mb
from dba_tables
where OWNER IN (SELECT USERNAME FROM DBA_USERS WHERE DEFAULT_TABLESPACE NOT IN ('SYSTEM','SYSAUX'))) est,
(select owner,segment_name,NVL(round(sum(bytes)/1024/1024,0),0.0000000001) as act_size_mb
from dba_segments
where OWNER IN (SELECT USERNAME FROM DBA_USERS WHERE DEFAULT_TABLESPACE NOT IN ('SYSTEM','SYSAUX'))
  and segment_type like '%TABLE%'
GROUP BY OWNER,SEGMENT_NAME
) ACT
WHERE EST.OWNER = ACT.OWNER
  AND EST.TABLE_NAME =  ACT.SEGMENT_NAME
  AND ACT.act_size_mb >=512
  and ROUND((1-EST.est_size_mb/ACT.act_size_mb)*100,2) >=50
ORDER BY 5
;




prompt 
prompt
prompt --segment size for user:
col owner format a16
col tablespace_name format a20
col SEGMENT_TYPE format a20
SELECT OWNER,
       TABLESPACE_NAME,
       SEGMENT_TYPE,
       SUM(BYTES)/1024/1024 AS SIZE_MB
FROM DBA_SEGMENTS
WHERE OWNER IN (SELECT USERNAME FROM DBA_USERS WHERE DEFAULT_TABLESPACE NOT IN ('SYSTEM','SYSAUX'))
GROUP BY OWNER,TABLESPACE_NAME,SEGMENT_TYPE
ORDER BY 1,2 ;

prompt
prompt
prompt--tablespace useage:

SET PAGESIZE 999
SET LINESIZE 110
TTITLE  LEFT "Tablespace Information"  SKIP 1 -
      LEFT "======================================================================================"
SET HEAD ON
SET FEEDBACK ON
BREAK ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF total_m ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF free_m  ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF used_m  ON REPORT
col tablespace format a25
col ext_mgt  format a8
col seg_mgt  format a8
col status format a7
set feedback off
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))/1024/1024),2) used_m,
   round((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))*100/d.sumbytes,2) used_pct
  from
    (select
      tablespace_name,   sum(bytes) sumbytes
     from dba_free_space   group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes    
      from dba_data_files     group by tablespace_name) d
    where f.tablespace_name(+) = d.tablespace_name
    order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name
union all
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round((d.sumbytes/1024/1024),2)-round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) used_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)*100/d.sumbytes,2) used_pct
   from
    (select
      tablespace_name,      sum(bytes_used) sumbytes
    -- sum(bytes_cached) sumbytes
     from v$temp_extent_pool     group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes
     from dba_temp_files     group by tablespace_name) d
  where f.tablespace_name(+) = d.tablespace_name
  order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name order by 5;
TTITLE OFF
set feedback on


prompt
prompt --sgatat
select pool ,name,bytes 
from v$sgastat 
order by pool,name;


