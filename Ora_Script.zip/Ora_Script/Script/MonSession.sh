#!/bin/ksh
export ORACLE_SID=$ORACLE_SID
LOG_PATH=/tmp/lirl/Script
LOGFILE=$LOG_PATH/Monitor_Session.log

sqlplus -S "/as sysdba" <<EOF >>$LOGFILE
set lines 200 pages 900
set feedback off
col Mon_time format a20
col inst_id format 999
COL username format a12
col machine format a16
col status format a10
col program format a24
col sess_cnt format 9999 
select to_char(sysdate,'yyyymmdd hh24:mi:ss') as Mon_time,
       inst_id,
       username,
       machine,
       status,
       substr(program,1,24) as program,
       count(*) as sess_cnt
from gv\$session
group by to_char(sysdate,'yyyymmdd hh24:mi:ss') ,
         inst_id,
         username,
         machine,
         status,
         substr(program,1,24)
order by inst_id,
         username,
         status,
         machine
;
         
exit;
EOF

file_size=`du -sm $LOGFILE| awk '{print $1}'`
if [ $file_size -gt 8 ]
then
cp $LOGFILE $LOGFILE.`date +"%Y%m%d%H%M"`
>$LOGFILE
fi

find $LOG_PATH -name 'Monitor_Session*' -mtime +30 -exec rm {} \;


