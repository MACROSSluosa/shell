set linesize 200 pagesize 1000
col event for a40
col program for a20
col sid format 99999
col logonTM format a20 
col program format a18
col status format a12
col sid new_value sid  
col username format a12 
col owner format a12
select &sid  sid from dual;
select a.sid,
       a.serial#,
       b.spid,
       a.status,
       a.username,
       a.state,
       a.SECONDS_IN_WAIT,
       to_char(logon_time,'yyyymmdd hh24:mi:ss') as logonTM
  from v$session a, v$process b
 where a.paddr = b.addr
   and a.sid = &sid ;
prompt --**************************************************
select sid,
       sql_id,
       prev_sql_id,
       sql_child_number
  from v$session
 where sid = &sid;
prompt --**************************************************
select sid,
       event,
       p1,
       p2,
       p1raw
 from v$session
where sid = &sid;
prompt "--------------------------------------------------"
prompt "lock with the session
prompt "--------------------------------------------------"
select * from v$lock where sid = &sid;
prompt
prompt

prompt "--------------------------------------------------"
prompt "object locked with the session"
prompt "--------------------------------------------------"
col object_name format a24
col object_type format a16
col created format a20
col last_ddl format a20
col temporary format 4
select distinct a.owner,a.object_id,
       a.object_name,
       a.object_type,
       temporary,
       to_char(a.created,'yyyymmdd hh24:mi:ss') as created,
       to_char(a.last_ddl_time,'yyyymmdd hh24:mi:ss') as last_ddl
  from dba_objects a,v$lock b
 where a.object_id = b.id1
   and b.sid = &sid;


set lines 132 pages 999
undefine sid;

