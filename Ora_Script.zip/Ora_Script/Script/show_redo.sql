set lines 200 pages 1000
col member format a36
col inst_id format 99
col group# format 99
col Size_Mb format 999999
select inst_id,group#,thread#,bytes/1024/1024 as Size_Mb ,MEMBERS from gv$log order by 1,3,2;

prompt ---------------Log File Member

select INST_ID,GROUP#,MEMBER from gv$logfile order by 1,2 ;


