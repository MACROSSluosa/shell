set pages 3000
col Parameter format a40
col "Instance Value" format a20
select KSPPINM "Parameter",
       c.ksppstvl "Instance Value"
from x$ksppi a, 
     x$ksppcv b,
     x$ksppsv c
where a.indx = b.indx and 
      a.indx = c.indx and 
      a.ksppinm like lower('%_optimizer%');