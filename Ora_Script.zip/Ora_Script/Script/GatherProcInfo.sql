oradebug setospid &os_process_id
oradebug dump processstate 10
oradebug short_stack
exec dbms_lock.sleep(60)
oradebug short_stack
oradebug dump processstate 10
oradebug tracefile_name
