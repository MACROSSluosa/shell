col sid for 99999
set linesize 200 pagesize 10000

select to_char(sysdate,'yyyymmdd hh24:mi:ss')  from dual;
select 
    b.sid,a.contents,a.segtype,
    a.size_m,b.sql_id,substr(c.sql_text,1,80) as sql_text
from 
     (select * 
        from
              (    select session_addr,contents,segtype,sum(blocks*8/1024) size_m 
                     from v$tempseg_usage 
                    group by session_addr,contents,segtype
                   having sum(blocks*8/1024) >= 100
                    order by sum(blocks*8/1024) desc
               )
      where rownum < 20
     ) a,
     v$session b,
     v$sqltext c
where 
      a.session_addr=b.saddr
 and  b.sql_id=c.sql_id
order by 
      b.sid,a.contents,a.segtype,b.sql_id,c.piece;

 
CLEAR COLUMNS BREAKS COMPUTES
 
COLUMN tablespace               FORMAT a20             HEADING 'Tablespace Name'      
COLUMN used_blocks              FORMAT 999,999         HEADING 'Used Size'            
COLUMN free_blocks              FORMAT 999,999         HEADING 'Free Size'            
COLUMN total_blocks             FORMAT 999,999         HEADING 'Total Size'           
COLUMN max_used_blocks          FORMAT 999,999         HEADING 'Max Used Size'        
COLUMN max_sort_blocks          FORMAT 999,999         HEADING 'Max Sort Size'        
 
CLEAR COMPUTES BREAKS
 
BREAK ON report
 
col tablespace_name format a24
set lines 200 pages 1000
select 
        s.tablespace_name                                tablespace
       ,(used_blocks*block_size)/1024/1024               used_blocks
       ,(free_blocks*block_size)/1024/1024               free_blocks
       ,(total_blocks*block_size)/1024/1024              total_blocks
       ,(max_used_blocks*block_size)/1024/1024           max_used_blocks
       ,(max_sort_blocks*block_size)/1024/1024           max_sort_blocks
from v$sort_segment s,dba_tablespaces t
where s.tablespace_name=t.tablespace_name;
 