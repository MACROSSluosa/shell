set lines 200 pages 999
col logon_time format a18
col sid format 9999999
col serial# format 9999999
select b.sid,
       b.serial#,
       to_char(b.logon_time,'yyyymmdd hh24:mi:ss') as logon_time,
       a.sql_id,
       a.segtype,
       round(a.blocks*8/1024,0) as size_mb,
       b.status,
       b.state,
       paddr
  from v$tempseg_usage a,
       v$session b
 where a.session_addr =  b.saddr
  order by 1,2;
  

