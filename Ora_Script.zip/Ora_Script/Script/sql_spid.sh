#!/bin/ksh
sqlplus -S "/as sysdba"  <<EOF > $1.log  
 col SERIAL# format 999999
 col sid format 99999
 col username format a10
 col machine format a12
 col program format a40
 col sql_text format a80
 col LOGIN_TIME format a30
 set lines 1000
 set pages 1000
 set verify off
 col sql_hash_value new_value hash_value  head hash_value
 col sql_id new_value sql_id
select sid,serial#,username,program,machine,process,sql_hash_value,
         to_char(logon_time,'yyyy/mm/dd hh24:mi:ss') as login_time,sql_id,event
  from v\$session
 where paddr in ( select addr from v\$process where spid=$1);

select sql_text
  from v\$sqltext_with_newlines
  where hash_value = &hash_value
 order by piece;

set feedback off 
set trimspool on 

prompt 
prompt "diaplay cursor"

select * from table(dbms_xplan.display_cursor('&sql_id',0,'ADVANCED'));

prompt 
prompt execute plan: 
set serveroutput on size 1000000 
begin 
dbms_output.put_line( '*------------------------------------------------------------------------------*'); 
    for i in (select rpad('|'||substr(lpad(' ',1 * (depth-1))||operation|| 
                decode(options, null,'',' '||options), 1, 32), 33, ' ')||'|'|| 
                rpad(decode(id, 0, '----- '||to_char(hash_value)||' -----', 
                substr(decode(substr(object_name, 1, 7), 'SYS_LE_', null, 
                object_name)||' ',1, 20)), 21, ' ')||'|'|| 
                lpad(decode(cardinality,null,'  ',decode(sign(cardinality-1000), 
                -1, cardinality||' ',decode(sign(cardinality-1000000), -1, 
                trunc(cardinality/1000)||'K',decode(sign(cardinality-1000000000), -1, 
                trunc(cardinality/1000000)||'M',trunc(cardinality/1000000000)||'G')))), 
                 7, ' ') || '|' || 
                lpad(decode(bytes,null,' ',decode(sign(bytes-1024), -1, bytes||' ', 
                decode(sign(bytes-1048576), 
                 -1, trunc(bytes/1024)||'K',decode(sign(bytes-1073741824), 
                -1, trunc(bytes/1048576)||'M',trunc(bytes/1073741824)||'G')))), 6, ' ') 
                 || '|' || 
                lpad(decode(cost,null,' ',decode(sign(cost-10000000), -1, cost||' ', 
                decode(sign(cost-1000000000), -1, trunc(cost/1000000)||'M', 
                trunc(cost/1000000000)||'G'))), 8, ' ') || '|' as Explain_plan 
              from v\$sql_plan 
               where hash_value = &hash_value 
              and child_number = (select max(child_number) from v\$sql_plan where 
               hash_value = &hash_value)) 
    loop 
      dbms_output.put_line(i.Explain_plan); 
    end loop; 
dbms_output.put_line( '*------------------------------------------------------------------------------*'); 
end; 
/ 
exit;
EOF
