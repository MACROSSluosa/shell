set linesize 200 pagesize 1000
select inst_id, sid, event, p1raw pin_handle_addr
  from gv$session
 where event = 'library cache pin';


select inst_id, KGLPNUSE KGLPNUSE_OR_SESSADDR, KGLPNHDL, KGLPNMOD, KGLPNREQ
  from x$kglpn
 where kglpnhdl = '&pin_handle_addr'
 order by KGLPNREQ;

prompt "If the above query didn't give the holder,the Holder maybe In Another Instance,You can use the object to query the holder"

select kglnaown owner,, kglnaobj object_name
  from X$KGLOB
 where KGLHDADR = '&&pin_handle_addr';
 
 
select 
      "query in another instance",
      p.inst_id,
      s.sid,
      s.sql_hash_value,
      s.username,
      s.osuser,
      s.machine,
      p.KGLPNUSE,
      p.KGLPNHDL,
      p.KGLPNMOD,
      p.KGLPNREQ,
      o.kglnaobj
 from v$session s, x$kglpn p, x$kglob o
where o.kglnaobj = '&object_name'
  and p.kglpnhdl = o.kglhdadr
  and s.SADDR = p.kglpnuse
  and p.KGLPNMOD <> 0;
  
  
---If is the Library cache lock,the replace the view x$kglpn using the view "x$kgllk"