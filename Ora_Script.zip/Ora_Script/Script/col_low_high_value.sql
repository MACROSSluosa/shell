set linesize 200 pagesize 1000
col low_value new_value low_value noprint
col high_value new_value high_value noprint

select low_value,high_value from dba_tab_col_statistics where table_name='&table_name' and column_name='&column_name';
alter session set nls_date_format='yyyymmdd hh24:mi:ss';
set serveroutput on
declare
min_date date;
max_date date;
begin
dbms_stats.CONVERT_RAW_VALUE('&low_value',min_date);
dbms_stats.CONVERT_RAW_VALUE('&high_value',max_date);
dbms_output.put_line('the min date is '||min_date);
dbms_output.put_line('the max date is '||max_date);
end;
/
