set lines 200 pages 1000

col Blocker_SID for a30
SELECT w.sid WAITER_SID, s.sid ||','||s.serial# "Blocker_SID", kglpnmod "Mode", kglpnreq "Req", SPID "OS Process"
FROM v$session_wait w, x$kglpn p, v$session s ,v$process o
WHERE p.kglpnuse=s.saddr
AND kglpnhdl=w.p1raw 
and w.event like '%library cache pin%'
and s.paddr=o.addr
and s.sid != w.sid;

prompt "-------------------------------------------------------------------------------------------------------------------------"

select sql_text 
      from v$sqlarea 
    where (v$sqlarea.address, v$sqlarea.hash_value) in ( 
             select sql_address, sql_hash_value 
               from v$session 
                where sid in ( 
                   select sid 
                     from v$session a, x$kglpn b 
                      where a.saddr = b.kglpnuse 
                       and b.kglpnmod <> 0 
                        and b.kglpnhdl IN (select p1raw 
                             from v$session_wait 
                             where sid=&sid and event like 'library%')));




