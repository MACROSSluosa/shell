#!/bin/ksh
export ORACLE_HOME=$ORACLE_HOME
export ORACLE_SID=$ORACLE_SID
export PATH=$ORACLE_HOME/bin:$PATH:.
DT=`date +%Y%m%d`
LOG_PATH=/tmp
LOG_NAME=$LOG_PATH/`hostname`_chk_redo_switch_prod_$DT.log

sqlplus -S "/as sysdba" <<EOF >$LOG_NAME
set lines 200 pages 0
col type format a30
col first_time format a18
col redo_mb format 9999
col archive_mb format 9999
set feedback off

select thread#,
       sequence#,
       first_time,
       switch_seconds as switch_seconds,
       during_secs,
       redo_mb,
       archive_mb,
       type  
from(
select log_switch.thread#,
       log_switch.sequence#,
       log_switch.first_time,
       log_switch.seconds as switch_seconds,
       log_archived.during_secs,
       log_archived.redo_mb,
       log_archived.archive_mb,
       log_archived.rate, 'Unnecessary Redo Log switch' as type  
from
(select thread#,sequence#,first_time,seconds
  from 
		  (
			select thread#,sequence#, to_char(first_time,'yyyymmdd_hh24:mi:ss') first_time,
			       round((first_time-lag(first_time) over(partition by thread# order by first_time))*24*60*60,2) Seconds
			        from V\$log_history
			  where first_time between sysdate -10 and sysdate 
	   	            and to_char(first_time,'hh24:mi:ss') between '08:00:00'and '18:00:00'
 			)
		where seconds < 60	) log_switch  ,
(
select thread#,sequence#,first_time,during_secs,archive_mb ,redo_mb,round(archive_mb/redo_mb,2) as rate
from (	   
				select thread#,sequence#,to_char(first_time,'yyyymmdd_hh24:mi:ss') first_time,
				       round(blocks*block_size/1024/1024,0) as archive_mb,
				       (select max(bytes/1024/1024) from V\$log) as redo_mb,
				       round((next_time - first_time)*1440*60) as during_secs
				from V\$archived_log
				where first_time between sysdate -10 and sysdate 
                                  and to_char(first_time,'hh24:mi:ss') between '08:00:00' and '18:00:00' 
  )) log_archived
where log_switch.thread# =  log_archived.thread#
  and log_switch.sequence# = log_archived.sequence#
  and log_archived.archive_mb <= 3 
  and log_archived.during_secs < 300
union
select log_switch.thread#,
       log_switch.sequence#,
       log_switch.first_time,
       log_switch.seconds as switch_seconds,
       log_archived.during_secs,
       log_archived.redo_mb,
       log_archived.archive_mb,
       log_archived.rate,'Redo Log switch frequently' as type
from
(select thread#,sequence#,first_time,seconds
  from 
		  (
			select thread#,sequence#, to_char(first_time,'yyyymmdd_hh24:mi:ss') first_time,
			       round((first_time-lag(first_time) over(partition by thread# order by first_time))*24*60*60,2) Seconds
			        from V\$log_history
			  where first_time between sysdate -10 and sysdate 
                            and to_char(first_time,'hh24:mi:ss') between '08:00:00' and '18:00:00'
			)
		where seconds < 90	) log_switch  ,
(
select thread#,sequence#,first_time,during_secs,archive_mb ,redo_mb,round(archive_mb/redo_mb,2) as rate
from (	   
				select thread#,sequence#,to_char(first_time,'yyyymmdd_hh24:mi:ss') first_time,
				       round(blocks*block_size/1024/1024,0) as archive_mb,
				       (select max(bytes/1024/1024) from V\$log) as redo_mb,
				       round((next_time - first_time)*1440*60) as during_secs
				from V\$archived_log
				where first_time between sysdate -10 and sysdate 
                                  and to_char(first_time,'hh24:mi:ss') between '08:00:00' and '18:00:00'
    )) log_archived
where log_switch.thread# =  log_archived.thread#
  and log_switch.sequence# = log_archived.sequence#
  and log_archived.rate > 0.8
  and log_archived.during_secs <= 90 ) order by 1,2
;

exit
EOF



