set lines 200
set pages 1000

col comm format a200                   
SELECT dbms_sqltune.report_sql_monitor(
sql_id => '&sql_id',             
report_level => 'ALL',                 
type=>'TEXT'                           
) comm                                 
FROM dual;                             