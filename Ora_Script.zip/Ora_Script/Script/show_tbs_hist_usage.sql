
set lines 200 pages 1000
col tbs_name format a36
select a.rtime,
       b.name tbs_name,
       round(a.TABLESPACE_USEDSIZE*c.block_size/1024/1024,0) as used_mb
 from DBA_HIST_TBSPC_SPACE_USAGE a ,
      v$tablespace b,
      dba_tablespaces c
 where a.tablespace_id = b.ts#
   and b.name =  c.tablespace_name
   and c.contents = 'PERMANENT'
 order by b.name,a.rtime ;
 --
select S.SNAP_ID,
               T.NAME,
               S.RTIME,
               (TABLESPACE_USEDSIZE - LAG(TABLESPACE_USEDSIZE, 1, NULL)
                OVER(ORDER BY S.SNAP_ID)) AS DIFF
          from V$TABLESPACE T, DBA_HIST_TBSPC_SPACE_USAGE S
         where T.TS# = S.TABLESPACE_ID
           and T.name = 'TS_TEST01'
           and RTIME >= '08/08/2008 18:00:00' ;
 