 EXEC DBMS_STATS.COPY_TABLE_STATS (upper('&Owner'), upper('&Table_Name'), Upper('&Part_From'), Upper('&Part_TO'), FORCE=>TRUE);
