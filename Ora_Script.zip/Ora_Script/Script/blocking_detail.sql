set linesize 200 pagesize 1000
col event for a40
select inst_id,
       sid,
       serial#,
       paddr,
       sql_id,
       event,
       state,
       seconds_in_wait,
       p1,
       p1raw,
       p2,
       blocking_instance,
       blocking_session
  from gv$session
 where blocking_session is not null
 order by blocking_instance,blocking_session,inst_id,seconds_in_wait ;