
alter session set nls_date_format='yyyymmdd hh24:mi:ss' ;
set lines 200
select dbid,
       name,
       created,
       log_mode,
       force_logging,
       SUPPLEMENTAL_LOG_DATA_ALL,
       DATABASE_ROLE,
       PROTECTION_MODE,
       PROTECTION_LEVEL
  from v$database ;
 
 col controlfile_name format a64
 select name as controlfile_name from v$controlfile ;
 
 select thread#,
        group#,
        sequence#,
        members,
        status,
        ARCHIVED,
        bytes/1024/1024 as size_MB
   from v$log
   order by thread#,group# ;
     
 
 select SNAP_INTERVAL,RETENTION from dba_hist_wr_control ;  
 
 
COLUMN banner   FORMAT a120   HEADING 'Banner'

SELECT * FROM v$version; 
 
set pages 1000
col parameter_name format a40
col parameter_value format a60
select name as parameter_name,
       value as parameter_value 
  from v$parameter ;     