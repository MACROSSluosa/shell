set lines 200 pages 1000

col KGLNAOWN for a10 
col KGLNAOBJ for a60
SELECT KGLNAOWN,KGLNAOBJ
    FROM x$kglob
   WHERE kglhdadr in( select P1RAW from v$session_wait where event like 'library cache lock%');
prompt "--------------------------------------------------------------------------------------"
  select sid, program ,machine from v$session where paddr in (
       SELECT s.paddr
        FROM x$kglpn p, v$session s
       WHERE p.kglpnuse=s.saddr(+) AND p.kglpnmod <> 0
   and kglpnhdl in ( select p1raw  from v$session_wait where event  in ('library cache pin','library cache lock','library cache load lock')));

