set lines 200 pages 1000
col program format a30
col terminal format a24
col bgproc format a8
col spid format a8
select spid,
       addr,
       program,
       decode(BACKGROUND,1,'Y','N') AS BGPROC,
       round(PGA_USED_MEM/1024/1024,2) as PGA_USED_MEM,
       round(PGA_ALLOC_MEM/1024/1024,2) as PGA_ALLOC_MEM,
       round(PGA_MAX_MEM/1024/1024,2) as PGA_MAX_MEM,
       terminal
  from v$process
order by 5,1 ;
  