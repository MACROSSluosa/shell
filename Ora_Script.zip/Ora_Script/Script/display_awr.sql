set linesize 200 pagesize 1000
col sql_id new_value sql_id noprint
select '&sql_id' sql_id from dual;




prompt
prompt
prompt "----------------------"
prompt "display cursor"
prompt "----------------------"
select * from table(dbms_xplan.display_cursor('&sql_id',&sql_child_number,'ADVANCED'));

prompt
prompt
prompt "----------------------"
prompt "display cursor peeked binds"
prompt "----------------------"
select * from table(dbms_xplan.display_awr('&sql_id',null,null,'PEEKED_BINDS'));

prompt
prompt  parsing_schema_name
select parsing_schema_name from dba_hist_sqlstat where sql_id = '&sql_id' and rownum < 3;


prompt
prompt
prompt "----------------------"
prompt "sql hist stat"
prompt "----------------------"
set lines 200
set pages 1000
col shijian for a12
col execu_d for 999999
col bg_d for 9999999999
col dr_d for 9999999999
col et_d for 99999999
col ct_d for 99999999
col io_time for 999999
col clus_time for 999999
col ap_time for 999999
col cc_time for 999999
col et_onetime for 999999
select 
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') shijian,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(IOWAIT_DELTA/1000000) io_time,
    sum(CLWAIT_DELTA/1000000) clus_time,
    sum(APWAIT_DELTA/1000000) ap_time,
    sum(ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from     
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where 
    a.SNAP_ID =b.SNAP_ID
and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
and a.sql_id='&sql_id' 
group by 
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
 order by 1;

prompt
prompt
prompt "----------------------"
prompt "display awr"
prompt "----------------------"

select * from table(dbms_xplan.display_awr('&sql_id'));




prompt
prompt
prompt "----------------------"
prompt "extrace bind variable"
prompt "----------------------"
   
set linesize 500 pagesize 1000
col bind1 for a20
col bind2 for a22
col bind3 for a20
col bind4 for a20
col bind5 for a20
col bind6 for a20
col bind7 for a20
col bind8 for a20
col bind9 for a20
col bind10 for a20
col bind11 for a20
col bind12 for a20
col bind13 for a20
col bind14 for a20
col bind15 for a20
col bind16 for a20
col bind17 for a20
col bind18 for a20
col bind19 for a20
col bind20 for a20

select 
snap_id,
dbms_sqltune.extract_bind(bind_data,1).value_string bind1,
dbms_sqltune.extract_bind(bind_data,2).value_string bind2,
dbms_sqltune.extract_bind(bind_data,3).value_string bind3,
dbms_sqltune.extract_bind(bind_data,4).value_string bind4,
dbms_sqltune.extract_bind(bind_data,5).value_string bind5,
dbms_sqltune.extract_bind(bind_data,6).value_string bind6,
dbms_sqltune.extract_bind(bind_data,7).value_string bind7,
dbms_sqltune.extract_bind(bind_data,8).value_string bind8,
dbms_sqltune.extract_bind(bind_data,9).value_string bind9,
dbms_sqltune.extract_bind(bind_data,10).value_string bind10,
dbms_sqltune.extract_bind(bind_data,11).value_string bind11,
dbms_sqltune.extract_bind(bind_data,12).value_string bind12,
dbms_sqltune.extract_bind(bind_data,13).value_string bind13,
dbms_sqltune.extract_bind(bind_data,14).value_string bind14,
dbms_sqltune.extract_bind(bind_data,15).value_string bind15,
dbms_sqltune.extract_bind(bind_data,16).value_string bind16,
dbms_sqltune.extract_bind(bind_data,17).value_string bind17,
dbms_sqltune.extract_bind(bind_data,18).value_string bind18,
dbms_sqltune.extract_bind(bind_data,19).value_string bind19,
dbms_sqltune.extract_bind(bind_data,20).value_string bind20
from dba_hist_sqlstat
where sql_id='&sql_id'
order by snap_id;
prompt "---------------------------"
prompt "Hist sql execute plan hash value"
prompt "--------------------------"
col start_time format a20
col parname format a12
select a.instance_number as inst,
       to_char(a.startup_time,'yyyymmdd hh24:mi:ss') as start_time,
      a.snap_id,
      b.parsing_schema_name as parname,
       b.plan_hash_value
from dba_hist_snapshot a,dba_hist_sqlstat b
where a.instance_number = b.instance_number
  and a.snap_id = b.snap_id
  and b.sql_id = '&sql_id'
  and a.startup_time >= sysdate - 7
order by 1,2;


set lines 132;
undefine sql_id;

