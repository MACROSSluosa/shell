oradebug setmypid
oradebug dump systemstate 266
exec dbms_lock.sleep(60);
oradebug dump systemstate 266
oradebug tracefile_name
