select s.sid,
     s.serial#,
     s.sql_id,
     v.usn,
     segment_name,
     r.status, 
     v.rssize/1024/1024 mb
From dba_rollback_segs r, 
     v$rollstat v,
     v$transaction t,
     v$session s
Where r.segment_id = v.usn and 
    v.usn=t.xidusn and 
    t.addr=s.taddr
order by segment_name ;