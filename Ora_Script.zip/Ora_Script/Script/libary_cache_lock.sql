---step 1
select p1raw,event, state,SECONDS_IN_WAIT from v$session where sql_id='9z55cu55w611j' ; 


---step 2 
   SELECT KGLNAOWN,KGLNAOBJ
    FROM x$kglob
   WHERE 
   ---kglhdadr = 'p1raw'
   kglhdadr='07000005CF645ED0';
   
---step 3
---execute in two instance
select inst_id,KGLLKUSE,KGLLKMOD,KGLLKREQ from x$kgllk where KGLNAOBJ='TXS_CNY';

---step 4
select sid,sql_id,event,
state,p1,p2,seconds_in_wait,
machine,program,
to_char(logon_time,'yyyymmdd hh24:mi:ss') 
from v$session where saddr in(
'070000060A2F5BE0');
---saddr = KGLLKUSE of step 3
