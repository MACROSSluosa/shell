oradebug setmypid
oradebug hanganalyze 3
exec dbms_lock.sleep(60)
oradebug hanganalyze 3
oradebug tracefile_name
