set lines 200 pages 999
col owner format a12
col segment_name foramt a24
col segment_type format a12

SELECT
OWNER,
SEGMENT_NAME,
SEGMENT_TYPE
FROM
DBA_EXTENTS
WHERE
FILE_ID = &file_id
AND &block_number 150 BETWEEN BLOCK_ID AND BLOCK_ID+BLOCKS - 1;

undefine file_id
undefine block_number
