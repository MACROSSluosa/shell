set lines 200 pages 1000
col inst_id format 999
col username format a12
col status format a14
col event format a40
prompt "------------------------------"
prompt "Session count"
prompt "------------------------------"
select inst_id,username,status,count(1) from gv$session 
  group by inst_id,username,status
  order by 1,2,4;
prompt
prompt
prompt "------------------------------"
prompt "Session event count"
prompt "------------------------------"

select inst_id,username,event,count(1) from gv$session
group by inst_id,username,event
order by 1,2,4,3;

prompt
prompt
prompt "-------------------------------"
prompt "Session Program count
prompt "-------------------------------"

select inst_id,username,program,count(1) from gv$session
group by inst_id,username,program
order by 1,2,4,3; 

