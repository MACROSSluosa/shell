#!/bin/ksh
export ORACLE_SID=$ORACLE_SID
LOGPATH=/tmp/lirl/Script
LOGFILE=$LOGPATH/Top10Cpu.log

sqlplus -S "/as sysdba" <<EOF >>$LOGFILE
set feedback off
set lines 200 pages 1000
col username format a12
col sql_id format a14
col cpu_used format 999999999
col Mon_time format a18
select * from (
select to_char(sysdate,'yyyymmdd hh24:mi:ss') as Mon_time,
       ss.username,
       ss.sid,
       ss.sql_id ,
       se.value as cpu_used,
       sa.buffer_gets,
       sa.executions,
       sa.disk_reads,
       sa.ELAPSED_TIME
  from v\$session ss,
       v\$sqlarea sa,
       v\$sesstat se,
       V\$statname sn
 where ss.sql_id = sa.sql_id
   and ss.sql_address =  sa.address
   and ss.sql_hash_value = sa.hash_value 
   and ss.sid =  se.sid
   and se.STATISTIC# = sn.STATISTIC#
   and sn.name ='CPU used by this session'
   and sa.executions > 0
   and ss.sql_id is not null 
  order by se.value desc 
) where rownum < 10
 ;
exit;
EOF

file_size=`du -sm $LOGFILE|awk '{print $1}'`

if [ $file_size -gt 4 ]
then
cp $LOGFILE $LOGFILE.`date +"%Y%m%d%H%M"`
>$LOGFILE
fi

find $LOGPATH -name "Top10Cpu*log*" -mtime +30 -exec rm {} \;


