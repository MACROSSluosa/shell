set linesize 200 pagesize 1000
alter session set nls_date_format = 'yyyymmdd hh24:mi:ss';
select timestamp,plan_hash_value from dba_hist_sql_plan where sql_id='&sql_id';
