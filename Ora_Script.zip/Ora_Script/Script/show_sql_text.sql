

set lines 200 pages 2000
set long 10000
col sql_id new_value new_sql_id;
select '&sql_id' sql_id from dual;

prompt From dba_hist_sqltext
select sql_text from dba_hist_sqltext where sql_id = '&new_sql_id';

prompt =======================================================
prompt From v$sqltext

select sql_text from v$sqltext where sql_id = '&new_sql_id' order by piece;

undefine sql_id;

