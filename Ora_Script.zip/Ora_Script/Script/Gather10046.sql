oradebug setospid &os_process_id
oradebug event 10046 trace name context forever,level 12
exec dbms_lock.sleep(&seconds_to_collect);
oradebug event 10046 trace name context off
oradebug tracefile_name
