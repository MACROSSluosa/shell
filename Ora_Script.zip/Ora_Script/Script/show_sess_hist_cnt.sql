set lines 132
col inst format 9999
col sess_cnt format 9999
col sample_time format a20

select  instance_number as inst,
         to_char(sample_time,'yyyymmdd hh24:mi')  as sample_time,
         count(distinct session_id||session_serial#)  as sess_cnt
      from dba_hist_active_sess_history 
    where to_char(sample_time,'yyyymmdd hh24mi')  >='&start_time'
       and to_char(sample_time,'yyyymmdd hh24mi')  <='&end_time'
      group by instance_number,to_char(sample_time,'yyyymmdd hh24:mi') 
     order by 2,1;
 
undefine start_time
undefine end_time
     

