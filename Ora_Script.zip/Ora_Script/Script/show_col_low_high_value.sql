select a.column_name, 
       a.partition_name,
       a.num_distinct,
       display_raw(a.low_value,b.data_type) as low_val,
       display_raw(a.high_value,b.data_type) as high_val,
       b.data_type
  from
     dba_part_col_statistics a,
     dba_tab_cols b
  where
    a.owner='&Owner' and
    a.owner='b.owner and 
    a.table_name='&Table_Name' and
    a.table_name=b.table_name and
    a.column_name=b.column_name and
    a.column_name = '&Column_Name' and
    a.low_value is not null
 order by 1, 2
;

