set linesize 200 pagesize 1000
prompt  "-------------------------------------------"
prompt "|Please check the state of datapump jobs....|"
prompt  "-------------------------------------------"
select * from dba_datapump_jobs order by state;

prompt "-------------------------------------------"
prompt "|the session used by datapump jobs.........|"
prompt  "-------------------------------------------"
select * from dba_datapump_sessions;