set lines 200 pages 1000
col sess format a18
col username format a12
col sql_id format a18
select s.inst_id||','||s.sid||','||s.serial# as sess, 
       s.username,
       s.sql_id||','||s.sql_child_number as sql_id, 
       S.STATUS,
       t.used_urec, 
       t.used_ublk,
       t.start_time,
       t.addr as t_addr
 from gv$session s, gv$transaction t
where s.inst_id =  t.inst_id
  and s.saddr = t.ses_addr
     order by t.used_ublk desc;
     