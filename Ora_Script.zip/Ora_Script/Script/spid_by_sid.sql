 set linesize 200 pagesize 1000
 col program for a80
 select b.spid, a.program
   from v$session a, v$process b
  where a.paddr = b.addr
    and a.sid = &sid ;