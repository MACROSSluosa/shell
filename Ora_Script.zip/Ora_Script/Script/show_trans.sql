set lines 200
set pages 1000

col sid format 9999
col username format a10
col trans_id format a13
col start_time format a15
col used_ublk heading 'used|undo|blocks' format 999999
col used_urec heading 'used|undo|records' format 999999
col log_io heading 'logical|io' format 99999999
col phy_io heading 'physical|io' format 99999999
col cr_get heading 'consistent|gets' format 999999999
select b.inst_id,b.sid,b.username,a.xidusn||'.'||a.xidslot||'.'||a.xidsqn trans_id,a.start_time,
        a.used_ublk,a.used_urec,a.log_io,a.phy_io,a.cr_get,
       decode(b.sql_hash_value,'00',prev_hash_value,sql_hash_value) hash_value,
       decode(b.sql_hash_value,'00',prev_sql_addr,sql_address) address
from gv$transaction a,gv$session b
where a.addr = b.taddr and a.inst_id=b.inst_id
order by 1;

