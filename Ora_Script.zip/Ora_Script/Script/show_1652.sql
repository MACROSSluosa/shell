set lines 200 pages 3000
col sql_id format a13
col sql_text format a120
SELECT  SQL_ID,
   TO_CHAR(SUBSTR(b.sql_text,1,4000)) as sql_text
     FROM sys.WRH$_SQLTEXT b
    WHERE b.sql_id IN
    (SELECT sql_id
       FROM
      (SELECT a.sql_id
         FROM sys.WRH$_SQLSTAT a
        WHERE a.parsing_schema_name NOT IN ('SYS')
      AND a.executions_total             >0
      AND a.direct_writes_total          >0
      AND a.SNAP_ID                     IN
        (SELECT SNAP_ID
           FROM sys.WRM$_SNAPSHOT
          WHERE to_date('&start_time','yyyymmdd hh24mi') BETWEEN begin_interval_time AND end_interval_time
        )
     ORDER BY a.direct_writes_total/ a.executions_total DESC
      )
      WHERE rownum<=10
    );
undefine start_time
