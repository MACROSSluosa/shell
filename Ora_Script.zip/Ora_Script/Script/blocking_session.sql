select blocking_instance, blocking_session, count(*)
  from gv$session
 where blocking_session is not null
 group by blocking_instance, blocking_session
 order by 1, 3;