--�鿴��־�ļ��л����
alter session set nls_date_format = 'yyyymmdd hh24:mi:ss';
set lines 200 pages 1000
col thread# format 99
col sequence# format 9999999 
col begin_date new_value begin_date
col end_date new_value end_date

select '&begin_date' begin_date,'&end_date' end_date from dual;

prompt Log switch:
select thread#,sequence#, to_char(first_time,'yyyymmdd_hh24:mi:ss') first_time,
       round((first_time-lag(first_time) over(partition by thread# order by first_time))*24*60,2) minutes
   from v$log_history
  where to_char(first_time,'yyyymmdd') >='&begin_date' and to_char(first_time,'yyyymmdd') <= '&end_date'
   order by thread#,first_time;

prompt Log archived:

select thread#, sequence#,first_time, next_time,completion_time,
round((next_time - first_time)*1440)  "online_using_time_MIN",
round((completion_time-next_time)*1440*60)  "archiving_time_S",
round(blocks*block_size/1024/1024,0) as size_mb
from V$archived_Log
where to_char(first_time,'yyyymmdd') >='&begin_date' and to_char(first_time,'yyyymmdd') <= '&end_date'
order by 1,2
;




