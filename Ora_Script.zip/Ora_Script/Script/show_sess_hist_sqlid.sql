set lines 200 pages 2000
col start_time new_value start_time
col end_time new_value end_time
col sql_id new_value sql_id
select '&start_time' as start_time,'&end_time' as end_time,'&sql_id' as sql_id  from dual;

COL BEGIN_SNAP_ID NEW_VALUE BEGIN_SNAP_ID noprint
COL END_SNAP_ID NEW_VALUE END_SNAP_ID noprint
SELECT (MAX(SNAP_ID) -1)  AS BEGIN_SNAP_ID
FROM WRM$_SNAPSHOT 
WHERE TO_CHAR(BEGIN_INTERVAL_TIME,'YYYYMMDDHH24MI') <= '&START_TIME'
  AND INSTANCE_NUMBER = (SELECT INSTANCE_NUMBER FROM V$INSTANCE WHERE ROWNUM <2) ;

col to_time new_value to_time noprint  
select to_char(to_date('&end_time','yyyymmddhh24mi')+1/24,'yyyymmddhh24mi') as to_time from dual;

SELECT (min(SNAP_ID)+1) AS END_SNAP_ID
FROM WRM$_SNAPSHOT 
WHERE TO_CHAR(BEGIN_INTERVAL_TIME,'YYYYMMDDHH24MI') > '&START_TIME'
  AND TO_CHAR(BEGIN_INTERVAL_TIME,'YYYYMMDDHH24MI') <= '&to_TIME'
  AND INSTANCE_NUMBER = (SELECT INSTANCE_NUMBER FROM V$INSTANCE WHERE ROWNUM <2) ;  

col sample_time format  a18;
col event format a24;
col session_id format 99999999
col inst format 9999
col time_waited format 99999999
col sess format a16
col sql_id format a14
select to_char(sample_time,'yyyymmdd hh24:mi:ss') as sample_time,
       session_id||'-'||session_serial# as sess,
     sql_id,
      event,
      p1,
      p2,
      time_waited
from dba_hist_active_sess_history 
where instance_number = (select instance_number from v$instance)
 and snap_id between &BEGIN_SNAP_ID and &END_SNAP_ID
 and to_char(sample_time,'yyyymmddhh24mi') >= '&start_time'
 and to_char(sample_time,'yyyymmddhh24mi') <= '&end_time'
 and sql_id = '&sql_id'
order by 1;
undefine sql_id
undefine start_time
undefine end_time
undefine session_id
undefine begin_snap_id
undefine end_snap_id
undefine to_time
