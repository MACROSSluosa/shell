set linesize 200 pagesize 1000
select a.inst_id,
       a.sid,
       a.type,
       a.lmode,
       a.request,
       a.id1,
       a.id2,
       a.block,
       decode(a.request, 0, 'Holder', 'Waiter') description
  from gv$lock a, (select id1, id2 from gv$lock b where block = 1) b
 where a.id1 = b.id1
   and a.id2 = b.id2
 order by a.id1,a.id2,description