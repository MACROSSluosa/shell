set linesize 200 pagesize 1000
col bind1 for a30
col bind2 for a30
col bind3 for a30
col bind4 for a30
col bind5 for a30
col bind6 for a30

select 
snap_id,
dbms_sqltune.extract_bind(bind_data,1).value_string bind1,
dbms_sqltune.extract_bind(bind_data,2).value_string bind2
from dba_hist_sqlstat
where sql_id='&sql_id'
order by snap_id;