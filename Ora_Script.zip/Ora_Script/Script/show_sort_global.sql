set lines 200
col tablespace_name format a18
select a.inst_id, 
           a.tablespace_name, 
           round(a.total_blocks*b.block_size/1024/1024,0) as totabl_mb, 
           round(a.used_blocks*b.block_size/1024/1024,0) as used_mb, 
           round(a.free_blocks*b.block_size/1024/1024,0) as free_mb
from gv$sort_segment a,dba_tablespaces b
where a.tablespace_name =  b.tablespace_name  ;

