set lines 200
set pages 100
col tablespace_name format a36
col fsfi format 999999.99
select a.tablespace_name,sqrt(max(a.blocks)/sum(a.blocks))*(100/sqrt(sqrt(count(a.blocks)))) FSFI
from dba_free_space a,dba_tablespaces b
where a.tablespace_name=b.tablespace_name
and b.contents not in ('TEMPORARY','UNDO')
group by a.tablespace_name 
order by 2;