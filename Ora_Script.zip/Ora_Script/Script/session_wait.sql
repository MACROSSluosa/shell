set linesize 200 pagesize 1000
col event for a80
select inst_id, event, count(*)
  from gv$session
 where event not like '%SQL%'
   and event not like '%Stream%'
   and event not like '%rdbms%'
   and event not like '%timer%'
   and event not like '%idle%'
 group by inst_id, event
 order by 1, 3;
