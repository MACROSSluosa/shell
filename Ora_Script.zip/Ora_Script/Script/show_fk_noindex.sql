
select 'Database has a ForeignKey without Index: '||owner||'.'||table_name
  from (SELECT /*+ rule */
         acc.owner, acc.table_name, acc.column_name, acc.position
          FROM dba_cons_columns acc, dba_constraints ac
         WHERE ac.constraint_name = acc.constraint_name
           AND ac.constraint_type = 'R'
           and ac.owner  in
               (select /*+ no_merge */
                 username
                  from dba_users
                 where default_tablespace not in
                       ('SYSTEM', 'SYSAUX', 'USERS'))
        MINUS
        SELECT /*+ rule */
         table_owner owner, table_name, column_name, column_position
          FROM dba_ind_columns
         where index_owner  in
               (select /*+ no_merge */
                 username
                  from dba_users
                 where default_tablespace not in
                       ('SYSTEM', 'SYSAUX', 'USERS')))
 ORDER BY owner,table_name, position, column_name;

