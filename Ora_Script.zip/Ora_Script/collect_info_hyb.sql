set pagesize 100
set echo on
set feedback on
col report_name new_val report_name noprint

select '/tmp/'||host_name||'_'||instance_name||'_'||to_char(sysdate,'yyyymmdd')||'.html' report_name from v$instance;
set markup html on
spool &report_name
alter session set nls_date_format='yyyymmdd hh24:mi:ss';
select * from v$version;
select dbid,name,platform_name,log_mode,controlfile_type,open_mode,protection_mode,protection_level,database_role from v$database;
select * from nls_database_parameters where parameter like '%CHARACTERSET%';
select inst_id,name,value from gv$parameter where name in('cluster_database','cluster_database_instances','db_block_size','cpu_count');
select inst_id,name,value from gv$parameter where isdefault ='FALSE' order by name;
select username,account_status,created,default_tablespace,temporary_tablespace from dba_users order by created;
select round(sum(bytes)/1024/1024/1024,1) size_g from dba_data_files;
select tablespace_name,sum(bytes)/1024/1024 from dba_data_files group by tablespace_name order by 2;
select tablespace_name,sum(bytes)/1024/1024 from dba_free_space group by tablespace_name order by 2;
select round(sum(bytes)/1024/1024/1024,1) size_g from dba_segments;
select file_name,file_id,tablespace_name,round(bytes/1024/1024,1) size_m,autoextensible,round(maxbytes/1024/1024,1) max_m,online_status from dba_data_files order by tablespace_name,file_id;
select * from v$recover_file;
select owner, object_type, count(*)
  from dba_objects
 where owner not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX'))
 group by owner, object_type
 order by 1, 3;
select owner, segment_type, round(sum(bytes) / 1024 / 1024, 1) size_m
  from dba_segments
 where owner not in
       (select username
          from dba_users
         where default_tablespace in ('SYSTEM', 'SYSAUX'))
 group by owner, segment_type
 order by 1, 3;
select * from dba_registry;
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
  from dba_tablespaces a,
       (select d.tablespace_name tablespace_name,
               round((d.sumbytes / 1024 / 1024), 2) total_m,
               round(decode(f.sumbytes, null, 0, f.sumbytes) / 1024 / 1024,
                     2) free_m,
               round(((d.sumbytes - decode(f.sumbytes, null, 0, f.sumbytes)) / 1024 / 1024),
                     2) used_m,
               round((d.sumbytes - decode(f.sumbytes, null, 0, f.sumbytes)) * 100 /
                     d.sumbytes,
                     2) used_pct
          from (select tablespace_name, sum(bytes) sumbytes
                  from dba_free_space
                 group by tablespace_name) f,
               (select tablespace_name, sum(bytes) sumbytes
                  from dba_data_files
                 group by tablespace_name) d
         where f.tablespace_name(+) = d.tablespace_name
         order by d.tablespace_name) b
 where a.tablespace_name = b.tablespace_name
union all
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
  from dba_tablespaces a,
       (select d.tablespace_name tablespace_name,
               round((d.sumbytes / 1024 / 1024), 2) total_m,
               round((d.sumbytes / 1024 / 1024), 2) -
               round(decode(f.sumbytes, null, 0, f.sumbytes) / 1024 / 1024,
                     2) free_m,
               round(decode(f.sumbytes, null, 0, f.sumbytes) / 1024 / 1024,
                     2) used_m,
               round(decode(f.sumbytes, null, 0, f.sumbytes) * 100 /
                     d.sumbytes,
                     2) used_pct
          from (select tablespace_name, sum(bytes_used) sumbytes
                  from v$temp_extent_pool
                 group by tablespace_name) f,
               (select tablespace_name, sum(bytes) sumbytes
                  from dba_temp_files
                 group by tablespace_name) d
         where f.tablespace_name(+) = d.tablespace_name
         order by d.tablespace_name) b
 where a.tablespace_name = b.tablespace_name
 order by 5;
 
select * from v$osstat;
spool off
undefine report_name
exit;