#!/bin/sh
##################################
##first argument:  begin  snap id
##second argunetb: end    snap id
##################################

if [ ! -n "$1" ]
then
echo "Pls input begin snap id"
exit
fi

if [ ! -n "$2" ]
then
echo "Pls input end snap id"
exit
fi

if [ ! "$1" -ge 0 ]
then
echo "Pls input begin snap id"
exit
fi

if [ ! "$2" -ge 0 ]
then
echo "Pls input end snap id"
exit
fi

if [ ! $1 > $2 ]
then
echo "begin snap id should greater then end snap id"
exit
fi

BEGIN_SNAP_ID=$1
END_SNAP_ID=$2

ROW_NUM_THRESHOLD=31
BUFFER_GETS_THRESHOLD=100
DISK_READS_THRESHOLD=100


DT=`date "+%Y%m%d_%H"`
LOGIN_NAME="/ as sysdba"

INSTNAME=`sqlplus -s ${LOGIN_NAME} <<EOF
SET FEEDBACK OFF
SET PAGES 0
select instance_name from v\\\$instance;
EOF`

if [ $? -lt 0 ]
then
echo "The script encounterd error,will exit"
exit
fi



DBID=`sqlplus -s ${LOGIN_NAME} <<EOF
SET FEEDBACK OFF
SET PAGES 0
select dbid from v\\\$database;
EOF`

INST_NUMBER=`sqlplus -s ${LOGIN_NAME} <<EOF
SET FEEDBACK OFF
SET PAGES 0
select instance_number from v\\\$instance;
EOF`

INST_NUMBER=`echo ${INST_NUMBER} |sed -e 's/^[ \t ]*/'`

FILENAME=TopSql_all_info_${INSTNAME}_${BEGIN_SNAP_ID}_${END_SNAP_ID}.log
>${FILENAME}

if [ $? -lt 0 ]
then
echo "The script encounterd error,will exit"
exit
fi


echo "#################################################" >>${FILENAME}
echo "## DB base info "                                  >>${FILENAME} 
echo "#################################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF
set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col name format a40
col value format a80
col describ format a40

spool ${FILENAME} append
prompt DB version
select * from v\$version;

prompt
prompt parameter is not default
prompt
select NAME,VALUE from v\$parameter where value is not null and isdefault='FALSE';

prompt
prompt Important hidden parameter 
prompt
SELECT x.ksppinm NAME, 
       y.ksppstvl VALUE, 
       x.ksppdesc describ
  FROM SYS.x\$ksppi x, 
       SYS.x\$ksppcv y
WHERE x.inst_id = USERENV ('Instance')
  AND y.inst_id = USERENV ('Instance')
  AND x.indx = y.indx
  AND ( x.ksppinm LIKE '%optimizer_use_feedback%' or
        x.ksppinm LIKE '%use_adaptive_log_file_sync%' or
        x.ksppinm LIKE '%px_use_large_pool%' or
        x.ksppinm LIKE '%undo_autotune%' or
        x.ksppinm LIKE '%gc_policy_time%' or
        x.ksppinm LIKE '%gc_undo_affinity%' or
        x.ksppinm LIKE '%gc_defer_time%' or
        x.ksppinm LIKE '%_gc_affinity%' or
        x.ksppinm LIKE '%optimizer_adaptive_cursor_sharing%' or
        x.ksppinm LIKE '%optimizer_extended_cursor_sharing%' or
        x.ksppinm LIKE '%optimizer_extended_cursor_sharing_rel%' 
       );

prompt
prompt resource limit
prompt       
select * from v\$resource_limit;

spool off

EOF


echo "   " >>${FILENAME}
echo "#################################################" >>${FILENAME}
echo "## TOP SQL "                                       >>${FILENAME} 
echo "#################################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF

set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col sql_id format a20

spool ${FILENAME} append
prompt top sql with most buffer gets
select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.BUFFER_GETS_DELTA ) > ${BUFFER_GETS_THRESHOLD}
 order by 5 desc) where rownum <   ${ROW_NUM_THRESHOLD}
;

prompt
prompt Top sql with most disk reads
prompt

select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.DISK_READS_DELTA ) > ${DISK_READS_THRESHOLD}
 order by 6 desc) where rownum <  ${ROW_NUM_THRESHOLD}
;

prompt
prompt Top sql with most time elasped
prompt

select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.ELAPSED_TIME_DELTA ) > 600
 order by 7 desc) where rownum <  ${ROW_NUM_THRESHOLD}
;


prompt
prompt Top sql with most time executions
prompt

select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.EXECUTIONS_DELTA ) > 50
 order by 4 desc) where rownum <  ${ROW_NUM_THRESHOLD}
;
spool off
EOF

grep "SQL: " ${FILENAME}  |awk -F ':' '{print $2}'  |awk '{print $1}' |sort -u >topsql_id.tmp

echo " " >show_sql_text.sql
echo " " >show_sql_plan.sql
echo " " >extract_binds.sql
echo " " >show_sql_object.sql
echo " " >report_sql_monitor.sql
echo " " >get_ddl.sql
echo " " >sql_session_info.sql

echo "select sql_id,sql_text from dba_hist_sqltext where sql_id in ("  >>show_sql_text.sql

echo "select distinct object_owner,object_name from dba_hist_sql_plan " >>show_sql_object.sql
echo "where operation like '%TABLE%' and object_type like '%TABLE%' and sql_id in(" >>show_sql_object.sql

echo "col bind1 for a20"   >>extract_binds.sql  
echo "col bind2 for a22"   >>extract_binds.sql
echo "col bind3 for a20"   >>extract_binds.sql
echo "col bind4 for a20"   >>extract_binds.sql
echo "col bind5 for a20"   >>extract_binds.sql
echo "col bind6 for a20"   >>extract_binds.sql
echo "col bind7 for a20"   >>extract_binds.sql
echo "col bind8 for a20"   >>extract_binds.sql
echo "col bind9 for a20"   >>extract_binds.sql
echo "col bind10 for a20"  >>extract_binds.sql
echo "col bind11 for a20"  >>extract_binds.sql
echo "col bind12 for a20"  >>extract_binds.sql
echo "col bind13 for a20"  >>extract_binds.sql
echo "col bind14 for a20"  >>extract_binds.sql
echo "col bind15 for a20"  >>extract_binds.sql
echo "col bind16 for a20"  >>extract_binds.sql
echo "col bind17 for a20"  >>extract_binds.sql
echo "col bind18 for a20"  >>extract_binds.sql
echo "col bind19 for a20"  >>extract_binds.sql
echo "col bind20 for a20"  >>extract_binds.sql
echo "    "                >>extract_binds.sql


cat topsql_id.tmp |while read line
do
echo "'$line',">>show_sql_text.sql
echo "'$line',">>show_sql_object.sql

echo "select * from table (dbms_xplan.display_cursor('$line',0,'allstats last advanced'));" >>show_sql_plan.sql
echo "select * from table (dbms_xplan.display_awr('$line',null,null,'PEEKED_BINDS'));" >>show_sql_plan.sql

echo "prompt"                       >>sql_session_info.sql
echo "select distinct sql_id,program,module,machine " >>sql_session_info.sql
echo "from dba_hist_active_sess_history where sql_id ='$line'" >>sql_session_info.sql 
echo "and snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID};" >>sql_session_info.sql
echo  "prompt"                                                 >>sql_session_info.sql


echo "select"                                                       >>extract_binds.sql
echo "sql_id,snap_id,"                                              >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,1).value_string   bind1," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,2).value_string   bind2," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,3).value_string   bind3," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,4).value_string   bind4," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,5).value_string   bind5," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,6).value_string   bind6," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,7).value_string   bind7," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,8).value_string   bind8," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,9).value_string   bind9," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,10).value_string bind10," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,11).value_string bind11," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,12).value_string bind12," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,13).value_string bind13," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,14).value_string bind14," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,15).value_string bind15," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,16).value_string bind16," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,17).value_string bind17," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,18).value_string bind18," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,19).value_string bind19," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,20).value_string bind20 " >>extract_binds.sql
echo "from dba_hist_sqlstat"                                        >>extract_binds.sql
echo "where sql_id='$line'"                                         >>extract_binds.sql
echo "order by snap_id;"                                            >>extract_binds.sql 
echo "   "                                                          >>extract_binds.sql
echo "prompt ${line}_monitor_report " >>report_sql_monitor.sql
echo "select dbms_sqltune.report_sql_monitor(type=>'TEXT', sql_id=>lower('$line'),report_level=>'ALL') from dual;" >>report_sql_monitor.sql
echo " " >>report_sql_monitor.sql
done

echo "'00');" >>show_sql_text.sql
echo "'00');" >>show_sql_object.sql

echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## SQL TEXT:"                               >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col sql_id format a20

spool ${FILENAME} append
@show_sql_text.sql
spool off
EOF1


echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## Execut Plan for TopSql"                  >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col sql_id format a20

spool ${FILENAME} append
@show_sql_plan.sql
spool off
EOF1

echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## SQL report monitor if exist"             >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 0
set linesize 200
set verify    off
set feedback on
set serverout on

spool ${FILENAME} append
@report_sql_monitor.sql
spool off
EOF1



echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## Binding variable for TopSql"             >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col sql_id format a20

spool ${FILENAME} append
@extract_binds.sql
spool off
EOF1



sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 0
set linesize 200
set verify    off
set feedback off
col sql_id format a20

spool sql_object.log 
@show_sql_object.sql
spool off
EOF1


>show_object_detail.sql
cat sql_object.log |while read line
do
TABLE_OWNER=`echo $line |awk '{print $1}'`
TABLE_NAME=`echo $line |awk '{print $2}'`

echo "EXECUTE  DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'STORAGE',FALSE);" >>get_ddl.sql 
echo "  " >>get_ddl.sql
echo "prompt DDL for ${TABLE_OWNER}.${TABLE_NAME}:" >>get_ddl.sql
echo "SELECT DBMS_METADATA.GET_DDL('TABLE','${TABLE_NAME}','${TABLE_OWNER}') FROM DUAL;" >>get_ddl.sql
echo "prompt" >>get_ddl.sql
echo " " >>get_ddl.sql


echo "prompt" >>show_object_detail.sql
echo "prompt  base info"                 >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select owner,object_name,object_id,data_object_id,  " >>show_object_detail.sql 
echo "to_char(created,'yyyymmdd hh24:miss') as created, " >>show_object_detail.sql 
echo "to_char(last_ddl_time,'yyyymmdd hh24:miss') as last_ddl_time " >>show_object_detail.sql 
echo "from dba_objects where owner = upper('${TABLE_OWNER}') " >>show_object_detail.sql 
echo "and object_name =  upper( '${TABLE_NAME}');  " >>show_object_detail.sql 
echo "prompt" >>show_object_detail.sql 
echo "   " >>show_object_detail.sql 


echo "prompt" >>show_object_detail.sql
echo "prompt  segment size (MB)"         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select owner,segment_name,sum(bytes)/1024/1024 size_m from dba_segments "         >>show_object_detail.sql
echo "where owner = upper('${TABLE_OWNER}') and segment_name = upper( '${TABLE_NAME}')" >>show_object_detail.sql
echo "group by owner, segment_name order by 1,2;"                                       >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql

echo "   " >>show_object_detail.sql 
echo "prompt" >>show_object_detail.sql
echo "prompt  Table partition type"         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select owner,table_name,PARTITIONING_TYPE,SUBPARTITIONING_TYPE " >>show_object_detail.sql 
echo "from dba_part_tables where owner = upper('${TABLE_OWNER}') and table_name =upper('$TABLE_NAME'); " >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   "    >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  Partition columns"         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select 'part' type,a.* from dba_part_key_columns a   " >>show_object_detail.sql
echo "where owner= upper('${TABLE_OWNER}') and name= upper('$TABLE_NAME') " >>show_object_detail.sql      
echo "union all     " >>show_object_detail.sql                                                                     
echo "select 'subpart' type,a.* from dba_subpart_key_columns a   " >>show_object_detail.sql
echo "where owner= upper('${TABLE_OWNER}') and name= upper('$TABLE_NAME') ;" >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  table stats"               >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select owner,table_name,num_rows,blocks,avg_row_len, "                  >>show_object_detail.sql
echo "partitioned,to_char(last_analyzed,'yyyymmdd hh24:mi:ss') as analyzed ," >>show_object_detail.sql
echo "num_rows * avg_row_len / 1024 /1024 / 0.9 est_M "                       >>show_object_detail.sql
echo "from dba_tables where owner = upper('${TABLE_OWNER}')"                  >>show_object_detail.sql
echo "and table_name = upper('${TABLE_NAME}');"                               >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  table stats history"       >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select a.owner,a.object_name,to_char(b.ANALYZETIME,'yyyymmdd hh24:mi:ss') as analyzed," >>show_object_detail.sql
echo "b.rowcnt,b.blkcnt from dba_objects a,sys.wri\$_optstat_tab_history b" >>show_object_detail.sql
echo "where a.object_type = 'TABLE'" >>show_object_detail.sql
echo "and a.object_name  = upper('${TABLE_NAME}') and a.owner = upper('${TABLE_OWNER}')" >>show_object_detail.sql
echo "and a.object_id = b.obj# order by 1,2,3;" >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  Index of table"            >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select owner, index_name,index_type,uniqueness,"                        >>show_object_detail.sql
echo "num_rows,to_char(last_analyzed,'yyyymmdd hh24:mi') as analyzed,"        >>show_object_detail.sql
echo "status,partitioned,distinct_keys"                                       >>show_object_detail.sql
echo "from dba_indexes where table_owner=upper('${TABLE_OWNER}')"             >>show_object_detail.sql
echo "and table_name = upper('${TABLE_NAME}') order by 1,2;"                  >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 
            
echo "prompt" >>show_object_detail.sql
echo "prompt  Columns of index "         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select index_owner, index_name,column_name,column_position" >>show_object_detail.sql 
echo "from dba_ind_columns "                                      >>show_object_detail.sql
echo "where table_owner = upper('${TABLE_OWNER}') "               >>show_object_detail.sql
echo "and table_name =upper('${TABLE_NAME}') order by 1,2,4; "    >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  index partition analyzed " >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select index_owner,index_name,partition_name,              ">>show_object_detail.sql
echo "to_char(last_analyzed,'yyyymmdd hh24:mi:ss') as analyzed,  ">>show_object_detail.sql
echo "distinct_keys,num_rows,status"                              >>show_object_detail.sql
echo "from dba_ind_partitions"                                    >>show_object_detail.sql
echo "where index_name  in (select index_name from dba_part_indexes where table_name  = upper('${TABLE_NAME}') )"  >>show_object_detail.sql
echo "order by 1,2,3;"                                           >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  column uniqueness "        >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql 
echo "   " >>show_object_detail.sql 

echo "select OWNER,column_name,num_distinct,histogram,num_nulls, ">>show_object_detail.sql
echo "to_char(last_analyzed,'yyyymmdd hh24:mi') as analyzed "     >>show_object_detail.sql 
echo "from dba_tab_col_statistics "                               >>show_object_detail.sql 
echo "where owner = upper('${TABLE_OWNER}')  and table_name = upper('${TABLE_NAME}') ">>show_object_detail.sql 
echo "order by owner,column_name;  "                              >>show_object_detail.sql 
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql  

echo "prompt" >>show_object_detail.sql
echo "prompt  partiton created "         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select * from (select owner,object_name,subobject_name,object_type,">>show_object_detail.sql
echo "to_char(created,'yyyymmdd hh24:mi') as created                    ">>show_object_detail.sql
echo "from dba_objects where owner = upper('${TABLE_OWNER}')              ">>show_object_detail.sql
echo "and object_name = upper('${TABLE_NAME}')order by 4 desc) where rownum<31; ">>show_object_detail.sql
echo "prompt" >>show_object_detail.sql 
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  partiton stats "         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select table_owner,table_name,partition_name," >>show_object_detail.sql  
echo "to_char(last_analyzed,'yyyymmdd hh24:mi') as analyzed," >>show_object_detail.sql  
echo "num_rows,round(num_rows*avg_row_len/1024/1024) as size_mb " >>show_object_detail.sql  
echo " from dba_tab_partitions where table_owner = upper('${TABLE_OWNER}') " >>show_object_detail.sql  
echo "and table_name = upper('${TABLE_NAME}')" >>show_object_detail.sql  
echo " order by 1,2,3;" >>show_object_detail.sql  
echo "prompt" >>show_object_detail.sql 
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  sub partiton stats "         >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select table_owner,table_name,partition_name,     " >>show_object_detail.sql  
echo "subpartition_name,to_char(last_analyzed,'yyyymmdd hh24:mi') as analyzed,num_rows " >>show_object_detail.sql  
echo "from dba_tab_subpartitions " >>show_object_detail.sql  
echo "where table_owner = upper('${TABLE_OWNER}')  and table_name = upper('${TABLE_NAME}') " >>show_object_detail.sql 
echo "order by 1,2,3;" >>show_object_detail.sql   
echo "prompt" >>show_object_detail.sql 
echo "   " >>show_object_detail.sql 

echo "prompt" >>show_object_detail.sql
echo "prompt  stats locked "             >>show_object_detail.sql
echo "prompt" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

echo "select owner,table_name,PARTITION_NAME,object_type," >>show_object_detail.sql
echo "to_char(LAST_ANALYZED,'yyyymmdd hh24:mi:ss') as last_analyzed, STATTYPE_LOCKED,stale_stats" >>show_object_detail.sql
echo "from DBA_TAB_STATISTICS where owner = upper('${TABLE_OWNER}')  and table_name = upper('${TABLE_NAME}')" >>show_object_detail.sql
echo "and object_type in ('TABLE','PARTITION') order by 1,2,3 ;" >>show_object_detail.sql
echo "   " >>show_object_detail.sql 

done


echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## Table all info :"                        >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 50000
set linesize 280
set long     2000000000
set verify        off
col owner format a16
col table_name format a24
col index_name format a24
col column_name format a24
col analyzed format a20
col created format a20
col object_type format a12
col sql_id format a20
col segment_name format a24
col object_name format a24
col PARTITION_NAME format a20
col SUBOBJECT_NAME format a20
col INDEX_TYPE format a16

spool ${FILENAME} append
@show_object_detail.sql
spool off
EOF1



echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## DDL for tables:"                         >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 0
set linesize 240
set verify    off
set feedback off
set long 2000000

spool ${FILENAME} append
@get_ddl.sql
spool off
EOF1

echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## Session info for sql:"                   >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 1000
set linesize 240
set verify    off
set feedback on
col machine format a36
col program format a40
col module format a36

spool ${FILENAME} append
@sql_session_info.sql
spool off
EOF1

echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## gen awr report:"                         >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set echo off;
set veri off;
set feedback off;
set termout on;
set heading off;
set long 9999999

declare 
i_snap number;
i_snap2 number;
begin
spool TopSql_awrrpt_${BEGIN_SNAP_ID}_${END_SNAP_ID}.html

for i_snap in ${BEGIN_SNAP_ID}..${END_SNAP_ID}
loop
exec i_snap2 := i_snap1 +1;
select output from table(dbms_workload_repository.awr_report_html(${DBID},${INST_NUMBER},i_snap, i_snap2));
end loop;
spool off
end;
/

EOF1



rm -f show_sql_text.sql
rm -f show_sql_plan.sql
rm -f extract_binds.sql
rm -f show_sql_object.sql
rm -f report_sql_monitor.sql
rm -f show_object_detail.sql
rm -f topsql_id.tmp
rm -f sql_object.log
rm -f get_ddl.sql
rm -f sql_session_info.sql


date
echo "  "                                        
echo "##########################################"  
echo "## All Done"
echo "Result file is: "${FILENAME}
echo "##########################################"




































