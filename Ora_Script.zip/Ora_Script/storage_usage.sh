
HOSTNAME=`hostname`
DATE=`date "+%Y%m%d"`

LOGFILE=${HOSTNAME}_${DATE}_storage_usage.log


if [ ! $USER = "root" ]
then
echo "pls run as root"
exit
fi


>${LOGFILE}

chmod 777 ${LOGFILE}

hostname >>${LOGFILE}

/sbin/ifconfig -a >>${LOGFILE}

fdisk -l >>${LOGFILE}

ll /dev/disk/by-path >>${LOGFILE}

/usr/sbin/vgs  >>${LOGFILE}

/usr/sbin/lvs >>${LOGFILE}

df -h >>${LOGFILE}

su -  oracle -c "db_usage.sh"
