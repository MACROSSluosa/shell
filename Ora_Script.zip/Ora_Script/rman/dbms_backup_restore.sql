DECLARE   
v_dev varchar2(50);  
v_done boolean:=false;  
BEGIN   
v_dev:=sys.dbms_backup_restore.deviceAllocate(type=>'sbt_tape',ident=>'t1',params=>'ENV=(TDPO_OPTFILE=/usr/tivoli/tsm/client/oracle/bin64/tdpo.opt)');   
dbms_backup_restore.RestoreSetArchivedLog(destination=>'/arch');  
dbms_backup_restore.RestoreArchivedLog(thread=>2,sequence=>18884);  
dbms_backup_restore.RestoreBackupPiece(done => v_done,handle => 'xxx_archlog_backup<xxxx1_7941 :796937510>.dbf', params => null);  
sys.dbms_backup_restore.deviceDeallocate;   
END; 
/

