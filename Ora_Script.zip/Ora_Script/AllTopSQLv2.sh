#!/bin/sh
##################################
##first argument:  begin  snap id
##second argunetb: end    snap id
##################################

if [ ! -n "$1" ]
then
echo "Pls input begin snap id"
exit
fi

if [ ! -n "$2" ]
then
echo "Pls input end snap id"
exit
fi

if [ ! "$1" -ge 0 ]
then
echo "Pls input begin snap id"
exit
fi

if [ ! "$2" -ge 0 ]
then
echo "Pls input end snap id"
exit
fi

if [ ! $1 > $2 ]
then
echo "begin snap id should greater then end snap id"
exit
fi

BEGIN_SNAP_ID=$1
END_SNAP_ID=$2

ROW_NUM_THRESHOLD=51
BUFFER_GETS_THRESHOLD=100
DISK_READS_THRESHOLD=100
EXEC_THRESHOLD=50


DT=`date "+%Y%m%d_%H"`
LOGIN_NAME="/ as sysdba"

INSTNAME=`sqlplus -s ${LOGIN_NAME} <<EOF
SET FEEDBACK OFF
SET PAGES 0
select instance_name from v\\\$instance;
EOF`

if [ $? -lt 0 ]
then
echo "The script encounterd error,will exit"
exit
fi



DBID=`sqlplus -s ${LOGIN_NAME} <<EOF
SET FEEDBACK OFF
SET PAGES 0
select dbid from v\\\$database;
EOF`

INST_NUMBER=`sqlplus -s ${LOGIN_NAME} <<EOF
SET FEEDBACK OFF
SET PAGES 0
select instance_number from v\\\$instance;
EOF`

INST_NUMBER=`echo ${INST_NUMBER} |sed -e 's/^[ \t ]*/'`

FILENAME=TopSql_all_info_${INSTNAME}_${BEGIN_SNAP_ID}_${END_SNAP_ID}.log
>${FILENAME}

if [ $? -lt 0 ]
then
echo "The script encounterd error,will exit"
exit
fi

echo "   " >>${FILENAME}
echo "#################################################" >>${FILENAME}
echo "## TOP SQL "                                       >>${FILENAME} 
echo "#################################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF

set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col sql_id format a20

spool ${FILENAME} append
prompt top sql with most buffer gets
select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.BUFFER_GETS_DELTA ) > ${BUFFER_GETS_THRESHOLD}
 order by 5 desc) where rownum <   ${ROW_NUM_THRESHOLD}
;

prompt
prompt Top sql with most disk reads
prompt

select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.DISK_READS_DELTA ) > ${DISK_READS_THRESHOLD}
 order by 6 desc) where rownum <  ${ROW_NUM_THRESHOLD}
;

prompt
prompt Top sql with most time elasped
prompt

select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.ELAPSED_TIME_DELTA ) > 600
 order by 7 desc) where rownum <  ${ROW_NUM_THRESHOLD}
;


prompt
prompt Top sql with most time executions
prompt

select * from (
select
    'SQL: '||a.sql_id sql_id,
    a.plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24') end_time,
    sum(a.EXECUTIONS_DELTA) execu_d,
    sum(a.BUFFER_GETS_DELTA ) bg_d,
    sum(a.DISK_READS_DELTA ) dr_d,
    sum(a.ELAPSED_TIME_DELTA/1000000) et_d,
    sum(a.CPU_TIME_DELTA/1000000)  ct_d,
    sum(a.IOWAIT_DELTA/1000000) io_time,
    sum(a.CLWAIT_DELTA/1000000) clus_time,
    sum(a.APWAIT_DELTA/1000000) ap_time,
    sum(a.ccwait_delta/1000000) cc_time,
    decode(sum(a.EXECUTIONS_DELTA),0,sum(a.ELAPSED_TIME_DELTA/1000000),sum(a.ELAPSED_TIME_DELTA/1000000)/sum(a.EXECUTIONS_DELTA)) et_onetime
from
    dba_hist_sqlstat a,
    dba_hist_snapshot b
where  a.SNAP_ID =b.SNAP_ID
  and b.snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID}
  and a.INSTANCE_NUMBER=b.INSTANCE_NUMBER
  and exists (select '1' from dba_hist_sqltext c where c.sql_id = a.sql_id and c.command_type < 7)
group by
    sql_id,
    plan_hash_value,
    to_char(b.END_INTERVAL_TIME,'yyyymmddhh24')
having sum(a.EXECUTIONS_DELTA ) > ${EXEC_THRESHOLD}
 order by 4 desc) where rownum <  ${ROW_NUM_THRESHOLD}
;
spool off
EOF

grep "SQL: " ${FILENAME}  |awk -F ':' '{print $2}'  |awk '{print $1}' |sort -u >topsql_id.tmp

echo " " >show_sql_text.sql
echo " " >show_sql_plan.sql
echo " " >extract_binds.sql
echo " " >show_sql_object.sql
echo " " >report_sql_monitor.sql
echo " " >get_ddl.sql
echo " " >sql_session_info.sql

echo "select sql_id,sql_text from dba_hist_sqltext where sql_id in ("  >>show_sql_text.sql

echo "select distinct object_owner,object_name from dba_hist_sql_plan " >>show_sql_object.sql
echo "where operation like '%TABLE%' and object_type like '%TABLE%' and sql_id in(" >>show_sql_object.sql

echo "col bind1 for a20"   >>extract_binds.sql  
echo "col bind2 for a22"   >>extract_binds.sql
echo "col bind3 for a20"   >>extract_binds.sql
echo "col bind4 for a20"   >>extract_binds.sql
echo "col bind5 for a20"   >>extract_binds.sql
echo "col bind6 for a20"   >>extract_binds.sql
echo "col bind7 for a20"   >>extract_binds.sql
echo "col bind8 for a20"   >>extract_binds.sql
echo "col bind9 for a20"   >>extract_binds.sql
echo "col bind10 for a20"  >>extract_binds.sql
echo "col bind11 for a20"  >>extract_binds.sql
echo "col bind12 for a20"  >>extract_binds.sql
echo "col bind13 for a20"  >>extract_binds.sql
echo "col bind14 for a20"  >>extract_binds.sql
echo "col bind15 for a20"  >>extract_binds.sql
echo "col bind16 for a20"  >>extract_binds.sql
echo "col bind17 for a20"  >>extract_binds.sql
echo "col bind18 for a20"  >>extract_binds.sql
echo "col bind19 for a20"  >>extract_binds.sql
echo "col bind20 for a20"  >>extract_binds.sql
echo "    "                >>extract_binds.sql


cat topsql_id.tmp |while read line
do
echo "'$line',">>show_sql_text.sql
echo "'$line',">>show_sql_object.sql

echo "select * from table (dbms_xplan.display_cursor('$line',0,'allstats last advanced'));" >>show_sql_plan.sql
echo "select * from table (dbms_xplan.display_awr('$line',null,null,'PEEKED_BINDS'));" >>show_sql_plan.sql

echo "prompt"                       >>sql_session_info.sql
echo "select distinct sql_id,program,module,machine " >>sql_session_info.sql
echo "from dba_hist_active_sess_history where sql_id ='$line'" >>sql_session_info.sql 
echo "and snap_id between ${BEGIN_SNAP_ID} and ${END_SNAP_ID};" >>sql_session_info.sql
echo  "prompt"                                                 >>sql_session_info.sql


echo "select"                                                       >>extract_binds.sql
echo "sql_id,snap_id,"                                              >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,1).value_string   bind1," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,2).value_string   bind2," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,3).value_string   bind3," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,4).value_string   bind4," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,5).value_string   bind5," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,6).value_string   bind6," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,7).value_string   bind7," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,8).value_string   bind8," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,9).value_string   bind9," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,10).value_string bind10," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,11).value_string bind11," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,12).value_string bind12," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,13).value_string bind13," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,14).value_string bind14," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,15).value_string bind15," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,16).value_string bind16," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,17).value_string bind17," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,18).value_string bind18," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,19).value_string bind19," >>extract_binds.sql
echo "dbms_sqltune.extract_bind(bind_data,20).value_string bind20 " >>extract_binds.sql
echo "from dba_hist_sqlstat"                                        >>extract_binds.sql
echo "where sql_id='$line'"                                         >>extract_binds.sql
echo "order by snap_id;"                                            >>extract_binds.sql 
echo "   "                                                          >>extract_binds.sql
echo "prompt ${line}_monitor_report " >>report_sql_monitor.sql
echo "select dbms_sqltune.report_sql_monitor(type=>'TEXT', sql_id=>lower('$line'),report_level=>'ALL') from dual;" >>report_sql_monitor.sql
echo " " >>report_sql_monitor.sql
done

echo "'00');" >>show_sql_text.sql
echo "'00');" >>show_sql_object.sql

echo "  "                                         >>${FILENAME}
echo "##########################################" >>${FILENAME}
echo "## SQL TEXT:"                               >>${FILENAME}
echo "##########################################" >>${FILENAME}

sqlplus -s ${LOGIN_NAME} <<EOF1
set pagesize 50000
set linesize 200
set long     2000000000
set verify        off
col sql_id format a20

spool ${FILENAME} append
@show_sql_text.sql
spool off
EOF1

