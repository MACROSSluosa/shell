#!/usr/bin/ksh
#/********************Basic Information********************/#
#Author:                Victor Zhou
#Date:                  2014-07-29
#Function:              To Check the oracle on AIX
#Environment:           AIX
#Main var and func:     None
#Version:               1.0
#/********************Basic Information********************/#

export LANG=en_US

#��ȡʵ����
inst_name=`ps -ef|grep ckpt|grep -v '+ASM'|grep -v grep|awk  '{print $NF}' |awk -F '_' '{print $3}'|head -1`

#����ű���Ŀ¼�����������־�ļ�������expdp��־�ļ���rman��־�ļ������ݿ�alert��־�ļ�
strScriptDirectory="/install/nh/tmp"
expdp_backup_logfile=/install/nh/log_dir/expdp_backup_logfile_icmsdb1.log
backup_logfile=/install/nh/log_dir/backup_logfile_icmsdb1.log
init_alert_logfile=/oracle/app/oracle/diag/rdbms/icmsdb/icmsdb1/trace/alert_icmsdb1.log
Windows_CheckLog_Directory=/install/CheckLog/

[ -f "$expdp_backup_logfile" ] || { echo "$expdp_backup_logfile does not exist!"; exit; }
[ -f "$backup_logfile" ] || { echo "$backup_logfile does not exist!"; exit; }
[ -f "$init_alert_logfile" ] || { echo "$init_alert_logfile does not exist!"; exit; }
[ -d "$Windows_CheckLog_Directory" ] || { mkdir -p $Windows_CheckLog_Directory; }

#����ű���ʹ�õ���ʱ�ļ������¼�ļ���
db_info_file=$strScriptDirectory/db_info_file.log_${inst_name}.log
system_info_file=$strScriptDirectory/system_info_${inst_name}.log
tbs_info_file=$strScriptDirectory/tbs_info_${inst_name}.log
tbs_threshold=$strScriptDirectory/tbs_threshold_${inst_name}.log
last_check_point=$strScriptDirectory/last_check_point_${inst_name}.log
alert_err_info=$strScriptDirectory/alert_err_info_${inst_name}.log
backup_err_info=$strScriptDirectory/backup_err_inf_${inst_name}.log
backup_piece_info=$strScriptDirectory/backup_piece_info_${inst_name}.log
expdp_backup_err_info=$strScriptDirectory/expdp_backup_err_info_${inst_name}.log
last_check_point_rman=$strScriptDirectory/last_check_point_rman_${inst_name}.log
expdp_last_check_point=$strScriptDirectory/expdp_last_check_point_${inst_name}.log

[ -f "$last_check_point" ] || { echo "alert_last_line=1" >$last_check_point; }
[ -f "$last_check_point_rman" ] || { echo 'backup_last_line="Jan 01 00:00:00"' >$last_check_point_rman; }
[ -f "$expdp_last_check_point" ] || { echo 'expdp_backup_last_line="Jan 01 00:00:00"' >$expdp_last_check_point; }


#��ȡ���ݿ��������Ϣ
ORACLE_SID=${inst_name}
hostname=`hostname`
[ -f $db_info_file ] && { rm -f $db_info_file; }
[ -f $tbs_info_file ] && { rm -f $tbs_info_file; }
[ -f $system_info_file ] && { rm -f $system_info_file; }
[ -f $tbs_threshold ] && { rm -f $tbs_threshold; }
[ -f $alert_err_info ] && { rm -f $alert_err_info; }
[ -f $backup_err_info ] && { rm -f $backup_err_info; }
[ -f $backup_piece_info ] && { rm -f $backup_piece_info; }

sqlplus "/ as sysdba"<<EOF
set line 200 pagesize 0 head off
col value for a60

spool $db_info_file
select 'db_name='||name from v\$database ; 
select 'open_mode='||open_mode from v\$database;
select 'bg_dump_dir='||value from v\$parameter where name='background_dump_dest';
spool off
set line 200  pagesize 0 long 10000
spool $tbs_info_file
select d.tablespace_name tablespace_name,
       round((d.sumbytes / 1024 / 1024), 2) total_m,
       round((d.sum_free_extend_bytes +
             decode(f.sumbytes, null, 0, f.sumbytes)) / 1024 / 1024,
             2) free_m,
       round(((d.sumbytes - d.sum_free_extend_bytes -
             decode(f.sumbytes, null, 0, f.sumbytes)) / 1024 / 1024),
             2) used_m,
       round((d.sumbytes - d.sum_free_extend_bytes -
             decode(f.sumbytes, null, 0, f.sumbytes)) * 100 / d.sumbytes,
             2) used_pct
  from (select tablespace_name, sum(bytes) sumbytes
          from dba_free_space
         group by tablespace_name) f,
       (select tablespace_name,
               sum(decode(maxbytes, 0, bytes, maxbytes)) sumbytes,
               sum((decode(maxbytes, 0, bytes, maxbytes) - bytes)) sum_free_extend_bytes
          from dba_data_files
         group by tablespace_name) d
 where f.tablespace_name(+) = d.tablespace_name
 order by d.tablespace_name;
spool off
exit 
EOF

db_name=`grep 'db_name=' $db_info_file |grep -v from |awk -F '=' '{print $2}'|tr -d '\n '`
open_mode=`grep 'open_mode=' $db_info_file|grep -v from  |awk -F '=' '{print $2}'|sed 's/ *$//`
bg_dump_dir=`grep 'bg_dump_dir=' $db_info_file |grep -v from |awk -F '=' '{print $2}'`
alert_log=`echo ${bg_dump_dir}/alert_${inst_name}.log|tr -d ' '`

#��ʹ���ʳ���70%�ı��ռ���Ϣ�����tbs_threshold�ļ���
cat $tbs_info_file |egrep -v "^ +"|grep -v "SQL>"|grep -v "rows selected"|awk '{if($5 >70) print "TABLESPACE "$1" free "$3"M ,used percent "$5}'>$tbs_threshold

if [ -s $tbs_threshold ];then
tbs_info='NOT NORMAL!SEE '${tbs_threshold}
else
tbs_info='NORMAL'
fi

open_status='NORMAL'

#��ʼ�ж����ݿ�״��
if [  "$open_mode" != "READ WRITE" ];then
        if [ -z "$open_mode" ];then
                db_name=$hostname' DB NOT KNOW'
                open_status='NO ORACLE PROCESS'
                tbs_info='ORACLE not open!canot see tbsinfo'
        else 
                open_status='db is nomount/mount but not open'
                tbs_info='ORACLE not open !canot see tbsinfo'
        fi
fi

#�ж�alert��־�Ƿ��и澯
#������ݿ⻹δ��������ʹ�ö����alert��־�ļ�
if [ -z "$bg_dump_dir" -o -z "$inst_name" ];then
                alert_log=$init_alert_logfile
fi

alert_last_line=`cat $last_check_point|grep 'alert_line='|awk -F'=' '{print $2}'`
if [ -z "$alert_last_line" ];then
        alert_last_line=1
fi
match_oras=`cat $alert_log|sed '='|sed -e 'N;s/\n/ /'|sed -n "$alert_last_line,\$"p|sed -n '/ORA-/p'|awk '{print $1}'`
rm -f $alert_err_info
for match_ora in $match_oras
do
echo $match_ora
[ $match_ora -ge 6 ] || { amtch_ora=6; }
startToCatchLineNumber=`expr $match_ora - 5`
endToCatchLineNumber=`expr $match_ora + 5`
cat $alert_log|sed '='|sed -e 'N;s/\n/ /'|sed -n "$startToCatchLineNumber,$endToCatchLineNumber"p >>$alert_err_info
done


if [ -s $alert_err_info ];then
alert_info='NOT NORMAL!SEE '$alert_err_info
else
alert_info='NORMAL'
fi

#�ж�rman�����Ƿ�����
backup_status=''
backup_last_line=`cat $last_check_point_rman|grep 'bakcup_line='|awk -F'=' '{print $2}'`
if [ -z "$backup_last_line" ];then
        backup_last_line="Jan 01 00:00:00"
fi
export last_backup_begin_time=`grep -E "Recovery Manager: Release .*- Production on " $backup_logfile |tail -1|awk -F' on ' '{print $2}'|awk '{print $2" "$3" "$4}' `
echo "last_backup_begin_time "$last_backup_begin_time
export last_backup_end_time=`ls -lrt $backup_logfile |awk '{print $6" "$7" "$8}' `
echo "last_backup_end_time "$last_backup_end_time
cat $backup_logfile |egrep  'RMAN-|ORA-' > $backup_err_info
backupTime=`perl -e 'use HTTP::Date;my $startTime=HTTP::Date::str2time($ENV{"last_backup_begin_time"});my $endTime=HTTP::Date::str2time($ENV{"last_backup_end_time"});my $mins=($endTime - $startTime)/60;print $mins'`
echo $backupTime
backupTime_in_mins=`echo $backupTime|awk -F '.' '{print $1}'`MINS
echo $backupTime_in_mins

#��ȡ����Ƭ��Ϣ
rman target / nocatalog<<EOF>$backup_piece_info
list backup;
exit
EOF

#��ȡ����tag
tags=`grep tag= $backup_logfile|awk -F 'tag=' '{print $2}'|awk '{print $1}'`
grep_tag=''
for tag in $tags
do 
grep_tag=${grep_tag}'|'${tag}
done

#��ȡ���ݴ�С(�ų�KB��С��)
backup_piece_sizes=`egrep -pv $grep_tag $backup_piece_info |awk '{a[NR]=$0;if(/TAG/) print a[NR-1]}'|awk '{if($2 == "Full") print $3;else print $2}'|grep -v K`
backup_size=0
numTotalBackupSize=0

for backup_piece_size in $backup_piece_sizes
do
    echo $backup_piece_size | grep -q "G$"
    if [ $? -eq 0 ];then
        numBackupSize=`echo $backup_piece_size | tr -d ' gbGB'`
        numFormatGtoM=`echo "scale=2;$numBackupSize * 1024"|bc`
        numTotalBackupSize=`echo "scale=2;$numTotalBackupSize + $numFormatGtoM"|bc`
        continue
    fi

    echo $backup_piece_size | grep -q "T$"
    if [ $? -eq 0 ];then
        numBackupSize=`echo $backup_piece_size | tr -d ' tbTB'`
        numFormatTtoM=`echo "scale=2;$numBackupSize * 1024 * 1024"|bc`
        numTotalBackupSize=`echo "scale=2;$numTotalBackupSize + $numFormatTtoM"|bc`
        continue
    fi
    
    numBackupSize=`echo $backup_piece_size | tr -d ' mbMB`
    numTotalBackupSize=`echo "scale=2;$numTotalBackupSize + $numBackupSize"|bc`

done

backup_status="SUCCESS"
backup_elapse=${backupTime_in_mins}
backup_size=${numTotalBackupSize}MB

if [ -z "$last_backup_begin_time" -o -z  "$last_backup_end_time"  ];then
        backup_status='BACKUP NOT SUCCESS'
        backup_elapse=''
        backup_size=''
        last_backup_end_time=''
fi

if [ -s ${backup_err_info} ];then 
        backup_status='BACKUP COMPLETE WITH ERROR,see errors in '${backup_err_info}
        backup_elapse=${backupTime_in_mins}
        backup_size=${numTotalBackupSize}MB
fi

if [ "${backup_last_line}" = "${last_backup_end_time}" ];then
        backup_status='NO BACKUP AFTER LAST ONE'
        backup_elapse=''
        backup_size=''
        last_backup_end_time=''
fi

#������α��ݳɹ������б��ݽ���ʱ�䣬����±���ʱ��
if [ -n "$last_backup_end_time" ];then
        echo "bakcup_line="${last_backup_end_time}>$last_check_point_rman
fi

#�ж�EXPDP�Ƿ�����
expdp_backup_last_line=`cat $expdp_last_check_point|grep 'expdp_bakcup_line='|awk -F'=' '{print $2}'`
if [ -z "$expdp_backup_last_line" ];then
   expdp_backup_last_line="Jan 01 00:00:00"
fi   
export last_expdp_backup_begin_time=`grep -E "Export: Release .* - Production on " $expdp_backup_logfile |tail -1|awk -F' on ' '{print $2}'|awk '{print $2" "$3" "$4}' `
echo "last_expdp_backup_begin_time "$last_expdp_backup_begin_time
export last_expdp_backup_end_time=`ls -lrt $expdp_backup_logfile |awk '{print $6" "$7" "$8}' `
echo "last_backup_end_time "$last_backup_end_time
expbackupTime=`perl -e 'use HTTP::Date;my $startTime=HTTP::Date::str2time($ENV{"last_expdp_backup_begin_time"});my $endTime=HTTP::Date::str2time($ENV{"last_expdp_backup_end_time"});my $mins=($endTime - $startTime)/60;print $mins'`
echo "expbackupTime "$expbackupTime
expbackupTime_in_mins=`echo $expbackupTime|awk -F '.' '{print $1}'`MINS
cat $expdp_backup_logfile|egrep  'ORA-' >$expdp_backup_err_info

exp_back_sizes=`grep rows$ $expdp_backup_logfile |awk '{print $(NF-3)$(NF-2)}'`
numTotaExpdpSize=0

for exp_back_size in $exp_back_sizes
do
    echo $exp_back_size | grep -q "G$"
    if [ $? -eq 0 ];then
        numBackupSize=`echo $exp_back_size | tr -d ' gbGB'`
        numFormatGtoM=`echo "scale=2;$numBackupSize * 1024"|bc`
        numTotaExpdpSize=`echo "scale=2;$numTotaExpdpSize + $numFormatGtoM"|bc`
        continue
    fi

    echo $exp_back_size | grep -q "T$"
    if [ $? -eq 0 ];then
        numBackupSize=`echo $exp_back_size | tr -d ' tbTB'`
        numFormatTtoM=`echo "scale=2;$numBackupSize * 1024 * 1024"|bc`
        numTotaExpdpSize=`echo "scale=2;$numTotaExpdpSize + $numFormatTtoM"|bc`
        continue
    fi
    
    numBackupSize=`echo $exp_back_size | tr -d ' mbMB`
    numTotaExpdpSize=`echo "scale=2;$numTotaExpdpSize + $numBackupSize"|bc`
done

exp_backup_status="SUCCESS"
exp_backup_elapse=${expbackupTime_in_mins}
exp_backup_size=${numTotaExpdpSize}MB

if [ -z "$last_expdp_backup_begin_time" -o -z  "$last_expdp_backup_end_time"  ];then
        exp_backup_status='EXPDP BACKUP NOT SUCCESS'
        exp_backup_elapse=''
        exp_backup_size=''
        last_expdp_backup_end_time=''
fi

if [ -s ${expdp_backup_err_info} ];then 
        exp_backup_status='export complete with error ,see errors in '${expdp_backup_err_info}
        exp_backup_elapse=${expbackupTime_in_mins}
        exp_backup_size=${numTotaExpdpSize}MB
fi

if [ "${expdp_backup_last_line}" = "${last_expdp_backup_end_time}" ];then
        exp_backup_status='NO EXPDP BACKUP AFTER LAST ONE'
        exp_backup_elapse=''
        exp_backup_size=''
        last_expdp_backup_end_time=''
fi

#ȡCPUʹ���ʰٷֱ�
intUserUsage=`vmstat | sed '/^$/d'|egrep -v "System|kthr|-----|us"|awk '{print $(NF-5)}'`
intSysUsage=`vmstat | sed '/^$/d'|egrep -v "System|kthr|-----|us"|awk '{print $(NF-4)}'`
intCPUUsage=`expr $intUserUsage + $intSysUsage`%

#ȡMemoryʹ���ʰٷֱ�
intMemorySize=`svmon -G | grep memory|awk '{print $2}'`
intMemoryVirtual=`svmon -G | grep memory|awk '{print $6}'`
intMemoryUsage=`echo "scale=2;$intMemoryVirtual*100/$intMemorySize"|bc`%


#д��־��Windows�ļ���������Ŀ¼CheckLog�У���Ŀ¼�����Ʋ��ܸı䣬��Ҫ����ܽű�Combine_Check_Log.vbs���ʹ��
echo "ORA,$db_name,$open_status,$tbs_info,$backup_status $exp_backup_status,$backup_size $exp_backup_size,$backup_elapse $exp_backup_elapse,$alert_info,$intCPUUsage,$intMemoryUsage" >$Windows_CheckLog_Directory/CheckResult_${hostname}_${db_name}_`date +%Y%m%d`.txt

#������α��ݳɹ������б��ݽ���ʱ�䣬����±���ʱ��
if [ -n "$last_backup_end_time" ];then
        echo "bakcup_line="${last_backup_end_time}>$last_check_point_rman
fi
if [ -n "$last_expdp_backup_end_time" ];then
        echo "expdp_bakcup_line="${last_expdp_backup_end_time}>$expdp_last_check_point
fi
if [ -n "$endToCatchLineNumber" ];then
echo 'alert_line='$endToCatchLineNumber >$last_check_point
fi