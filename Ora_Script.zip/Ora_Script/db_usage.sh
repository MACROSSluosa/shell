
HOSTNAME=`hostname`
DATE=`date "+%Y%m%d"`
LOGFILE=${HOSTNAME}_${DATE}_storage_usage.log


sqlplus  -S "/as sysdba" <<EOF
spool ${LOGFILE} append

col dba_name format a16
select name from v\$database ;



select name diskgroup_name,total_mb,free_mb
from v\$asm_diskgroup ;


SET PAGESIZE 999
SET LINESIZE 110
TTITLE  LEFT "Tablespace Information"  SKIP 1 -
      LEFT "======================================================================================"
SET HEAD ON
SET FEEDBACK ON
BREAK ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF total_m ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF free_m  ON REPORT
COMPUTE SUM LABEL 'Total Spaces' OF used_m  ON REPORT
col tablespace format a25
col ext_mgt  format a8
col seg_mgt  format a8
col status format a7
set feedback off
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))/1024/1024),2) used_m,
   round((d.sumbytes-decode(f.sumbytes,null,0,f.sumbytes))*100/d.sumbytes,2) used_pct
  from
    (select
      tablespace_name,   sum(bytes) sumbytes
     from dba_free_space   group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes    
      from dba_data_files     group by tablespace_name) d
    where f.tablespace_name(+) = d.tablespace_name
    order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name
union all
select b.tablespace_name tablespace,
       b.total_m,
       b.free_m,
       b.used_m,
       b.used_pct
from
dba_tablespaces a,
(select
   d.tablespace_name tablespace_name,
   round((d.sumbytes/1024/1024),2) total_m,
   round((d.sumbytes/1024/1024),2)-round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) free_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)/1024/1024,2) used_m,
   round(decode(f.sumbytes,null,0,f.sumbytes)*100/d.sumbytes,2) used_pct
   from
    (select
      tablespace_name,      sum(bytes_used) sumbytes
    -- sum(bytes_cached) sumbytes
     from v\$temp_extent_pool     group by tablespace_name) f,
    (select tablespace_name,      sum(bytes) sumbytes
     from dba_temp_files     group by tablespace_name) d
  where f.tablespace_name(+) = d.tablespace_name
  order by d.tablespace_name) b
where a.tablespace_name=b.tablespace_name order by 5;
TTITLE OFF

prompt tbs hist usage

set lines 200 pages 1000
col tbs_name format a36
select a.rtime,
       b.name tbs_name,
       round(a.TABLESPACE_USEDSIZE*c.block_size/1024/1024,0) as used_mb
 from DBA_HIST_TBSPC_SPACE_USAGE a ,
      v\$tablespace b,
      dba_tablespaces c
 where a.tablespace_id = b.ts#
   and b.name =  c.tablespace_name
   and c.contents = 'PERMANENT'
 order by b.name,a.rtime ;

 set lines 200 pages 1000
 col tablespace_name format a36
 col file_name format a80
 select tablespace_name,
        file_name,
        bytes/1024/1024 as size_mb,
        autoextensible
 from dba_data_files
 order by 1,2;

spool off
exit
EOF 





