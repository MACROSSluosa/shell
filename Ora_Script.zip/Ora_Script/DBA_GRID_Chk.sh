#!/bin/bash
HOSTNAME=`hostname`
IPADDR=`hostname -i`
DT=`date +%Y%m%d`
FILENAME=/tmp/DBA_OraChk_grid_${HOSTNAME}_${DT}.html

if [ !$USER = "grid" ]
then
echo "Please run as grid user"
exit
fi

if [ -z `env|grep ORACLE_BASE` ]
then
echo "Please set ORACLE_BASE for GRID USER"
exit
fi


if [ -f ${FILENAME} ]
then
>${FILENAME}
else
touch ${FILENAME}
fi

LISTER_LOG=$ORACLE_BASE/diag/tnslsnr/`hostname`/listener/trace/listener.log
LISTER_LOG_SIZE=`du -sm $LISTER_LOG |awk '{print $1}'`


echo "<html>"         >> ${FILENAME}
echo "<head>"         >> ${FILENAME}
echo "<meta http-equiv="'"Content-Type"'" content="'"text/html; charset=GBK"'">"  >> ${FILENAME}

echo "<meta name="'"generator"'" content="'"OS"'">"  >> ${FILENAME}
echo "<title>CRS check Report</title>    <style type="'"text/css"'">      body              {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;}      p                 {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;}      table,tr,td       {font:9pt Arial,Helvetica,sans-serif; color:Black; background:#C0C0C0; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px;}      th                {font:bold 9pt Arial,Helvetica,sans-serif; color:#336699; background:#cccc99; padding:0px 0px 0px 0px;}      h1                {font:bold 12pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; border-bottom:1px solid #cccc99; margin-top:0pt; margin-bottom:0pt; padding:0px 0px 0px 0px;}      h2                {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; margin-top:4pt; margin-bottom:0pt;}      a                 {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.link            {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLink          {font:9pt Arial,Helvetica,sans-serif; color:#663300; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkBlue      {font:9pt Arial,Helvetica,sans-serif; color:#0000ff; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkDarkBlue  {font:9pt Arial,Helvetica,sans-serif; color:#000099; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkRed       {font:9pt Arial,Helvetica,sans-serif; color:#ff0000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkDarkRed   {font:9pt Arial,Helvetica,sans-serif; color:#990000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkGreen     {font:9pt Arial,Helvetica,sans-serif; color:#00ff00; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}      a.noLinkDarkGreen {font:9pt Arial,Helvetica,sans-serif; color:#009900; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;}    </style>" >>${FILENAME}

echo "</head>" >>${FILENAME}


echo "<body BGCOLOR="'"#C0C0C0"'">" >>${FILENAME}


echo "<br>" >>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo " <b>Host Info</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>" >>${FILENAME}


echo "<table width="90%" border="1">   ">>${FILENAME}
echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Host Name</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${HOSTNAME}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}



echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">IP Address</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${IPADDR}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


OS_VERSION=`cat /etc/redhat-release`
KERNEL_VERISON=`uname -r`
RUN_LEVEL=`who -r`

STR_OUT='<br>'
grep -v "^$" /etc/hosts |while read line
do
STR_OUT=$STR_OUT`echo $line|awk '{print $0"</br>"}'`
done



echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">OS Version</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${OS_VERSION}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Kernel Version</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${KERNEL_VERISON}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}


echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Run Level</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${RUN_LEVEL}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}

echo "<tr> ">>${FILENAME}
echo "<th align="'"left"'" width="'"20%"'">Host File</th> ">>${FILENAME}
echo "<td width="'"80%"'"> ">>${FILENAME}
echo "<tt>${STR_OUT}</tt> ">>${FILENAME}
echo "</td> ">>${FILENAME}
echo "</tr>">>${FILENAME}

echo "</table> ">>${FILENAME}


echo "<br>" >>${FILENAME}
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo " <b>CRS STATUS</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>" >>${FILENAME}

echo "<table width="90%" border="1">   ">>${FILENAME}
echo "<tr>                             ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">NAME</th>            ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">TARGET</th>          ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">STATE</th>           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">SERVER</th>          ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">STATE_DETAILS</th>   ">>${FILENAME}
echo "</tr>                                                       ">>${FILENAME}



echo "<tr><th align="'"left"'" colspan="'"5"'"> Local Resource </th></tr>             ">>${FILENAME}


echo "<tr><th align="'"left"'" colspan="'"5"'"> Cluster Resource </th></tr>           ">>${FILENAME}

echo "</table>                                                                         ">>${FILENAME}

###############################vote disk ####
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>VOTE DISK</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">No</th>                 ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">STATE</th>              ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">File Universal Id </th> ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">File Name</th>          ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">Disk group</th>         ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

crsctl query css votedisk|grep -v "-" |grep -v "File Universal Id" |while read line 
do

VAL1=`echo $line |awk '{print $1}'`
VAL2=`echo $line |awk '{print $2}'`
VAL3=`echo $line |awk '{print $3}'`
VAL4=`echo $line |awk '{print $4}'`
VAL5=`echo $line |awk '{print $5}'`
VAL6=`echo $line |awk '{print $6}'`

echo "<tr> "                                                           >>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $VAL1 </td>"               >>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $VAL2 </td>"               >>${FILENAME}  
echo "<td align="'"left"'" width="'"20%"'"> $VAL3 </td>"               >>${FILENAME} 
echo "<td align="'"left"'" width="'"20%"'"> $VAL4 </td>"               >>${FILENAME} 
echo "<td align="'"left"'" width="'"20%"'"> $VAL5 </td>"               >>${FILENAME} 


echo "</tr> "                                                           >>${FILENAME}

done 
echo "</table>                                                         ">>${FILENAME} 

##################OCR POSITION
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                                                   >>${FILENAME}
echo " <b>OCR Position</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">OCR Position</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

cat /etc/oracle/ocr.loc |while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"               >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}
done
echo "</table>"                                                       >>${FILENAME}


##################opatch version
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>OPatch Version</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">OPatch Version</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

$ORACLE_HOME/OPatch/opatch version |grep -v "^$" |while read line
do
echo "<tr>                                                           ">>${FILENAME}

echo "<td align="'"left"'" width="'"20%"'"> $line </td>"               >>${FILENAME}

echo "</tr>                                                           ">>${FILENAME}

done
echo "</table>"                                                       >>${FILENAME}


##################Patch Details
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>Patch Details</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">Patch Details</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

$ORACLE_HOME/OPatch/opatch lsinventory |grep -v "^$" |grep -v "-"|while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"              >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}

done
echo "</table>"                                                       >>${FILENAME}



##################CSS DIAGWAIT
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>CSS DIAGWAIT</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">CSS DIAGWAIT</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

crsctl get css diagwait|while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"              >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}
done
echo "</table>"                                                       >>${FILENAME}


##################CSS DiskTimeOut
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>CSS DiskTimeOut</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">CSS DiskTimeOut</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

crsctl get css disktimeout|while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"              >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}
done
echo "</table>"                                                       >>${FILENAME}


##################CSS MissCount
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>CSS MissCount</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">CSS MissCount</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

crsctl get css misscount|while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"              >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}
done
echo "</table>"                                                       >>${FILENAME}


##################CSS RebootTime
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>CSS RebootTime</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">CSS RebootTime</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

crsctl get css reboottime|while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"              >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}
done
echo "</table>"                                                       >>${FILENAME}

##################Listener Status
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>Listener Status</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="90%" border="1">                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">Listener Status</th>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

lsnrctl status|while read line
do
echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"left"'" width="'"20%"'"> $line </td>"              >>${FILENAME}
echo "</tr>                                                           ">>${FILENAME}
done
echo "</table>"                                                       >>${FILENAME}



##################Listener Log Info
echo "<font size="'"+2"'" face="'"Arial,Helvetica,Geneva,sans-serif"'" color="'"#336699"'">"  >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}
echo " <b>Listener Log Info</b></font><hr align="'"left"'" width="'"460"'">" >>${FILENAME}
echo "<br>"                                                          >>${FILENAME}

echo "<table width="'"90%"'" border="'"1"'" >                                 ">>${FILENAME}
echo "<tr>                                                           ">>${FILENAME}
echo "<th align="'"center"'" width="'"20%"'">Item</th>               ">>${FILENAME}
echo "<th align="'"center"'" width="'"80%"'">Value</th>               ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}


echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"center"'" width="'"20%"'">Name</td>               ">>${FILENAME}
echo "<td  aign="'"left"'" width="'"80%"'">${LISTER_LOG}</td>       ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"center"'" width="'"20%"'">Size(MB)</td>               ">>${FILENAME}
echo "<td align="'"left"'" width="'"80%"'">${LISTER_LOG_SIZE}</td>      ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

echo "<tr>                                                           ">>${FILENAME}
echo "<td align="'"center"'" width="'"20%"'">Contets for last 2000 lines</td>               ">>${FILENAME}
echo "<td align="'"left"'" width="'"80%"'">`tail -2000 ${LISTER_LOG}`</td>      ">>${FILENAME}
echo "</tr>"                                                          >>${FILENAME}

echo "</table>"                                                       >>${FILENAME}
echo "</body>" >>${FILENAME}
echo "</html>" >>${FILENAME}
